import { existsSync } from 'node:fs';
import type { ExpoConfig } from 'expo/config';

const localGoogleServices = process.env.GOOGLE_SERVICES_JSON || './google-services.json';
const googleServicesFile = existsSync(localGoogleServices) ? localGoogleServices : undefined;
const projectId = process.env.EAS_PROJECT_ID;

const config: ExpoConfig = {
  name: 'HUSTLER',
  slug: 'hustler-private-chat',
  scheme: 'hustler',
  version: '1.0.0',
  orientation: 'portrait',
  userInterfaceStyle: 'dark',
  icon: './assets/icon.png',
  assetBundlePatterns: ['**/*'],
  ios: {
    bundleIdentifier: 'app.hustler.privatechat',
    supportsTablet: false,
    infoPlist: {
      NSCameraUsageDescription: 'HUSTLER uses the camera for private video calls and profile photos.',
      NSMicrophoneUsageDescription: 'HUSTLER uses the microphone for private calls and voice messages.',
      NSPhotoLibraryUsageDescription: 'HUSTLER lets you choose an image to share with an approved contact.'
    }
  },
  android: {
    package: 'app.hustler.privatechat',
    ...(googleServicesFile ? { googleServicesFile } : {}),
    adaptiveIcon: {
      foregroundImage: './assets/adaptive-icon.png',
      backgroundColor: '#041618'
    },
    permissions: [
      'android.permission.CAMERA',
      'android.permission.RECORD_AUDIO',
      'android.permission.MODIFY_AUDIO_SETTINGS',
      'android.permission.POST_NOTIFICATIONS',
      'android.permission.BLUETOOTH_CONNECT',
      'android.permission.INTERNET',
      'android.permission.VIBRATE'
    ],
    allowBackup: false,
    softwareKeyboardLayoutMode: 'pan'
  },
  plugins: [
    [
      '@config-plugins/react-native-webrtc',
      {
        cameraPermission: 'Allow HUSTLER to use your camera for private video calls.',
        microphonePermission: 'Allow HUSTLER to use your microphone for private calls.'
      }
    ],
    [
      'expo-audio',
      {
        microphonePermission: 'Allow HUSTLER to record voice messages and calls.',
        enableBackgroundRecording: false
      }
    ],
    [
      'expo-image-picker',
      {
        photosPermission: 'Choose a photo to share privately with an approved HUSTLER contact.',
        cameraPermission: 'Take a profile photo or a photo to share privately.'
      }
    ],
    [
      'expo-splash-screen',
      {
        image: './assets/splash.png',
        imageWidth: 240,
        resizeMode: 'contain',
        backgroundColor: '#041618'
      }
    ],
    [
      'expo-notifications',
      {
        defaultChannel: 'messages',
        color: '#20D7B5'
      }
    ],
    'expo-font',
    'expo-asset'
  ],
  extra: {
    firebase: {
      apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY ?? '',
      authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN ?? '',
      projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID ?? '',
      storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET ?? '',
      messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? '',
      appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID ?? '',
      databaseURL: process.env.EXPO_PUBLIC_FIREBASE_DATABASE_URL ?? ''
    },
    unlockExpression: process.env.EXPO_PUBLIC_UNLOCK_EXPRESSION ?? '748+88',
    ...(projectId ? { eas: { projectId } } : {})
  }
};

export default config;

import { applicationDefault, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { getDatabase } from 'firebase-admin/database';

const email = process.argv[2];
const projectId = process.argv[3] || process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT;
const databaseURL = process.env.FIREBASE_DATABASE_URL || process.env.EXPO_PUBLIC_FIREBASE_DATABASE_URL;
if (!email || !projectId || !databaseURL) {
  console.error('Usage: FIREBASE_DATABASE_URL=<exact-rtdb-url> npm run provision-admin -- <existing-auth-email> <firebase-project-id>');
  process.exit(2);
}

initializeApp({ credential: applicationDefault(), projectId, databaseURL });
const auth = getAuth();
const user = await auth.getUserByEmail(email);
if (user.disabled) throw new Error('The selected Firebase Auth account is disabled.');
const db = getFirestore();
const profileRef = db.collection('users').doc(user.uid);
const profile = await profileRef.get();
if (!profile.exists) throw new Error('Create/sign in to the account once so its pending users/{uid} profile exists, then rerun this command.');
await auth.setCustomUserClaims(user.uid, { ...(user.customClaims ?? {}), admin: true });
await profileRef.update({
  status: 'approved',
  role: 'admin',
  accountDisabled: false,
  approvedAt: FieldValue.serverTimestamp(),
  updatedAt: FieldValue.serverTimestamp()
});
await getDatabase().ref(`approved/${user.uid}`).set(true);
console.log(`Provisioned ${email} (${user.uid}) as the initial HUSTLER administrator.`);
console.log('The account must refresh its Firebase ID token (sign out/in) before the admin claim is visible in the app.');

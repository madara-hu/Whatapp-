import { createHmac } from 'node:crypto';
import { getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, Timestamp, getFirestore } from 'firebase-admin/firestore';
import { getDatabase } from 'firebase-admin/database';
import { getMessaging } from 'firebase-admin/messaging';
import { setGlobalOptions } from 'firebase-functions/v2';
import { onDocumentCreated, onDocumentWritten } from 'firebase-functions/v2/firestore';
import { onValueWritten } from 'firebase-functions/v2/database';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { defineSecret, defineString } from 'firebase-functions/params';

if (getApps().length === 0) initializeApp();
setGlobalOptions({ region: 'asia-south1', maxInstances: 10 });

const db = getFirestore();
const rtdb = getDatabase();
const TURN_URLS = defineString('TURN_URLS', { default: '' });
const TURN_SHARED_SECRET = defineSecret('TURN_SHARED_SECRET');
const terminalCallStatuses = new Set(['ended', 'declined', 'missed', 'failed']);

async function userIsApproved(uid: string): Promise<boolean> {
  const snapshot = await db.collection('users').doc(uid).get();
  return snapshot.exists && snapshot.data()?.status === 'approved' && snapshot.data()?.accountDisabled !== true;
}

async function sendPushToUser(uid: string, input: { title: string; body: string; channelId: 'messages' | 'calls'; data: Record<string, string> }): Promise<void> {
  const userRef = db.collection('users').doc(uid);
  const profile = await userRef.get();
  if (!profile.exists || profile.data()?.status !== 'approved' || profile.data()?.accountDisabled === true) return;
  const devices = await userRef.collection('devices').get();
  const docs = devices.docs.filter(snapshot => typeof snapshot.data().token === 'string' && snapshot.data().token.length > 20);
  const tokens = docs.map(snapshot => String(snapshot.data().token));
  if (tokens.length === 0) return;
  const response = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: input.title, body: input.body },
    data: input.data,
    android: {
      priority: 'high',
      ttl: 60_000,
      notification: { channelId: input.channelId, sound: 'default' }
    },
    apns: { headers: { 'apns-priority': '10', 'apns-expiration': String(Math.floor(Date.now() / 1000) + 60) } }
  });
  const invalid = response.responses.flatMap((result, index) => {
    const code = result.error?.code ?? '';
    return code.includes('registration-token-not-registered') || code.includes('invalid-registration-token') ? [docs[index]?.ref] : [];
  }).filter((reference): reference is NonNullable<typeof reference> => Boolean(reference));
  await Promise.all(invalid.map(reference => reference.delete()));
}

export const mirrorApprovalToRealtimeDatabase = onDocumentWritten('users/{uid}', async event => {
  const after = event.data?.after;
  const uid = event.params.uid;
  if (!after?.exists) {
    await rtdb.ref(`approved/${uid}`).set(false);
    await rtdb.ref(`status/${uid}`).remove();
    return;
  }
  const profile = after.data();
  if (!profile) return;
  const isApproved = profile.status === 'approved' && profile.accountDisabled !== true;
  await rtdb.ref(`approved/${uid}`).set(isApproved);
  if (!isApproved) await rtdb.ref(`status/${uid}`).set({ state: 'offline', last_changed: Date.now() });
});

export const mirrorPresenceToFirestore = onValueWritten('/status/{uid}', async event => {
  const uid = event.params.uid;
  const profileRef = db.collection('users').doc(uid);
  const profile = await profileRef.get();
  if (!profile.exists || profile.data()?.status !== 'approved' || profile.data()?.accountDisabled === true) return;
  const status = event.data.after.val() as { state?: string; last_changed?: number } | null;
  const state = status?.state === 'online' ? 'online' : 'offline';
  const changedAt = typeof status?.last_changed === 'number' ? status.last_changed : Date.now();
  await profileRef.update({
    presence: state,
    lastSeenAt: Timestamp.fromMillis(changedAt),
    updatedAt: FieldValue.serverTimestamp()
  });
});

export const notifyOnMessage = onDocumentCreated('chats/{chatId}/messages/{messageId}', async event => {
  const message = event.data?.data();
  if (!message || typeof message.senderId !== 'string') return;
  const chat = await db.collection('chats').doc(event.params.chatId).get();
  if (!chat.exists) return;
  const participants = chat.data()?.participantIds;
  if (!Array.isArray(participants)) return;
  const recipients = participants.filter((uid: unknown): uid is string => typeof uid === 'string' && uid !== message.senderId);
  await Promise.all(recipients.map(uid => sendPushToUser(uid, {
    title: 'HUSTLER',
    body: 'You have a new private message.',
    channelId: 'messages',
    data: { kind: 'message', chatId: event.params.chatId }
  })));
});

export const notifyOnIncomingCall = onDocumentWritten('calls/{callId}', async event => {
  const before = event.data?.before.data();
  const afterSnapshot = event.data?.after;
  if (!afterSnapshot?.exists) return;
  const call = afterSnapshot.data();
  if (!call) return;
  const becameRinging = call.status === 'ringing' && typeof call.offer?.sdp === 'string'
    && (before?.status !== 'ringing' || typeof before?.offer?.sdp !== 'string');
  if (becameRinging && typeof call.calleeId === 'string') {
    await sendPushToUser(call.calleeId, {
      title: 'HUSTLER call',
      body: call.mediaType === 'video' ? 'Incoming video call' : 'Incoming voice call',
      channelId: 'calls',
      data: { kind: 'call', callId: event.params.callId, callerId: String(call.callerId), mediaType: String(call.mediaType) }
    });
  }

  const becameTerminal = terminalCallStatuses.has(String(call.status)) && !terminalCallStatuses.has(String(before?.status ?? ''));
  if (becameTerminal) await deleteCallCandidates(event.params.callId);
});

async function deleteCallCandidates(callId: string): Promise<void> {
  const callRef = db.collection('calls').doc(callId);
  for (const side of ['callerCandidates', 'calleeCandidates']) {
    while (true) {
      const snapshot = await callRef.collection(side).limit(450).get();
      if (snapshot.empty) break;
      const batch = db.batch();
      snapshot.docs.forEach(candidate => batch.delete(candidate.ref));
      await batch.commit();
    }
  }
}

export const markUnansweredCallsMissed = onSchedule({ schedule: 'every 1 minutes', timeZone: 'UTC' }, async () => {
  const cutoff = Timestamp.fromMillis(Date.now() - 60_000);
  const expired = await db.collection('calls')
    .where('status', '==', 'ringing')
    .where('createdAt', '<', cutoff)
    .limit(100)
    .get();
  if (expired.empty) return;
  const batch = db.batch();
  expired.docs.forEach(call => batch.update(call.ref, {
    status: 'missed',
    endedAt: FieldValue.serverTimestamp(),
    durationSeconds: 0,
    updatedAt: FieldValue.serverTimestamp()
  }));
  await batch.commit();
});

export const adminSetAccountStatus = onCall(async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator approval is required.');
  const uid = request.data?.uid;
  const status = request.data?.status;
  if (typeof uid !== 'string' || !['approved', 'pending', 'disabled'].includes(status)) {
    throw new HttpsError('invalid-argument', 'A valid account and status are required.');
  }
  if (uid === request.auth.uid) throw new HttpsError('failed-precondition', 'Use the secure provisioning process to modify the initial administrator.');
  const target = db.collection('users').doc(uid);
  const snapshot = await target.get();
  if (!snapshot.exists) throw new HttpsError('not-found', 'The account profile was not found.');
  const accountDisabled = status === 'disabled';
  await target.update({
    status,
    accountDisabled,
    updatedAt: FieldValue.serverTimestamp(),
    ...(status === 'approved' ? { approvedAt: FieldValue.serverTimestamp() } : {})
  });
  if (accountDisabled) await getAuth().revokeRefreshTokens(uid);
  return { ok: true };
});

export const getTurnConfig = onCall({ secrets: [TURN_SHARED_SECRET] }, async request => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in to request call configuration.');
  if (!(await userIsApproved(request.auth.uid))) throw new HttpsError('permission-denied', 'An approved account is required.');
  const urls = TURN_URLS.value().split(',').map(value => value.trim()).filter(Boolean);
  if (urls.length === 0) return { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }], turnConfigured: false };
  const secret = TURN_SHARED_SECRET.value();
  if (!secret) throw new HttpsError('failed-precondition', 'TURN_SHARED_SECRET is not configured in Secret Manager.');
  const expiresAt = Math.floor(Date.now() / 1000) + 60 * 60;
  const username = `${expiresAt}:${request.auth.uid}`;
  const credential = createHmac('sha1', secret).update(username).digest('base64');
  return { iceServers: [{ urls, username, credential }], turnConfigured: true, expiresAt };
});

import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, setDoc } from 'firebase/firestore';
import { deleteObject, getBytes, ref, uploadBytes } from 'firebase/storage';

const emulatorConfigured = Boolean(process.env.FIREBASE_STORAGE_EMULATOR_HOST && process.env.FIRESTORE_EMULATOR_HOST);
const suite = describe.skipIf(!emulatorConfigured);
let testEnv: RulesTestEnvironment;

suite('Firebase Storage security rules', () => {
  beforeAll(async () => {
    const [host, rawPort] = (process.env.FIREBASE_STORAGE_EMULATOR_HOST ?? '127.0.0.1:9199').split(':');
    const rules = readFileSync(new URL('../storage.rules', import.meta.url), 'utf8');
    testEnv = await initializeTestEnvironment({
      projectId: process.env.GCLOUD_PROJECT ?? 'demo-hustler-private-chat',
      storage: { host: host ?? '127.0.0.1', port: Number(rawPort ?? 9199), rules }
    });
  });

  beforeEach(async () => {
    await testEnv.clearStorage();
    await testEnv.clearFirestore();
    await testEnv.withSecurityRulesDisabled(async context => {
      const db = context.firestore();
      for (const [uid, status] of [['alice', 'approved'], ['bob', 'approved'], ['eve', 'pending']] as const) {
        await setDoc(doc(db, 'users', uid), {
          status,
          accountDisabled: false,
          username: uid,
          displayName: uid,
          photoPath: null
        });
      }
      await setDoc(doc(db, 'chats', 'alice__bob'), {
        participantIds: ['alice', 'bob']
      });
    });
  });

  afterAll(async () => { await testEnv.cleanup(); });

  it('allows approved participants to read shared media but denies unapproved, unrelated, or destructive access', async () => {
    const bytes = new Uint8Array([72, 85, 83, 84, 76, 69, 82]);
    const aliceStorage = testEnv.authenticatedContext('alice').storage();
    const bobStorage = testEnv.authenticatedContext('bob').storage();
    const eveStorage = testEnv.authenticatedContext('eve').storage();
    const mediaPath = 'chats/alice__bob/alice/photo.jpg';

    await assertSucceeds(uploadBytes(ref(aliceStorage, mediaPath), bytes, { contentType: 'image/jpeg' }));
    const downloaded = await assertSucceeds(getBytes(ref(bobStorage, mediaPath)));
    if (downloaded.byteLength !== bytes.byteLength) throw new Error('The private media bytes did not round-trip.');

    await assertFails(getBytes(ref(eveStorage, mediaPath)));
    await assertFails(uploadBytes(ref(eveStorage, 'chats/alice__bob/eve/intrusion.jpg'), bytes, { contentType: 'image/jpeg' }));
    await assertFails(uploadBytes(ref(aliceStorage, 'chats/missing/alice/intrusion.jpg'), bytes, { contentType: 'image/jpeg' }));
    await assertFails(uploadBytes(ref(aliceStorage, 'chats/alice__bob/bob/impersonation.jpg'), bytes, { contentType: 'image/jpeg' }));
    await assertFails(deleteObject(ref(bobStorage, mediaPath)));
  });

  it('requires approved ownership for profile photos', async () => {
    const bytes = new Uint8Array([1, 2, 3]);
    const aliceStorage = testEnv.authenticatedContext('alice').storage();
    const bobStorage = testEnv.authenticatedContext('bob').storage();
    const path = 'users/alice/profile/avatar.jpg';
    await assertSucceeds(uploadBytes(ref(aliceStorage, path), bytes, { contentType: 'image/jpeg' }));
    await assertSucceeds(getBytes(ref(bobStorage, path)));
    await assertFails(uploadBytes(ref(bobStorage, 'users/alice/profile/avatar.jpg'), bytes, { contentType: 'image/jpeg' }));
  });
});

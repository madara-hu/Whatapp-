import { describe, expect, it } from 'vitest';
import { calculateOrUnlock, evaluateExpression, formatCalculatorNumber, isUnlockExpression } from '../src/core/calculator';
import { postAuthDestination } from '../src/core/authPolicy';
import { canTransitionCallStatus, isTerminalCallStatus, releaseCallResources } from '../src/core/callLifecycle';
import { directChatId, messagePreview, receiptLabel } from '../src/core/chatModel';

describe('calculator unlock and parser', () => {
  it('unlocks on the exact sequence in the same equals decision, before evaluating it', () => {
    const started = Date.now();
    expect(calculateOrUnlock('748+88', '748+88')).toEqual({ kind: 'unlock' });
    expect(Date.now() - started).toBeLessThan(50);
    expect(calculateOrUnlock(' 748 + 88 ', '748+88')).toEqual({ kind: 'unlock' });
    expect(isUnlockExpression('748+88', '748+88')).toBe(true);
  });

  it('continues to calculate with correct operator precedence and decimals', () => {
    expect(evaluateExpression('2+3*4')).toBe(14);
    expect(evaluateExpression('(2+3)*4')).toBe(20);
    expect(evaluateExpression('2.5*4')).toBe(10);
    expect(evaluateExpression('-3+7/2')).toBe(0.5);
    expect(formatCalculatorNumber(0.1 + 0.2)).toBe('0.3');
    expect(calculateOrUnlock('12+8', '748+88')).toEqual({ kind: 'result', value: 20 });
  });

  it('rejects malformed or unsafe expressions without JavaScript execution', () => {
    expect(() => evaluateExpression('1/0')).toThrow(/zero/i);
    expect(() => evaluateExpression('1..2+3')).toThrow();
    expect(() => evaluateExpression('2+globalThis')).toThrow();
    expect(() => evaluateExpression('(')).toThrow();
    expect(() => evaluateExpression('9e100')).toThrow();
  });
});

describe('authentication access policy', () => {
  it('routes only approved, enabled profiles to chats', () => {
    expect(postAuthDestination({ hasProfile: true, status: 'approved', accountDisabled: false })).toBe('chats');
    expect(postAuthDestination({ hasProfile: true, status: 'pending' })).toBe('pending');
    expect(postAuthDestination({ hasProfile: true, status: 'disabled' })).toBe('disabled');
    expect(postAuthDestination({ hasProfile: false })).toBe('profile-required');
  });
});

describe('chat helpers', () => {
  it('creates a deterministic one-to-one ID and labels previews', () => {
    expect(directChatId('z-user', 'a-user')).toBe('a-user__z-user');
    expect(directChatId('a-user', 'z-user')).toBe('a-user__z-user');
    expect(messagePreview({ type: 'image' })).toBe('Photo');
    expect(messagePreview({ type: 'audio' })).toBe('Voice message');
    expect(messagePreview({ type: 'text', text: 'hello'.repeat(40) })).toHaveLength(160);
  });

  it('shows sent, delivered and read receipt states only to the sender', () => {
    expect(receiptLabel({ senderId: 'alice', deliveredTo: ['alice'], readBy: ['alice'] }, 'alice')).toBe('sent');
    expect(receiptLabel({ senderId: 'alice', deliveredTo: ['alice', 'bob'], readBy: ['alice'] }, 'alice')).toBe('delivered');
    expect(receiptLabel({ senderId: 'alice', deliveredTo: ['alice', 'bob'], readBy: ['alice', 'bob'] }, 'alice')).toBe('read');
    expect(receiptLabel({ senderId: 'alice', deliveredTo: ['alice'], readBy: ['alice'] }, 'bob')).toBeNull();
  });
});

describe('call lifecycle and cleanup', () => {
  it('allows only intended call state transitions', () => {
    expect(canTransitionCallStatus('ringing', 'connecting')).toBe(true);
    expect(canTransitionCallStatus('connecting', 'active')).toBe(true);
    expect(canTransitionCallStatus('active', 'ended')).toBe(true);
    expect(canTransitionCallStatus('ended', 'active')).toBe(false);
    expect(isTerminalCallStatus('missed')).toBe(true);
    expect(isTerminalCallStatus('connecting')).toBe(false);
  });

  it('releases tracks, peer, listeners, and remote signaling candidates', async () => {
    const calls: string[] = [];
    const track = { stop: () => calls.push('track') };
    await releaseCallResources({
      streams: [{ getTracks: () => [track] }],
      peer: { close: () => calls.push('peer') },
      unsubscribers: [() => calls.push('listener')],
      removeCandidates: async () => { calls.push('candidates'); }
    });
    expect(calls).toEqual(['listener', 'track', 'peer', 'candidates']);
  });
});

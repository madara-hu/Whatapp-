import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { collection, deleteDoc, doc, getDoc, getDocs, query, serverTimestamp, setDoc, updateDoc, where, writeBatch } from 'firebase/firestore';

const emulatorConfigured = Boolean(process.env.FIRESTORE_EMULATOR_HOST);
const suite = describe.skipIf(!emulatorConfigured);
let testEnv: RulesTestEnvironment;

suite('Firestore security rules', () => {
  beforeAll(async () => {
    const [host, rawPort] = (process.env.FIRESTORE_EMULATOR_HOST ?? '127.0.0.1:8080').split(':');
    const rules = readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8');
    testEnv = await initializeTestEnvironment({
      projectId: process.env.GCLOUD_PROJECT ?? 'demo-hustler-private-chat',
      firestore: { host: host ?? '127.0.0.1', port: Number(rawPort ?? 8080), rules }
    });
  });

  beforeEach(async () => {
    await testEnv.clearFirestore();
    await testEnv.withSecurityRulesDisabled(async context => {
      const db = context.firestore();
      for (const uid of ['alice', 'bob', 'eve']) {
        await setDoc(doc(db, 'users', uid), {
          username: uid,
          displayName: uid,
          about: '',
          photoPath: null,
          status: uid === 'eve' ? 'pending' : 'approved',
          role: 'member',
          accountDisabled: false,
          presence: 'offline',
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
      await setDoc(doc(db, 'chats', 'alice__bob'), {
        participantIds: ['alice', 'bob'],
        createdAt: new Date(),
        updatedAt: new Date(),
        lastMessageAt: null,
        lastMessageId: null,
        lastMessagePreview: '',
        lastSenderId: null,
        unreadCounts: { alice: 0, bob: 0 }
      });
      await setDoc(doc(db, 'chats', 'alice__bob', 'messages', 'seeded'), {
        senderId: 'alice', type: 'text', text: 'hello', storagePath: null,
        mediaMimeType: null, durationMs: null, createdAt: new Date(),
        deliveredTo: ['alice'], readBy: ['alice']
      });
    });
  });

  afterAll(async () => { await testEnv.cleanup(); });

  it('prevents an unrelated authenticated account from reading another chat or its messages', async () => {
    const eveDb = testEnv.authenticatedContext('eve').firestore();
    await assertFails(getDoc(doc(eveDb, 'chats', 'alice__bob')));
    await assertFails(getDoc(doc(eveDb, 'chats', 'alice__bob', 'messages', 'seeded')));
  });

  it('allows approved participants to read messages and blocks pending accounts from listing contacts', async () => {
    const aliceDb = testEnv.authenticatedContext('alice').firestore();
    await assertSucceeds(getDoc(doc(aliceDb, 'chats', 'alice__bob', 'messages', 'seeded')));
    const eveDb = testEnv.authenticatedContext('eve').firestore();
    await assertFails(getDocs(query(collection(eveDb, 'users'), where('status', '==', 'approved'))));
  });

  it('blocks disabled users and permits pending-account review only with the admin claim', async () => {
    const aliceDb = testEnv.authenticatedContext('alice').firestore();
    await testEnv.withSecurityRulesDisabled(async context => {
      await updateDoc(doc(context.firestore(), 'users', 'alice'), { accountDisabled: true });
    });
    await assertFails(getDoc(doc(aliceDb, 'chats', 'alice__bob')));

    const adminDb = testEnv.authenticatedContext('root', { admin: true }).firestore();
    await assertSucceeds(getDocs(query(collection(adminDb, 'users'), where('status', '==', 'pending'))));
  });

  it('requires account creation and username reservation in the same transaction', async () => {
    const memberDb = testEnv.authenticatedContext('newmember').firestore();
    const batch = writeBatch(memberDb);
    batch.set(doc(memberDb, 'usernames', 'new_member'), {
      uid: 'newmember', username: 'new_member', createdAt: serverTimestamp()
    });
    batch.set(doc(memberDb, 'users', 'newmember'), {
      username: 'new_member', displayName: 'New Member', about: '', photoPath: null,
      status: 'pending', role: 'member', accountDisabled: false, presence: 'offline',
      lastSeenAt: serverTimestamp(), createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });
    await assertSucceeds(batch.commit());

    await assertFails(setDoc(doc(memberDb, 'usernames', 'squatted_name'), {
      uid: 'newmember', username: 'squatted_name', createdAt: serverTimestamp()
    }));
  });

  it('allows a valid message transaction and rejects forged unread increments', async () => {
    const aliceDb = testEnv.authenticatedContext('alice').firestore();
    const chatRef = doc(aliceDb, 'chats', 'alice__bob');
    const messageRef = doc(aliceDb, 'chats', 'alice__bob', 'messages', 'valid-message');
    const batch = writeBatch(aliceDb);
    batch.set(messageRef, {
      senderId: 'alice', type: 'text', text: 'Hello Bob', storagePath: null,
      mediaMimeType: null, durationMs: null, createdAt: serverTimestamp(),
      deliveredTo: ['alice'], readBy: ['alice']
    });
    batch.update(chatRef, {
      lastMessageId: 'valid-message', lastMessagePreview: 'Hello Bob',
      lastMessageAt: serverTimestamp(), lastSenderId: 'alice', updatedAt: serverTimestamp(),
      unreadCounts: { alice: 0, bob: 1 }
    });
    await assertSucceeds(batch.commit());

    const forgedBatch = writeBatch(aliceDb);
    forgedBatch.set(doc(aliceDb, 'chats', 'alice__bob', 'messages', 'forged-message'), {
      senderId: 'alice', type: 'text', text: 'More', storagePath: null,
      mediaMimeType: null, durationMs: null, createdAt: serverTimestamp(),
      deliveredTo: ['alice'], readBy: ['alice']
    });
    forgedBatch.update(chatRef, {
      lastMessageId: 'forged-message', lastMessagePreview: 'More',
      lastMessageAt: serverTimestamp(), lastSenderId: 'alice', updatedAt: serverTimestamp(),
      unreadCounts: { alice: 0, bob: 9999 }
    });
    await assertFails(forgedBatch.commit());
  });

  it('allows an approved user to create only a valid private pair', async () => {
    const aliceDb = testEnv.authenticatedContext('alice').firestore();
    await assertSucceeds(setDoc(doc(aliceDb, 'chats', 'alice__bob_2'), {
      participantIds: ['alice', 'bob'],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastMessageAt: null,
      lastMessageId: null,
      lastMessagePreview: '',
      lastSenderId: null,
      unreadCounts: { alice: 0, bob: 0 }
    }));
    await assertFails(setDoc(doc(aliceDb, 'chats', 'alice__eve'), {
      participantIds: ['alice', 'eve'], createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
      lastMessageAt: null, lastMessageId: null, lastMessagePreview: '', lastSenderId: null,
      unreadCounts: { alice: 0, eve: 0 }
    }));
  });

  it('restricts call signaling, status changes, and candidate cleanup to call participants', async () => {
    const aliceDb = testEnv.authenticatedContext('alice').firestore();
    const eveDb = testEnv.authenticatedContext('eve').firestore();
    const callRef = doc(aliceDb, 'calls', 'call-1');
    await assertSucceeds(setDoc(callRef, {
      callerId: 'alice', calleeId: 'bob', participantIds: ['alice', 'bob'], mediaType: 'audio',
      status: 'ringing', offer: { type: 'offer', sdp: 'test-offer-sdp' }, answer: null,
      createdAt: serverTimestamp(), answeredAt: null, endedAt: null, durationSeconds: null, updatedAt: serverTimestamp()
    }));
    const candidateRef = doc(aliceDb, 'calls', 'call-1', 'callerCandidates', 'candidate-1');
    await assertSucceeds(setDoc(candidateRef, { candidate: 'candidate:sample', sdpMid: 'audio', sdpMLineIndex: 0, createdAt: serverTimestamp() }));
    await assertFails(getDoc(doc(eveDb, 'calls', 'call-1')));
    await assertFails(setDoc(doc(eveDb, 'calls', 'call-1', 'calleeCandidates', 'intruder'), { candidate: 'bad', sdpMid: null, sdpMLineIndex: null, createdAt: serverTimestamp() }));
    await assertSucceeds(updateDoc(callRef, { status: 'ended', endedAt: serverTimestamp(), durationSeconds: 0, updatedAt: serverTimestamp() }));
    await assertSucceeds(deleteDoc(candidateRef));
  });
});

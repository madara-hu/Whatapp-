`npm test` runs the deterministic core tests. The Firestore and Storage security-rule suites skip when their emulator host variables are not set.

Run `npm run rules:test` to start Firestore and Storage emulators under the demo-only project `demo-hustler-private-chat` and execute the rule suites (7 Firestore tests and 2 Storage tests). It requires Java 21+ and does not contact or require login to a live Firebase project.

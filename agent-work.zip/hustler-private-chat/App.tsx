import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, BackHandler, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useAuthState } from '@/hooks/useAuth';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { firebaseReady, realtimeDatabase } from '@/config/firebase';
import { postAuthDestination } from '@/core/authPolicy';
import { clearPrivateMediaCache } from '@/services/mediaService';
import { signIn, registerPendingAccount, logout } from '@/services/authService';
import { connectPresence } from '@/services/presenceService';
import { addNotificationTapListener, getInitialNotificationData, installNotificationPresentation, refreshPushTokenIfGranted, registerPushNotifications, subscribePushTokenRefresh, unregisterPushNotifications } from '@/services/notificationService';
import { acceptIncomingCall, CallController, declineIncomingCall, startOutgoingCall, subscribeIncomingCalls, getCall } from '@/services/callService';
import { getApprovedUser, getChatById, getOrCreateDirectChat } from '@/services/chatService';
import type { CallDocument, CallMediaType, ChatDocument, MainTab, UserProfile } from '@/types/models';
import { CalculatorScreen } from '@/screens/CalculatorScreen';
import { LoginScreen, PendingApprovalScreen, RegisterScreen } from '@/screens/AuthScreens';
import { ChatListScreen } from '@/screens/ChatListScreen';
import { ContactsScreen } from '@/screens/ContactsScreen';
import { ChatScreen } from '@/screens/ChatScreen';
import { ProfileScreen } from '@/screens/ProfileScreen';
import { CallHistoryScreen } from '@/screens/CallHistoryScreen';
import { PrivacyScreen } from '@/screens/PrivacyScreen';
import { AdminScreen } from '@/screens/AdminScreen';
import { LogoutScreen } from '@/screens/LogoutScreen';
import { IncomingCallScreen } from '@/screens/IncomingCallScreen';
import { ActiveCallScreen } from '@/screens/ActiveCallScreen';
import { ImagePreviewScreen } from '@/screens/ImagePreviewScreen';
import { AppScreen } from '@/components/Primitives';

export type Route =
  | { name: 'calculator' }
  | { name: 'login' }
  | { name: 'register' }
  | { name: 'pending' }
  | { name: 'chats' }
  | { name: 'calls' }
  | { name: 'contacts'; embedded: boolean }
  | { name: 'profile' }
  | { name: 'privacy' }
  | { name: 'admin' }
  | { name: 'logout' }
  | { name: 'chat'; chat: ChatDocument; person: UserProfile }
  | { name: 'image'; storagePath: string }
  | { name: 'incomingCall'; call: CallDocument; person: UserProfile }
  | { name: 'activeCall'; controller: CallController; person: UserProfile };

function routeForTab(tab: MainTab): Route {
  if (tab === 'calls') return { name: 'calls' };
  if (tab === 'contacts') return { name: 'contacts', embedded: false };
  if (tab === 'profile') return { name: 'profile' };
  return { name: 'chats' };
}

function isProtectedRoute(route: Route): boolean {
  return !['calculator', 'login', 'register', 'pending'].includes(route.name);
}

export default function App() {
  const authState = useAuthState();
  const connected = useNetworkStatus();
  const [route, setRoute] = useState<Route>({ name: 'calculator' });
  const [, setHistory] = useState<Route[]>([]);
  const [unlocked, setUnlocked] = useState(false);
  const [notificationEnabled, setNotificationEnabled] = useState<boolean | null>(null);
  const [logoutBusy, setLogoutBusy] = useState(false);
  const [callStarting, setCallStarting] = useState(false);
  const routeRef = useRef(route);
  const acceptingCallRef = useRef(false);
  const deferredNotificationRef = useRef<Record<string, unknown> | null>(null);

  routeRef.current = route;

  const replaceRoute = useCallback((next: Route) => {
    routeRef.current = next;
    setHistory([]);
    setRoute(next);
  }, []);

  const pushRoute = useCallback((next: Route) => {
    setHistory(previous => [...previous, routeRef.current]);
    routeRef.current = next;
    setRoute(next);
  }, []);

  const goBack = useCallback(() => {
    setHistory(previous => {
      if (previous.length > 0) {
        const next = previous[previous.length - 1];
        if (next) { routeRef.current = next; setRoute(next); }
        return previous.slice(0, -1);
      }
      const fallback: Route = unlocked
        ? (authState.profile?.status === 'approved' ? { name: 'chats' } : { name: 'login' })
        : { name: 'calculator' };
      routeRef.current = fallback;
      setRoute(fallback);
      return [];
    });
  }, [authState.profile?.status, unlocked]);

  const goTab = useCallback((tab: MainTab) => replaceRoute(routeForTab(tab)), [replaceRoute]);

  const openIncomingCall = useCallback(async (call: CallDocument) => {
    const current = routeRef.current;
    if (current.name === 'activeCall' || (current.name === 'incomingCall' && current.call.id === call.id)) return;
    try {
      const caller = await getApprovedUser(call.callerId);
      if (!caller) return;
      pushRoute({ name: 'incomingCall', call, person: caller });
    } catch {
      // The authenticated call listener will retry when Firestore reconnects.
    }
  }, [pushRoute]);

  const handleNotificationData = useCallback(async (data: Record<string, unknown>) => {
    if (!unlocked) {
      deferredNotificationRef.current = data;
      return;
    }
    const kind = typeof data.kind === 'string' ? data.kind : '';
    if (kind === 'call' && typeof data.callId === 'string') {
      const call = await getCall(data.callId).catch(() => null);
      if (call?.status === 'ringing') await openIncomingCall(call);
      return;
    }
    if (kind === 'message' && typeof data.chatId === 'string') {
      const chat = await getChatById(data.chatId).catch(() => null);
      if (!chat || !authState.user) return;
      const otherUid = chat.participantIds.find(uid => uid !== authState.user?.uid);
      if (!otherUid) return;
      const person = await getApprovedUser(otherUid).catch(() => null);
      if (person) pushRoute({ name: 'chat', chat, person });
    }
  }, [authState.user, openIncomingCall, pushRoute, unlocked]);

  const unlock = useCallback(() => {
    setUnlocked(true);
    if (!firebaseReady) replaceRoute({ name: 'login' });
    else if (authState.ready && authState.user) {
      const destination = postAuthDestination({
        hasProfile: Boolean(authState.profile),
        ...(authState.profile ? { status: authState.profile.status, accountDisabled: authState.profile.accountDisabled } : {})
      });
      if (destination === 'chats') replaceRoute({ name: 'chats' });
      else if (destination === 'disabled') replaceRoute({ name: 'login' });
      else replaceRoute({ name: 'pending' });
    } else replaceRoute({ name: 'login' });
  }, [authState, replaceRoute]);

  useEffect(() => {
    if (!unlocked || !authState.ready) return;
    if (authState.user) {
      const destination = postAuthDestination({
        hasProfile: Boolean(authState.profile),
        ...(authState.profile ? { status: authState.profile.status, accountDisabled: authState.profile.accountDisabled } : {})
      });
      if (destination === 'disabled') {
        clearPrivateMediaCache();
        if (authState.user) void unregisterPushNotifications(authState.user.uid).catch(() => undefined);
        void logout().catch(() => undefined);
        setUnlocked(false);
        replaceRoute({ name: 'calculator' });
        return;
      }
      if (destination === 'pending' || destination === 'profile-required') {
        if (routeRef.current.name === 'login' || routeRef.current.name === 'register' || routeRef.current.name === 'chats' || isProtectedRoute(routeRef.current)) replaceRoute({ name: 'pending' });
        return;
      }
      if (routeRef.current.name === 'login' || routeRef.current.name === 'register' || routeRef.current.name === 'pending') replaceRoute({ name: 'chats' });
    } else if (isProtectedRoute(routeRef.current)) {
      replaceRoute({ name: 'login' });
    }
  }, [authState, replaceRoute, unlocked]);

  useEffect(() => {
    if (!authState.user || authState.profile?.status !== 'approved' || authState.profile.accountDisabled || !realtimeDatabase) return;
    return connectPresence(authState.user.uid);
  }, [authState.user?.uid, authState.profile?.status, authState.profile?.accountDisabled]);

  useEffect(() => {
    installNotificationPresentation();
    if (!authState.user || authState.profile?.status !== 'approved' || authState.profile.accountDisabled) return;
    const uid = authState.user.uid;
    void refreshPushTokenIfGranted(uid).catch(() => undefined);
    void getInitialNotificationData().then(data => { if (data) void handleNotificationData(data); }).catch(() => undefined);
    const unsubscribeTap = addNotificationTapListener(data => { void handleNotificationData(data); });
    const unsubscribeTokenRefresh = subscribePushTokenRefresh(uid);
    return () => { unsubscribeTap(); unsubscribeTokenRefresh(); };
  }, [authState.user?.uid, authState.profile?.status, authState.profile?.accountDisabled, handleNotificationData]);

  useEffect(() => {
    if (!unlocked || !deferredNotificationRef.current) return;
    const data = deferredNotificationRef.current;
    deferredNotificationRef.current = null;
    void handleNotificationData(data);
  }, [handleNotificationData, unlocked]);

  useEffect(() => {
    if (!authState.user || authState.profile?.status !== 'approved' || authState.profile.accountDisabled) return;
    return subscribeIncomingCalls(authState.user.uid, calls => {
      const current = routeRef.current;
      if (calls.length > 0) {
        const incoming = calls[0];
        if (incoming) void openIncomingCall(incoming);
      } else if (current.name === 'incomingCall' && !acceptingCallRef.current) {
        goBack();
      }
    }, () => undefined);
  }, [authState.user?.uid, authState.profile?.status, authState.profile?.accountDisabled, goBack, openIncomingCall]);

  useEffect(() => {
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      const current = routeRef.current;
      if (current.name === 'calculator') return false;
      if (current.name === 'activeCall') void current.controller.end('ended');
      goBack();
      return true;
    });
    return () => listener.remove();
  }, [goBack]);

  const startCall = useCallback(async (person: UserProfile, mediaType: CallMediaType) => {
    if (callStarting || !authState.user) return;
    setCallStarting(true);
    try {
      const controller = await startOutgoingCall({ callerId: authState.user.uid, calleeId: person.uid, mediaType });
      pushRoute({ name: 'activeCall', controller, person });
    } catch (error) {
      Alert.alert('Call could not start', error instanceof Error ? error.message : 'Check Firebase, call permissions, and TURN setup.');
    } finally { setCallStarting(false); }
  }, [authState.user, callStarting, pushRoute]);

  const openChatWith = useCallback(async (person: UserProfile) => {
    if (!authState.user) return;
    try {
      const chatId = await getOrCreateDirectChat(authState.user.uid, person.uid);
      const chat = await getChatById(chatId);
      if (!chat) throw new Error('Conversation could not be opened.');
      pushRoute({ name: 'chat', chat, person });
    } catch (error) {
      Alert.alert('Could not open conversation', error instanceof Error ? error.message : 'Please reconnect and try again.');
    }
  }, [authState.user, pushRoute]);

  const signOutAndLock = useCallback(async () => {
    setLogoutBusy(true);
    try {
      const current = routeRef.current;
      if (current.name === 'activeCall') await current.controller.end('ended');
      clearPrivateMediaCache();
      if (authState.user) void unregisterPushNotifications(authState.user.uid).catch(() => undefined);
      await logout();
      setUnlocked(false);
      replaceRoute({ name: 'calculator' });
    } catch (error) {
      Alert.alert('Could not log out', error instanceof Error ? error.message : 'Please try again.');
    } finally { setLogoutBusy(false); }
  }, [authState.user, replaceRoute]);

  const enableNotifications = useCallback(async () => {
    if (!authState.user) throw new Error('Sign in first.');
    const result = await registerPushNotifications(authState.user.uid);
    setNotificationEnabled(result.enabled);
    if (!result.enabled) throw new Error(result.message);
  }, [authState.user]);

  const tab = (value: MainTab) => goTab(value);

  let screen;
  if (route.name === 'calculator') screen = <CalculatorScreen onUnlocked={unlock} />;
  else if (route.name === 'login') screen = <LoginScreen configured={firebaseReady} onLogin={async (email, password) => { await signIn(email, password); }} onRegister={() => pushRoute({ name: 'register' })} />;
  else if (route.name === 'register') screen = <RegisterScreen configured={firebaseReady} onBack={goBack} onRegister={async input => { await registerPendingAccount(input); }} />;
  else if (route.name === 'pending') screen = <PendingApprovalScreen profile={authState.profile} onBack={() => { setUnlocked(false); replaceRoute({ name: 'calculator' }); }} onSignOut={() => void signOutAndLock()} />;
  else if (route.name === 'chats' && authState.user && authState.profile) screen = <ChatListScreen uid={authState.user.uid} profile={authState.profile} connected={connected} onTab={tab} onContacts={() => pushRoute({ name: 'contacts', embedded: true })} onOpenChat={(chat, person) => pushRoute({ name: 'chat', chat, person })} />;
  else if (route.name === 'calls' && authState.user) screen = <CallHistoryScreen uid={authState.user.uid} onTab={tab} onCall={(person, mediaType) => void startCall(person, mediaType)} />;
  else if (route.name === 'contacts' && authState.user) screen = <ContactsScreen uid={authState.user.uid} embedded={route.embedded} onBack={goBack} onTab={tab} onSelect={person => void openChatWith(person)} />;
  else if (route.name === 'profile' && authState.user && authState.profile) screen = <ProfileScreen uid={authState.user.uid} email={authState.user.email ?? ''} profile={authState.profile} onTab={tab} onPrivacy={() => pushRoute({ name: 'privacy' })} onAdmin={() => pushRoute({ name: 'admin' })} onLogout={() => pushRoute({ name: 'logout' })} />;
  else if (route.name === 'privacy') screen = <PrivacyScreen onBack={goBack} onEnableNotifications={enableNotifications} notificationsEnabled={notificationEnabled} />;
  else if (route.name === 'admin') screen = <AdminScreen onBack={goBack} />;
  else if (route.name === 'logout') screen = <LogoutScreen onCancel={goBack} onConfirm={() => void signOutAndLock()} loading={logoutBusy} />;
  else if (route.name === 'chat' && authState.user) screen = <ChatScreen uid={authState.user.uid} chat={route.chat} person={route.person} onBack={goBack} onCall={type => void startCall(route.person, type)} onPreview={storagePath => pushRoute({ name: 'image', storagePath })} connected={connected} />;
  else if (route.name === 'image') screen = <ImagePreviewScreen storagePath={route.storagePath} onBack={goBack} />;
  else if (route.name === 'incomingCall') screen = <IncomingCallScreen call={route.call} person={route.person} onAccept={async () => {
    acceptingCallRef.current = true;
    try {
      const controller = await acceptIncomingCall({ callId: route.call.id, currentUid: authState.user?.uid ?? '' });
      pushRoute({ name: 'activeCall', controller, person: route.person });
    } finally { acceptingCallRef.current = false; }
  }} onDecline={async () => { await declineIncomingCall(route.call.id); goBack(); }} />;
  else if (route.name === 'activeCall') screen = <ActiveCallScreen controller={route.controller} person={route.person} onFinished={goBack} />;
  else screen = <AppScreen><View /></AppScreen>;

  return <><StatusBar style="light" />{screen}</>;
}

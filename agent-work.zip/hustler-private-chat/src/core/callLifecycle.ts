export type LifecycleStatus = 'ringing' | 'connecting' | 'active' | 'ended' | 'declined' | 'missed' | 'failed';

const transitions: Record<LifecycleStatus, readonly LifecycleStatus[]> = {
  ringing: ['connecting', 'ended', 'declined', 'missed', 'failed'],
  connecting: ['active', 'ended', 'failed'],
  active: ['ended', 'failed'],
  ended: [],
  declined: [],
  missed: [],
  failed: []
};

export function canTransitionCallStatus(from: LifecycleStatus, to: LifecycleStatus): boolean {
  return transitions[from].includes(to);
}

export function isTerminalCallStatus(status: LifecycleStatus): boolean {
  return transitions[status].length === 0;
}

export interface ReleasableTrack { stop(): void }
export interface ReleasableStream { getTracks(): ReleasableTrack[] }
export interface ReleasablePeer { close(): void }

export async function releaseCallResources(input: {
  streams?: Array<ReleasableStream | null | undefined>;
  peer?: ReleasablePeer | null;
  unsubscribers?: Array<(() => void) | null | undefined>;
  removeCandidates?: (() => Promise<void>) | null;
}): Promise<void> {
  for (const unsubscribe of input.unsubscribers ?? []) {
    try { unsubscribe?.(); } catch { /* best-effort cleanup */ }
  }
  for (const stream of input.streams ?? []) {
    try {
      for (const track of stream?.getTracks() ?? []) {
        try { track.stop(); } catch { /* continue releasing remaining tracks */ }
      }
    } catch { /* a partially released native stream must not block cleanup */ }
  }
  try { input.peer?.close(); } catch { /* continue cleanup */ }
  try { await input.removeCandidates?.(); } catch { /* candidates can be swept by server cleanup */ }
}

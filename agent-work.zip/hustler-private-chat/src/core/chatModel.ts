import type { MessageDocument, MessageType } from '@/types/models';

export function directChatId(firstUid: string, secondUid: string): string {
  if (!firstUid || !secondUid || firstUid === secondUid) throw new Error('A direct chat needs two different users.');
  return [firstUid, secondUid].sort().join('__');
}

export function messagePreview(input: { type: MessageType; text?: string | null }): string {
  if (input.type === 'image') return 'Photo';
  if (input.type === 'audio') return 'Voice message';
  return (input.text ?? '').trim().slice(0, 160);
}

export function receiptLabel(message: Pick<MessageDocument, 'senderId' | 'deliveredTo' | 'readBy'>, currentUid: string): 'sent' | 'delivered' | 'read' | null {
  if (message.senderId !== currentUid) return null;
  if (message.readBy.some(uid => uid !== currentUid)) return 'read';
  if (message.deliveredTo.some(uid => uid !== currentUid)) return 'delivered';
  return 'sent';
}

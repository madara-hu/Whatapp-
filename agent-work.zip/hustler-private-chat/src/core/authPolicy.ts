import type { AccountStatus } from '@/types/models';

export type PostAuthDestination = 'pending' | 'disabled' | 'profile-required' | 'chats';

export function postAuthDestination(input: {
  hasProfile: boolean;
  status?: AccountStatus;
  accountDisabled?: boolean;
}): PostAuthDestination {
  if (!input.hasProfile) return 'profile-required';
  if (input.accountDisabled || input.status === 'disabled') return 'disabled';
  if (input.status !== 'approved') return 'pending';
  return 'chats';
}

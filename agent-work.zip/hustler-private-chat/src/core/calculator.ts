export type CalculatorOperator = '+' | '-' | '*' | '/' | '(' | ')';
type Token = number | CalculatorOperator;

export class CalculatorError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CalculatorError';
  }
}

export function normalizeExpression(expression: string): string {
  return expression
    .replace(/[×✕]/g, '*')
    .replace(/[÷]/g, '/')
    .replace(/[−–]/g, '-')
    .replace(/\s+/g, '');
}

export function isUnlockExpression(expression: string, configuredExpression: string): boolean {
  const entered = normalizeExpression(expression);
  const configured = normalizeExpression(configuredExpression);
  return entered.length > 0 && entered === configured;
}

function tokenize(expression: string): Token[] {
  const source = normalizeExpression(expression);
  if (!source) throw new CalculatorError('Enter a calculation first.');
  if (source.length > 160) throw new CalculatorError('That calculation is too long.');

  const tokens: Token[] = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (character === undefined) break;
    if (/[0-9.]/.test(character)) {
      const start = index;
      let decimalPoints = 0;
      while (index < source.length && /[0-9.]/.test(source[index] ?? '')) {
        if (source[index] === '.') decimalPoints += 1;
        if (decimalPoints > 1) throw new CalculatorError('Check the decimal point.');
        index += 1;
      }
      const raw = source.slice(start, index);
      if (raw === '.') throw new CalculatorError('Enter a number.');
      const value = Number(raw);
      if (!Number.isFinite(value)) throw new CalculatorError('That number is out of range.');
      tokens.push(value);
      continue;
    }
    if (character === '+' || character === '-' || character === '*' || character === '/' || character === '(' || character === ')') {
      tokens.push(character);
      index += 1;
      continue;
    }
    throw new CalculatorError('Only numbers and basic operators are allowed.');
  }
  return tokens;
}

class Parser {
  private position = 0;
  private depth = 0;

  constructor(private readonly tokens: Token[]) {}

  parse(): number {
    const result = this.parseAdditive();
    if (this.position !== this.tokens.length) throw new CalculatorError('Check the expression.');
    if (!Number.isFinite(result)) throw new CalculatorError('The result is out of range.');
    return Object.is(result, -0) ? 0 : result;
  }

  private peek(): Token | undefined {
    return this.tokens[this.position];
  }

  private consume(): Token | undefined {
    const token = this.peek();
    if (token !== undefined) this.position += 1;
    return token;
  }

  private parseAdditive(): number {
    let value = this.parseMultiplicative();
    while (this.peek() === '+' || this.peek() === '-') {
      const operator = this.consume();
      const right = this.parseMultiplicative();
      value = operator === '+' ? value + right : value - right;
      if (!Number.isFinite(value)) throw new CalculatorError('The result is out of range.');
    }
    return value;
  }

  private parseMultiplicative(): number {
    let value = this.parseUnary();
    while (this.peek() === '*' || this.peek() === '/') {
      const operator = this.consume();
      const right = this.parseUnary();
      if (operator === '/') {
        if (right === 0) throw new CalculatorError('Cannot divide by zero.');
        value /= right;
      } else {
        value *= right;
      }
      if (!Number.isFinite(value)) throw new CalculatorError('The result is out of range.');
    }
    return value;
  }

  private parseUnary(): number {
    const operator = this.peek();
    if (operator === '+' || operator === '-') {
      this.consume();
      const value = this.parseUnary();
      return operator === '-' ? -value : value;
    }
    return this.parsePrimary();
  }

  private parsePrimary(): number {
    const token = this.consume();
    if (typeof token === 'number') return token;
    if (token === '(') {
      this.depth += 1;
      if (this.depth > 32) throw new CalculatorError('Too many nested parentheses.');
      const value = this.parseAdditive();
      if (this.consume() !== ')') throw new CalculatorError('A closing parenthesis is missing.');
      this.depth -= 1;
      return value;
    }
    throw new CalculatorError('The expression is incomplete.');
  }
}

/** Safe recursive-descent evaluator. It never executes JavaScript source. */
export function evaluateExpression(expression: string): number {
  return new Parser(tokenize(expression)).parse();
}

export type EqualsOutcome = { kind: 'unlock' } | { kind: 'result'; value: number };

/** Checks the unlock condition before doing ordinary calculator work. */
export function calculateOrUnlock(expression: string, configuredExpression: string): EqualsOutcome {
  if (isUnlockExpression(expression, configuredExpression)) return { kind: 'unlock' };
  return { kind: 'result', value: evaluateExpression(expression) };
}

export function formatCalculatorNumber(value: number): string {
  if (!Number.isFinite(value)) throw new CalculatorError('The result is out of range.');
  const normalized = Object.is(value, -0) ? 0 : value;
  if (Number.isInteger(normalized) && Math.abs(normalized) < 1e15) return String(normalized);
  return normalized.toFixed(10).replace(/(?:\.0+|(?:(\.\d*?)0+))$/, '$1');
}

import type { Timestamp } from 'firebase/firestore';

export type AccountStatus = 'pending' | 'approved' | 'disabled';
export type AccountRole = 'member' | 'admin';
export type PresenceState = 'online' | 'offline';
export type MessageType = 'text' | 'image' | 'audio';
export type CallMediaType = 'audio' | 'video';
export type CallStatus = 'ringing' | 'connecting' | 'active' | 'ended' | 'declined' | 'missed' | 'failed';

export interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  about: string;
  photoPath: string | null;
  status: AccountStatus;
  role: AccountRole;
  accountDisabled: boolean;
  presence: PresenceState;
  lastSeenAt: Timestamp | null;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface ChatDocument {
  id: string;
  participantIds: string[];
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
  lastMessageAt: Timestamp | null;
  lastMessageId: string | null;
  lastMessagePreview: string;
  lastSenderId: string | null;
  unreadCounts: Record<string, number>;
}

export interface MessageDocument {
  id: string;
  senderId: string;
  type: MessageType;
  text: string | null;
  storagePath: string | null;
  mediaMimeType: string | null;
  durationMs: number | null;
  createdAt: Timestamp | null;
  deliveredTo: string[];
  readBy: string[];
}

export interface TypingState {
  uid: string;
  isTyping: boolean;
  updatedAt: Timestamp | null;
}

export interface CallDescription {
  type: 'offer' | 'answer';
  sdp: string;
}

export interface CallDocument {
  id: string;
  callerId: string;
  calleeId: string;
  participantIds: string[];
  mediaType: CallMediaType;
  status: CallStatus;
  offer: CallDescription | null;
  answer: CallDescription | null;
  createdAt: Timestamp | null;
  answeredAt: Timestamp | null;
  endedAt: Timestamp | null;
  durationSeconds: number | null;
}

export type MainTab = 'chats' | 'calls' | 'contacts' | 'profile';

import { Image, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, IconButton } from '@/components/Primitives';
import { theme } from '@/config/theme';
import { usePrivateMedia } from '@/hooks/usePrivateMedia';

export function ImagePreviewScreen({ storagePath, onBack }: { storagePath: string; onBack: () => void }) {
  const image = usePrivateMedia(storagePath, 'image/jpeg');
  return (
    <AppScreen style={styles.screen}>
      <View style={styles.header}><IconButton name="close" onPress={onBack} background="#0B2223" /><Text style={styles.title}>Photo preview</Text><View style={{ width: 42 }} /></View>
      <View style={styles.imageWrap}>{image ? <Image source={{ uri: image }} resizeMode="contain" style={styles.image} /> : <View style={styles.loading}><Ionicons name="image-outline" size={26} color={theme.colors.teal} /><Text style={styles.loadingText}>Loading protected media…</Text></View>}</View>
      <Text style={styles.caption}>Media is fetched through authenticated Firebase Storage access.</Text>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 8, paddingBottom: 18 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 48 },
  title: { color: theme.colors.text, fontSize: 15, fontWeight: '700' },
  imageWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#010B0C', borderRadius: 20, overflow: 'hidden', marginTop: 10 },
  image: { width: '100%', height: '100%' },
  loading: { alignItems: 'center', gap: 9 },
  loadingText: { color: theme.colors.textMuted, fontSize: 12 },
  caption: { color: theme.colors.textMuted, fontSize: 10, textAlign: 'center', marginTop: 10 }
});

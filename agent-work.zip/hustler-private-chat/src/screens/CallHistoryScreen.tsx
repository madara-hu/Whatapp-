import { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { BottomTabs } from '@/components/BottomTabs';
import { theme } from '@/config/theme';
import { getApprovedUser } from '@/services/chatService';
import { subscribeCallHistory } from '@/services/callService';
import type { CallDocument, CallMediaType, MainTab, UserProfile } from '@/types/models';

function callTime(value: CallDocument['createdAt']): string {
  if (!value) return '';
  const date = value.toDate();
  const today = new Date();
  return date.toDateString() === today.toDateString()
    ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    : date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function durationText(duration: number | null): string {
  if (duration === null) return '';
  if (duration < 60) return `${duration}s`;
  return `${Math.floor(duration / 60)}m ${String(duration % 60).padStart(2, '0')}s`;
}

export function CallHistoryScreen({ uid, onTab, onCall }: { uid: string; onTab: (tab: MainTab) => void; onCall: (person: UserProfile, mediaType: CallMediaType) => void }) {
  const [calls, setCalls] = useState<CallDocument[]>([]);
  const [people, setPeople] = useState<Record<string, UserProfile>>({});
  const [error, setError] = useState('');
  useEffect(() => subscribeCallHistory(uid, setCalls, caught => setError(caught.message)), [uid]);
  useEffect(() => {
    let live = true;
    const ids = [...new Set(calls.map(call => call.participantIds.find(id => id !== uid)).filter((id): id is string => Boolean(id)))];
    void Promise.all(ids.map(async id => [id, await getApprovedUser(id)] as const)).then(results => {
      if (!live) return;
      setPeople(previous => {
        const next = { ...previous };
        results.forEach(([id, person]) => { if (person) next[id] = person; });
        return next;
      });
    }).catch(() => undefined);
    return () => { live = false; };
  }, [calls, uid]);

  const rows = useMemo(() => calls.filter(call => people[call.participantIds.find(id => id !== uid) ?? '']), [calls, people, uid]);
  return (
    <AppScreen style={styles.screen}>
      <View style={styles.heading}><Text style={styles.title}>Calls</Text><Text style={styles.subtitle}>Voice and video history</Text></View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {rows.length === 0 ? <View style={styles.empty}><View style={styles.emptyIcon}><Ionicons name="call-outline" size={25} color={theme.colors.teal} /></View><Text style={styles.emptyTitle}>No calls yet</Text><Text style={styles.emptyText}>Calls with approved HUSTLER contacts will appear here.</Text></View> : (
        <FlatList data={rows} keyExtractor={item => item.id} contentContainerStyle={{ paddingBottom: 8 }} renderItem={({ item }) => {
          const otherUid = item.participantIds.find(id => id !== uid) ?? '';
          const person = people[otherUid];
          if (!person) return null;
          const outbound = item.callerId === uid;
          const icon = item.mediaType === 'video' ? 'videocam' : 'call';
          const statusLabel = item.status === 'missed' ? 'Missed' : item.status === 'declined' ? (outbound ? 'Declined' : 'Declined by you') : item.status === 'failed' ? 'Failed' : item.status === 'ringing' ? (outbound ? 'Outgoing' : 'Incoming') : outbound ? 'Outgoing' : 'Incoming';
          const color = item.status === 'missed' || item.status === 'failed' ? theme.colors.danger : theme.colors.teal;
          return (
            <View style={styles.callRow}>
              <Avatar name={person.displayName} photoPath={person.photoPath} size={48} online={person.presence === 'online'} />
              <View style={{ flex: 1 }}><Text style={styles.personName}>{person.displayName}</Text><View style={styles.callMeta}><Ionicons name={outbound ? 'arrow-up' : 'arrow-down'} size={13} color={color} /><Text style={[styles.callStatus, { color }]}>{statusLabel} · {item.mediaType}</Text><Text style={styles.time}>· {callTime(item.createdAt)}{item.durationSeconds !== null ? ` · ${durationText(item.durationSeconds)}` : ''}</Text></View></View>
              <Pressable onPress={() => onCall(person, item.mediaType)} style={styles.callAgain}><Ionicons name={icon} size={18} color={theme.colors.teal} /></Pressable>
            </View>
          );
        }} />
      )}
      <BottomTabs active="calls" onChange={onTab} />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 12, paddingBottom: 2 },
  heading: { marginBottom: 22 },
  title: { color: theme.colors.text, fontSize: 27, fontWeight: '800' },
  subtitle: { color: theme.colors.textMuted, fontSize: 12, marginTop: 4 },
  callRow: { minHeight: 75, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft },
  personName: { color: theme.colors.text, fontSize: 14, fontWeight: '700' },
  callMeta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 5, flexWrap: 'wrap' },
  callStatus: { fontSize: 10, textTransform: 'capitalize' },
  time: { color: theme.colors.textMuted, fontSize: 9 },
  callAgain: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#113734', alignItems: 'center', justifyContent: 'center' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
  emptyIcon: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#103734', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  emptyTitle: { color: theme.colors.text, fontSize: 18, fontWeight: '800' },
  emptyText: { color: theme.colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: 'center', marginTop: 7 },
  error: { color: theme.colors.danger, fontSize: 12 }
});

import { useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, ScreenHeader } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { BottomTabs } from '@/components/BottomTabs';
import { theme } from '@/config/theme';
import { getApprovedContacts } from '@/services/chatService';
import type { MainTab, UserProfile } from '@/types/models';

export function ContactsScreen({
  uid,
  onBack,
  onTab,
  onSelect,
  embedded = false
}: {
  uid: string;
  onBack: () => void;
  onTab: (tab: MainTab) => void;
  onSelect: (user: UserProfile) => void;
  embedded?: boolean;
}) {
  const [contacts, setContacts] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let live = true;
    void getApprovedContacts(uid).then(value => {
      if (live) setContacts(value);
    }).catch(caught => {
      if (live) setError(caught instanceof Error ? caught.message : 'Could not load approved contacts.');
    }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [uid]);

  const filtered = contacts.filter(person => `${person.displayName} ${person.username}`.toLowerCase().includes(search.toLowerCase().trim()));

  return (
    <AppScreen style={styles.screen}>
      {embedded ? <ScreenHeader title="New conversation" onBack={onBack} /> : (
        <View style={styles.titleRow}><View><Text style={styles.title}>People</Text><Text style={styles.subtitle}>Approved HUSTLER accounts</Text></View></View>
      )}
      <View style={styles.search}><Ionicons name="search-outline" size={18} color={theme.colors.textMuted} /><TextInput value={search} onChangeText={setSearch} placeholder="Search people" placeholderTextColor={theme.colors.textMuted} style={styles.searchInput} /></View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {loading ? <View style={styles.center}><Text style={styles.muted}>Loading approved contacts…</Text></View> : filtered.length === 0 ? (
        <View style={styles.center}><View style={styles.emptyIcon}><Ionicons name="people-outline" size={25} color={theme.colors.teal} /></View><Text style={styles.emptyTitle}>{search ? 'No one found' : 'No approved contacts yet'}</Text><Text style={styles.mutedCenter}>{search ? 'Try a different search.' : 'Ask the HUSTLER administrator to approve both accounts first.'}</Text></View>
      ) : (
        <FlatList data={filtered} keyExtractor={item => item.uid} contentContainerStyle={{ paddingBottom: 12 }} renderItem={({ item }) => (
          <Pressable onPress={() => onSelect(item)} style={({ pressed }) => [styles.personRow, pressed && { opacity: 0.7 }]}>
            <Avatar name={item.displayName} photoPath={item.photoPath} size={50} online={item.presence === 'online'} />
            <View style={{ flex: 1 }}><Text style={styles.personName}>{item.displayName || item.username}</Text><Text style={styles.personSub}>@{item.username} · {item.presence === 'online' ? 'Online' : 'Approved contact'}</Text></View>
            <Ionicons name="chatbubble-ellipses-outline" size={19} color={theme.colors.teal} />
          </Pressable>
        )} />
      )}
      {!embedded ? <BottomTabs active="contacts" onChange={onTab} /> : null}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 12 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  title: { color: theme.colors.text, fontSize: 27, fontWeight: '800' },
  subtitle: { color: theme.colors.textMuted, fontSize: 12, marginTop: 4 },
  search: { height: 48, borderRadius: 15, backgroundColor: theme.colors.surface, borderColor: theme.colors.border, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 9, marginBottom: 15 },
  searchInput: { flex: 1, color: theme.colors.text, fontSize: 14 },
  personRow: { minHeight: 74, alignItems: 'center', flexDirection: 'row', gap: 12, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft },
  personName: { color: theme.colors.text, fontSize: 14, fontWeight: '700' },
  personSub: { color: theme.colors.textMuted, fontSize: 11, marginTop: 4 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 26 },
  muted: { color: theme.colors.textMuted, fontSize: 13 },
  mutedCenter: { color: theme.colors.textMuted, fontSize: 12, textAlign: 'center', lineHeight: 18, marginTop: 7, maxWidth: 280 },
  emptyIcon: { width: 62, height: 62, borderRadius: 31, backgroundColor: '#103734', alignItems: 'center', justifyContent: 'center', marginBottom: 17 },
  emptyTitle: { color: theme.colors.text, fontSize: 17, fontWeight: '800' },
  error: { color: theme.colors.danger, fontSize: 12, marginVertical: 10 }
});

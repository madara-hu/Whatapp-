import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type ListRenderItemInfo
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioPlayer, useAudioRecorder } from 'expo-audio';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, ErrorNotice, IconButton } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { theme } from '@/config/theme';
import { receiptLabel } from '@/core/chatModel';
import { loadOlderMessages, markChatRead, sendMessage, setTyping, subscribeLatestMessages, subscribeTyping, type MessagePage } from '@/services/chatService';
import { uploadChatMedia } from '@/services/mediaService';
import type { ChatDocument, MessageDocument, UserProfile } from '@/types/models';

function timeLabel(value: MessageDocument['createdAt']): string {
  if (!value) return 'Sending…';
  return value.toDate().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function timestampNumber(message: MessageDocument): number {
  return message.createdAt?.toMillis() ?? 0;
}

function AudioMessage({ path, mimeType, mine }: { path: string; mimeType: string; mine: boolean }) {
  const [uri, setUri] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    let live = true;
    void import('@/services/mediaService').then(({ loadPrivateMediaDataUri }) => loadPrivateMediaDataUri(path, mimeType)).then(value => { if (live) setUri(value); }).catch(() => undefined);
    return () => { live = false; };
  }, [path, mimeType]);
  const player = useAudioPlayer(uri ? { uri } : null);
  const toggle = () => {
    if (!uri) return;
    if (playing) { player.pause(); setPlaying(false); }
    else { player.play(); setPlaying(true); }
  };
  return (
    <Pressable onPress={toggle} style={styles.audioBubble}>
      <View style={[styles.audioPlay, mine && styles.audioPlayMine]}><Ionicons name={playing ? 'pause' : 'play'} size={16} color={mine ? theme.colors.backgroundDeep : theme.colors.teal} /></View>
      <View style={styles.audioTrack}><View style={[styles.audioTrackFill, mine && styles.audioTrackFillMine]} /><Text style={[styles.audioLabel, mine && styles.audioLabelMine]}>{uri ? (playing ? 'Playing voice message' : 'Voice message') : 'Loading voice message…'}</Text></View>
    </Pressable>
  );
}

function MessageBubble({ message, uid, onPreview }: { message: MessageDocument; uid: string; onPreview: (storagePath: string) => void }) {
  const mine = message.senderId === uid;
  const receipt = receiptLabel(message, uid);
  const imageUri = usePrivateMediaUri(message.type === 'image' ? message.storagePath : null, message.mediaMimeType ?? 'image/jpeg');
  return (
    <View style={[styles.messageLine, mine ? styles.messageMine : styles.messageTheirs]}>
      <View style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleTheirs]}>
        {message.type === 'image' && message.storagePath ? (
          <Pressable onPress={() => onPreview(message.storagePath ?? '')} style={styles.imageMessage}>
            {imageUri ? <Image source={{ uri: imageUri }} resizeMode="cover" style={styles.messageImage} /> : <View style={styles.imagePlaceholder}><Ionicons name="image-outline" size={22} color={theme.colors.teal} /><Text style={styles.placeholderText}>Protected photo</Text></View>}
            {message.text ? <Text style={[styles.caption, mine && styles.captionMine]}>{message.text}</Text> : null}
          </Pressable>
        ) : message.type === 'audio' && message.storagePath ? (
          <AudioMessage path={message.storagePath} mimeType={message.mediaMimeType ?? 'audio/mp4'} mine={mine} />
        ) : <Text style={[styles.messageText, mine && styles.messageTextMine]}>{message.text ?? ''}</Text>}
        <View style={styles.metaRow}><Text style={[styles.messageTime, mine && styles.messageTimeMine]}>{timeLabel(message.createdAt)}</Text>{mine ? <Ionicons name={receipt === 'read' ? 'checkmark-done' : 'checkmark-done'} size={14} color={receipt === 'read' ? '#80F4E0' : '#A7D6CF'} /> : null}</View>
      </View>
    </View>
  );
}

function usePrivateMediaUri(path: string | null, mimeType = 'image/jpeg'): string | null {
  const [uri, setUri] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    setUri(null);
    if (path) void import('@/services/mediaService').then(({ loadPrivateMediaDataUri }) => loadPrivateMediaDataUri(path, mimeType)).then(value => { if (live) setUri(value); }).catch(() => undefined);
    return () => { live = false; };
  }, [path, mimeType]);
  return uri;
}

export function ChatScreen({
  uid,
  chat,
  person,
  onBack,
  onCall,
  onPreview,
  connected
}: {
  uid: string;
  chat: ChatDocument;
  person: UserProfile;
  onBack: () => void;
  onCall: (type: 'audio' | 'video') => void;
  onPreview: (path: string) => void;
  connected: boolean | null;
}) {
  const [messages, setMessages] = useState<MessageDocument[]>([]);
  const [typingNames, setTypingNames] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const [recording, setRecording] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const cursor = useRef<MessagePage['cursor']>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recordingStarted = useRef(0);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);

  useEffect(() => {
    return subscribeLatestMessages(chat.id, page => {
      cursor.current = page.cursor;
      setHasMore(page.hasMore);
      setMessages(previous => {
        const merged = new Map<string, MessageDocument>();
        [...page.messages, ...previous].forEach(message => merged.set(message.id, message));
        return [...merged.values()].sort((a, b) => timestampNumber(b) - timestampNumber(a));
      });
      void markChatRead(chat.id, uid, page.messages).catch(() => undefined);
    }, caught => setError(caught.message));
  }, [chat.id, uid]);

  useEffect(() => subscribeTyping(chat.id, uid, values => {
    setTypingNames(values.some(item => item.isTyping) ? [person.displayName || person.username] : []);
  }), [chat.id, uid, person.displayName, person.username]);

  useEffect(() => () => {
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    void setTyping(chat.id, uid, false).catch(() => undefined);
  }, [chat.id, uid]);

  const onInput = (value: string) => {
    setInput(value);
    const next = value.trim().length > 0;
    void setTyping(chat.id, uid, next).catch(() => undefined);
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    if (next) typingTimeout.current = setTimeout(() => { void setTyping(chat.id, uid, false).catch(() => undefined); }, 1800);
  };

  const submitText = async () => {
    const text = input.trim();
    if (!text || sending) return;
    setInput(''); setError(''); setSending(true);
    void setTyping(chat.id, uid, false).catch(() => undefined);
    try { await sendMessage({ chatId: chat.id, senderId: uid, recipientId: person.uid, type: 'text', text }); }
    catch (caught) { setInput(text); setError(caught instanceof Error ? caught.message : 'Message could not be sent.'); }
    finally { setSending(false); }
  };

  const sendPhoto = async () => {
    if (sending) return;
    setError('');
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) throw new Error('Photo library permission was not granted.');
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: false, quality: 0.82 });
      if (result.canceled || !result.assets[0]) return;
      setSending(true);
      const asset = result.assets[0];
      const uploaded = await uploadChatMedia({ chatId: chat.id, uid, uri: asset.uri, kind: 'image', mimeType: asset.mimeType ?? 'image/jpeg' });
      await sendMessage({ chatId: chat.id, senderId: uid, recipientId: person.uid, type: 'image', storagePath: uploaded.storagePath, mediaMimeType: asset.mimeType ?? 'image/jpeg' });
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Photo could not be sent.'); }
    finally { setSending(false); }
  };

  const toggleRecording = async () => {
    setError('');
    if (recording) {
      try {
        setRecording(false);
        await recorder.stop();
        const uri = recorder.uri;
        if (!uri) throw new Error('The voice recording was not saved.');
        const durationMs = Date.now() - recordingStarted.current;
        if (durationMs < 500) throw new Error('Record a little longer before sending.');
        setSending(true);
        const uploaded = await uploadChatMedia({ chatId: chat.id, uid, uri, kind: 'audio', mimeType: 'audio/mp4' });
        await sendMessage({ chatId: chat.id, senderId: uid, recipientId: person.uid, type: 'audio', storagePath: uploaded.storagePath, mediaMimeType: 'audio/mp4', durationMs });
      } catch (caught) { setError(caught instanceof Error ? caught.message : 'Voice message could not be sent.'); }
      finally { setSending(false); }
      return;
    }
    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) throw new Error('Microphone permission was not granted.');
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      recordingStarted.current = Date.now();
      setRecording(true);
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not start recording.'); }
  };

  const loadOlder = async () => {
    if (!cursor.current || loadingOlder || !hasMore) return;
    setLoadingOlder(true);
    try {
      const page = await loadOlderMessages(chat.id, cursor.current);
      cursor.current = page.cursor;
      setHasMore(page.hasMore);
      setMessages(previous => {
        const merged = new Map<string, MessageDocument>();
        [...previous, ...page.messages].forEach(message => merged.set(message.id, message));
        return [...merged.values()].sort((a, b) => timestampNumber(b) - timestampNumber(a));
      });
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not load older messages.'); }
    finally { setLoadingOlder(false); }
  };

  const typingLabel = typingNames.length > 0 ? `${person.displayName || person.username} is typing…` : connected === false ? 'Offline · messages will retry when reconnected' : person.presence === 'online' ? 'Online' : person.lastSeenAt ? `Last seen ${person.lastSeenAt.toDate().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : 'Private conversation';

  const renderMessage = useCallback(({ item }: ListRenderItemInfo<MessageDocument>) => <MessageBubble message={item} uid={uid} onPreview={onPreview} />, [uid, onPreview]);
  const listFooter = useMemo(() => loadingOlder ? <Text style={styles.loadingOlder}>Loading older messages…</Text> : null, [loadingOlder]);

  return (
    <AppScreen style={styles.screen}>
      <View style={styles.header}>
        <IconButton name="chevron-back" onPress={onBack} size={40} background="transparent" />
        <Avatar name={person.displayName} photoPath={person.photoPath} size={40} online={person.presence === 'online'} />
        <View style={styles.headerPerson}><Text numberOfLines={1} style={styles.personName}>{person.displayName || person.username}</Text><Text numberOfLines={1} style={styles.personStatus}>{typingNames.length ? `${person.displayName || person.username} is typing…` : person.presence === 'online' ? 'Online' : 'Private chat'}</Text></View>
        <IconButton name="videocam-outline" onPress={() => onCall('video')} color={theme.colors.text} background="transparent" size={38} />
        <IconButton name="call-outline" onPress={() => onCall('audio')} color={theme.colors.text} background="transparent" size={38} />
      </View>
      {connected === false ? <View style={styles.offlineBanner}><Ionicons name="cloud-offline-outline" size={14} color={theme.colors.warning} /><Text style={styles.offlineText}>Offline · pending writes will sync when available</Text></View> : null}
      {error ? <ErrorNotice text={error} /> : null}
      {messages.length === 0 ? <View style={styles.empty}><View style={styles.emptyLock}><Ionicons name="lock-closed-outline" size={21} color={theme.colors.teal} /></View><Text style={styles.emptyTitle}>Start a private conversation</Text><Text style={styles.emptyText}>Messages are saved to this approved Firebase conversation. This build does not currently provide end-to-end message encryption.</Text></View> : (
        <FlatList
          data={messages}
          inverted
          keyExtractor={item => item.id}
          renderItem={renderMessage}
          onEndReached={() => void loadOlder()}
          onEndReachedThreshold={0.25}
          ListFooterComponent={listFooter}
          contentContainerStyle={styles.messageList}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        />
      )}
      <Text numberOfLines={1} style={styles.typingLine}>{typingLabel}</Text>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={0}>
        <View style={styles.composer}>
          <IconButton name="add" onPress={() => void sendPhoto()} size={38} iconSize={21} background="transparent" color={theme.colors.textSecondary} disabled={sending} />
          <View style={styles.inputWrap}><TextInput value={input} onChangeText={onInput} placeholder="Message privately…" placeholderTextColor={theme.colors.textMuted} style={styles.input} multiline maxLength={4000} editable={!sending && !recording} onSubmitEditing={() => void submitText()} /></View>
          {input.trim() ? <Pressable onPress={() => void submitText()} disabled={sending} style={styles.sendButton}><Ionicons name="arrow-up" size={20} color={theme.colors.backgroundDeep} /></Pressable> : <Pressable onPress={() => void toggleRecording()} disabled={sending} style={[styles.micButton, recording && styles.recordingButton]}><Ionicons name={recording ? 'stop' : 'mic-outline'} size={19} color={recording ? 'white' : theme.colors.teal} /></Pressable>}
        </View>
        {recording ? <Text style={styles.recordingHint}>Recording voice message · tap stop to send</Text> : null}
      </KeyboardAvoidingView>
      <Text numberOfLines={1} style={styles.underComposer}>{typingNames.length ? ' ' : 'HUSTLER · PRIVATE CONVERSATION'}</Text>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingHorizontal: 13, paddingTop: 5, paddingBottom: 5 },
  header: { height: 55, flexDirection: 'row', alignItems: 'center', gap: 6, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft, marginBottom: 4 },
  headerPerson: { flex: 1, marginLeft: 2 },
  personName: { color: theme.colors.text, fontSize: 14, fontWeight: '800' },
  personStatus: { color: theme.colors.textMuted, fontSize: 10, marginTop: 3 },
  offlineBanner: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#342D1E', borderRadius: 10, padding: 8, marginTop: 6 },
  offlineText: { color: '#E4C887', fontSize: 10 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 25 },
  emptyLock: { width: 54, height: 54, borderRadius: 27, alignItems: 'center', justifyContent: 'center', backgroundColor: '#103734', marginBottom: 14 },
  emptyTitle: { color: theme.colors.text, fontSize: 16, fontWeight: '800', textAlign: 'center' },
  emptyText: { color: theme.colors.textMuted, fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 8, maxWidth: 295 },
  messageList: { paddingHorizontal: 3, paddingVertical: 10 },
  messageLine: { flexDirection: 'row', marginVertical: 4 },
  messageMine: { justifyContent: 'flex-end' },
  messageTheirs: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '84%', borderRadius: 19, paddingHorizontal: 12, paddingTop: 9, paddingBottom: 5 },
  bubbleMine: { backgroundColor: '#0C665B', borderBottomRightRadius: 6 },
  bubbleTheirs: { backgroundColor: '#132A2B', borderWidth: 1, borderColor: '#1B393A', borderBottomLeftRadius: 6 },
  messageText: { color: theme.colors.text, fontSize: 14, lineHeight: 20 },
  messageTextMine: { color: '#F2FFFC' },
  metaRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 3, marginTop: 3 },
  messageTime: { color: '#85A19E', fontSize: 9 },
  messageTimeMine: { color: '#B5E2DA' },
  imageMessage: { minWidth: 180, maxWidth: 240 },
  messageImage: { width: 220, height: 170, borderRadius: 13, backgroundColor: '#0A1718' },
  imagePlaceholder: { width: 220, height: 150, borderRadius: 13, alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#0A1B1C' },
  placeholderText: { color: theme.colors.textMuted, fontSize: 10 },
  caption: { color: theme.colors.text, fontSize: 12, marginTop: 7 },
  captionMine: { color: '#F2FFFC' },
  audioBubble: { minWidth: 190, flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 2 },
  audioPlay: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: '#123B39' },
  audioPlayMine: { backgroundColor: '#7FE5D3' },
  audioTrack: { flex: 1, gap: 5 },
  audioTrackFill: { height: 3, width: '80%', borderRadius: 2, backgroundColor: '#3C6E68' },
  audioTrackFillMine: { backgroundColor: '#8CEADA' },
  audioLabel: { color: theme.colors.textSecondary, fontSize: 10 },
  audioLabelMine: { color: '#E9FFFA' },
  loadingOlder: { color: theme.colors.textMuted, fontSize: 10, alignSelf: 'center', padding: 8 },
  typingLine: { color: theme.colors.teal, fontSize: 10, minHeight: 15, paddingLeft: 10 },
  composer: { minHeight: 52, flexDirection: 'row', alignItems: 'flex-end', gap: 5, borderRadius: 19, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, paddingHorizontal: 5, paddingVertical: 5 },
  inputWrap: { flex: 1, maxHeight: 105, justifyContent: 'center' },
  input: { minHeight: 38, maxHeight: 98, color: theme.colors.text, fontSize: 13, paddingHorizontal: 8, paddingVertical: 8, textAlignVertical: 'center' },
  sendButton: { width: 39, height: 39, borderRadius: 20, backgroundColor: theme.colors.teal, alignItems: 'center', justifyContent: 'center', marginBottom: 1 },
  micButton: { width: 39, height: 39, borderRadius: 20, backgroundColor: '#123B39', alignItems: 'center', justifyContent: 'center', marginBottom: 1 },
  recordingButton: { backgroundColor: theme.colors.danger },
  recordingHint: { color: theme.colors.danger, fontSize: 10, textAlign: 'center', paddingTop: 4 },
  underComposer: { color: '#446A67', fontSize: 8, letterSpacing: 1.2, textAlign: 'center', paddingTop: 6 }
});

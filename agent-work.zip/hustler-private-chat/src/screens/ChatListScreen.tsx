import { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, BrandMark, IconButton } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { BottomTabs } from '@/components/BottomTabs';
import { theme } from '@/config/theme';
import { getApprovedUser, subscribeChats } from '@/services/chatService';
import type { ChatDocument, MainTab, UserProfile } from '@/types/models';

function dateLabel(value: ChatDocument['lastMessageAt']): string {
  if (!value) return '';
  const date = value.toDate();
  const now = new Date();
  if (date.toDateString() === now.toDateString()) return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (now.getTime() - date.getTime() < 6 * 24 * 60 * 60 * 1000) return date.toLocaleDateString([], { weekday: 'short' });
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export function ChatListScreen({
  uid,
  profile,
  connected,
  onTab,
  onOpenChat,
  onContacts
}: {
  uid: string;
  profile: UserProfile;
  connected: boolean | null;
  onTab: (tab: MainTab) => void;
  onOpenChat: (chat: ChatDocument, person: UserProfile) => void;
  onContacts: () => void;
}) {
  const [chats, setChats] = useState<ChatDocument[]>([]);
  const [people, setPeople] = useState<Record<string, UserProfile>>({});
  const [queryText, setQueryText] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => subscribeChats(uid, value => {
    setChats(value); setLoading(false); setError('');
  }, caught => { setLoading(false); setError(caught.message); }), [uid]);

  useEffect(() => {
    let live = true;
    const otherIds = [...new Set(chats.flatMap(chat => chat.participantIds.filter(id => id !== uid)))];
    void Promise.all(otherIds.map(async id => [id, await getApprovedUser(id)] as const)).then(entries => {
      if (!live) return;
      setPeople(previous => {
        const next = { ...previous };
        for (const [id, person] of entries) if (person) next[id] = person;
        return next;
      });
    }).catch(caught => { if (live) setError(caught instanceof Error ? caught.message : 'Could not load chat profiles.'); });
    return () => { live = false; };
  }, [chats, uid]);

  const filtered = useMemo(() => chats.filter(chat => {
    const person = chat.participantIds.map(id => people[id]).find(Boolean);
    const searchable = `${person?.displayName ?? ''} ${person?.username ?? ''} ${chat.lastMessagePreview}`.toLowerCase();
    return searchable.includes(queryText.trim().toLowerCase());
  }), [chats, people, queryText]);

  return (
    <AppScreen style={styles.screen}>
      <View style={styles.header}>
        <View style={styles.brandRow}><BrandMark size={42} /><View><Text style={styles.brand}>HUSTLER</Text><Text style={styles.headerSub}>PRIVATE MESSAGING</Text></View></View>
        <Pressable onPress={() => onTab('profile')}><Avatar name={profile.displayName} photoPath={profile.photoPath} size={42} online={profile.presence === 'online'} /></Pressable>
      </View>
      <View style={styles.titleRow}>
        <View><Text style={styles.pageTitle}>Messages</Text><Text style={styles.pageSub}>{connected === false ? 'Offline · reconnecting…' : 'Your approved conversations'}</Text></View>
        {connected === false ? <Ionicons name="cloud-offline-outline" size={19} color={theme.colors.warning} /> : <View style={styles.secureBadge}><Ionicons name="lock-closed" size={12} color={theme.colors.teal} /><Text style={styles.secureText}>PRIVATE</Text></View>}
      </View>
      <View style={styles.search}>
        <Ionicons name="search-outline" size={18} color={theme.colors.textMuted} />
        <TextInput value={queryText} onChangeText={setQueryText} placeholder="Search conversations" placeholderTextColor={theme.colors.textMuted} style={styles.searchInput} returnKeyType="search" />
        {queryText ? <IconButton name="close-circle" onPress={() => setQueryText('')} size={30} iconSize={18} background="transparent" color={theme.colors.textMuted} /> : null}
      </View>
      <View style={styles.sectionHead}><Text style={styles.sectionTitle}>RECENT</Text><Text style={styles.sectionCount}>{filtered.length}</Text></View>
      {error ? <View style={styles.errorCard}><Ionicons name="alert-circle-outline" color={theme.colors.danger} size={17} /><Text style={styles.errorText}>{error}</Text></View> : null}
      {loading ? <View style={styles.centerState}><Text style={styles.muted}>Loading secure conversations…</Text></View> : filtered.length === 0 ? (
        <View style={styles.empty}>
          <View style={styles.emptyIcon}><Ionicons name="chatbubble-ellipses-outline" size={27} color={theme.colors.teal} /></View>
          <Text style={styles.emptyTitle}>{queryText ? 'No matches' : 'Your chats start here'}</Text>
          <Text style={styles.emptyText}>{queryText ? 'Try another name or message.' : 'Only approved accounts appear here. Start a private conversation with an approved contact.'}</Text>
          <Pressable onPress={onContacts} style={styles.startButton}><Ionicons name="add" size={18} color={theme.colors.backgroundDeep} /><Text style={styles.startButtonText}>Find a contact</Text></Pressable>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => {
            const person = item.participantIds.map(id => people[id]).find(Boolean);
            if (!person) return null;
            const unread = item.unreadCounts[uid] ?? 0;
            const lastPrefix = item.lastSenderId === uid ? 'You: ' : '';
            return (
              <Pressable onPress={() => onOpenChat(item, person)} style={({ pressed }) => [styles.chatRow, pressed && styles.rowPressed]}>
                <Avatar name={person.displayName} photoPath={person.photoPath} size={54} online={person.presence === 'online'} />
                <View style={styles.chatBody}>
                  <View style={styles.chatTop}><Text numberOfLines={1} style={styles.personName}>{person.displayName || person.username}</Text><Text style={styles.time}>{dateLabel(item.lastMessageAt)}</Text></View>
                  <View style={styles.chatBottom}><Text numberOfLines={1} style={styles.preview}>{lastPrefix}{item.lastMessagePreview || 'Say hello securely'}</Text>{unread > 0 ? <View style={styles.unread}><Text style={styles.unreadText}>{unread > 99 ? '99+' : unread}</Text></View> : null}</View>
                </View>
              </Pressable>
            );
          }}
          ListFooterComponent={<View style={{ height: 10 }} />}
        />
      )}
      <BottomTabs active="chats" onChange={onTab} />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 9, paddingBottom: 2 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brand: { color: theme.colors.text, fontSize: 16, fontWeight: '900', letterSpacing: 1.8 },
  headerSub: { color: theme.colors.textMuted, fontSize: 8, letterSpacing: 1.5, marginTop: 3 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 17 },
  pageTitle: { color: theme.colors.text, fontSize: 28, fontWeight: '800', letterSpacing: -0.6 },
  pageSub: { color: theme.colors.textMuted, fontSize: 12, marginTop: 3 },
  secureBadge: { borderRadius: 100, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface, paddingHorizontal: 10, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 5 },
  secureText: { color: theme.colors.teal, fontSize: 9, fontWeight: '900', letterSpacing: 1.1 },
  search: { height: 49, borderRadius: 16, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 9, marginBottom: 19 },
  searchInput: { color: theme.colors.text, flex: 1, fontSize: 13, paddingVertical: 8 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 7 },
  sectionTitle: { color: theme.colors.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 1.6 },
  sectionCount: { color: theme.colors.textMuted, fontSize: 10 },
  list: { paddingBottom: 6 },
  chatRow: { minHeight: 78, flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft, gap: 13 },
  rowPressed: { opacity: 0.75 },
  chatBody: { flex: 1, justifyContent: 'center' },
  chatTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  personName: { color: theme.colors.text, fontSize: 15, fontWeight: '700', flex: 1 },
  time: { color: theme.colors.textMuted, fontSize: 10 },
  chatBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginTop: 6 },
  preview: { color: theme.colors.textMuted, fontSize: 12, flex: 1 },
  unread: { minWidth: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.colors.teal, paddingHorizontal: 5 },
  unreadText: { color: theme.colors.backgroundDeep, fontSize: 10, fontWeight: '900' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  emptyIcon: { height: 64, width: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', backgroundColor: '#103734', borderWidth: 1, borderColor: theme.colors.border, marginBottom: 17 },
  emptyTitle: { color: theme.colors.text, fontSize: 18, fontWeight: '800', textAlign: 'center' },
  emptyText: { color: theme.colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: 'center', maxWidth: 290, marginTop: 8 },
  startButton: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.colors.teal, paddingHorizontal: 17, paddingVertical: 12, borderRadius: 16, marginTop: 20 },
  startButtonText: { color: theme.colors.backgroundDeep, fontSize: 12, fontWeight: '800' },
  centerState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  muted: { color: theme.colors.textMuted, fontSize: 13 },
  errorCard: { backgroundColor: '#321F23', borderRadius: 14, borderColor: '#60393E', borderWidth: 1, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 8 },
  errorText: { flex: 1, color: '#F7C4C1', fontSize: 11, lineHeight: 16 }
});

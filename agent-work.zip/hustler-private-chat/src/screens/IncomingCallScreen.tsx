import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, PrimaryButton } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { theme } from '@/config/theme';
import type { CallDocument, UserProfile } from '@/types/models';

export function IncomingCallScreen({
  call,
  person,
  onAccept,
  onDecline
}: {
  call: CallDocument;
  person: UserProfile;
  onAccept: () => Promise<void>;
  onDecline: () => Promise<void>;
}) {
  const [busy, setBusy] = useState<'accept' | 'decline' | null>(null);
  const [error, setError] = useState('');
  const accept = async () => {
    setError(''); setBusy('accept');
    try { await onAccept(); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not answer the call.'); setBusy(null); }
  };
  const decline = async () => {
    setError(''); setBusy('decline');
    try { await onDecline(); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not decline the call.'); setBusy(null); }
  };

  return (
    <AppScreen style={styles.screen}>
      <View style={styles.topTag}><View style={styles.ringDot} /><Text style={styles.topTagText}>INCOMING {call.mediaType.toUpperCase()} CALL</Text></View>
      <View style={styles.center}>
        <View style={styles.avatarHalo}><Avatar name={person.displayName} photoPath={person.photoPath} size={122} online /></View>
        <Text style={styles.name}>{person.displayName}</Text>
        <Text style={styles.handle}>@{person.username}</Text>
        <Text style={styles.status}>{call.mediaType === 'video' ? 'HUSTLER video call' : 'HUSTLER voice call'}</Text>
        <View style={styles.secureNote}><Ionicons name="lock-closed-outline" size={13} color={theme.colors.teal} /><Text style={styles.secureText}>WebRTC encrypted media</Text></View>
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <View style={styles.actions}>
        <View style={styles.actionCol}><PrimaryButton title="Decline" icon="call" variant="danger" loading={busy === 'decline'} disabled={busy !== null} onPress={() => void decline()} style={styles.actionButton} /><Text style={styles.actionHint}>DECLINE</Text></View>
        <View style={styles.actionCol}><PrimaryButton title="Answer" icon={call.mediaType === 'video' ? 'videocam' : 'call'} loading={busy === 'accept'} disabled={busy !== null} onPress={() => void accept()} style={[styles.actionButton, styles.answerButton]} /><Text style={styles.actionHint}>ANSWER</Text></View>
      </View>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingHorizontal: 28, paddingTop: 26, paddingBottom: 26, alignItems: 'center', justifyContent: 'space-between' },
  topTag: { alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 13, paddingVertical: 8, borderRadius: 99, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface },
  ringDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: theme.colors.teal },
  topTagText: { color: theme.colors.textSecondary, fontSize: 9, fontWeight: '900', letterSpacing: 1.4 },
  center: { alignItems: 'center', marginTop: -10 },
  avatarHalo: { padding: 7, borderRadius: 80, backgroundColor: '#0D3130', borderColor: '#1C5951', borderWidth: 1 },
  name: { color: theme.colors.text, fontSize: 25, fontWeight: '800', marginTop: 19 },
  handle: { color: theme.colors.textMuted, fontSize: 13, marginTop: 5 },
  status: { color: theme.colors.textSecondary, fontSize: 13, marginTop: 16 },
  secureNote: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  secureText: { color: theme.colors.textMuted, fontSize: 10 },
  actions: { flexDirection: 'row', width: '100%', justifyContent: 'space-between', gap: 14, marginBottom: 16 },
  actionCol: { flex: 1, alignItems: 'center', gap: 8 },
  actionButton: { width: '100%', height: 58 },
  answerButton: { backgroundColor: theme.colors.tealStrong },
  actionHint: { color: theme.colors.textMuted, fontSize: 9, letterSpacing: 1.3, fontWeight: '800' },
  error: { color: theme.colors.danger, fontSize: 12, textAlign: 'center', marginBottom: 10 }
});

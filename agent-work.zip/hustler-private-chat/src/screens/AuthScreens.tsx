import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, BrandTitle, ErrorNotice, FormField, PrimaryButton } from '@/components/Primitives';
import { theme } from '@/config/theme';
import type { UserProfile } from '@/types/models';

export function LoginScreen({
  configured,
  onLogin,
  onRegister
}: {
  configured: boolean;
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: () => void;
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setError(''); setLoading(true);
    try { await onLogin(email, password); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not sign in.'); }
    finally { setLoading(false); }
  };

  return (
    <AppScreen scroll style={styles.screen}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.content}>
        <View style={styles.brandBlock}><BrandTitle subtitle="Your private space, kept personal." /></View>
        <View style={styles.card}>
          <Text style={styles.eyebrow}>WELCOME BACK</Text>
          <Text style={styles.title}>Sign in</Text>
          <Text style={styles.subtitle}>Use your approved HUSTLER account.</Text>
          {!configured ? <ErrorNotice text="Firebase is not configured yet. Follow FIREBASE_SETUP.md, then rebuild the app." /> : null}
          <ErrorNotice text={error} />
          <FormField label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" icon="mail-outline" />
          <FormField label="Password" value={password} onChangeText={setPassword} placeholder="Your password" secureTextEntry icon="lock-closed-outline" />
          <PrimaryButton title="Sign in securely" icon="arrow-forward" loading={loading} disabled={!configured || !email.trim() || !password} onPress={() => void submit()} style={styles.submit} />
          <View style={styles.noteRow}><Ionicons name="shield-checkmark-outline" size={16} color={theme.colors.teal} /><Text style={styles.note}>Account access is protected by Firebase Authentication and approval rules.</Text></View>
        </View>
        <View style={styles.registerRow}>
          <Text style={styles.registerText}>Need access?</Text>
          <Pressable onPress={onRegister}><Text style={styles.registerLink}>Request an account</Text></Pressable>
        </View>
        <Text style={styles.footer}>HUSTLER · PRIVATE BY DESIGN</Text>
      </KeyboardAvoidingView>
    </AppScreen>
  );
}

export function RegisterScreen({
  configured,
  onBack,
  onRegister
}: {
  configured: boolean;
  onBack: () => void;
  onRegister: (data: { email: string; password: string; username: string; displayName: string }) => Promise<void>;
}) {
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [requested, setRequested] = useState(false);

  const submit = async () => {
    setError(''); setLoading(true);
    try {
      await onRegister({ email, password, username, displayName });
      setRequested(true);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not request access.');
    } finally { setLoading(false); }
  };

  if (requested) return <PendingApprovalScreen profile={null} onBack={onBack} />;

  return (
    <AppScreen scroll style={styles.screen}>
      <View style={styles.content}>
        <Pressable onPress={onBack} style={styles.backRow}><Ionicons name="chevron-back" size={19} color={theme.colors.textSecondary} /><Text style={styles.backText}>Back to sign in</Text></Pressable>
        <View style={styles.brandBlock}><BrandTitle subtitle="Access is approved by your administrator." /></View>
        <View style={styles.card}>
          <Text style={styles.eyebrow}>REQUEST ACCESS</Text>
          <Text style={styles.title}>Create your account</Text>
          <Text style={styles.subtitle}>New accounts stay pending until the owner approves them.</Text>
          {!configured ? <ErrorNotice text="Firebase is not configured. Complete setup before creating an account." /> : null}
          <ErrorNotice text={error} />
          <FormField label="Display name" value={displayName} onChangeText={setDisplayName} placeholder="How contacts see you" icon="person-outline" autoCapitalize="words" maxLength={48} />
          <FormField label="Username" value={username} onChangeText={setUsername} placeholder="3–20 letters, numbers, underscores" icon="at-outline" maxLength={20} />
          <FormField label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" icon="mail-outline" />
          <FormField label="Password" value={password} onChangeText={setPassword} placeholder="At least 10 characters" secureTextEntry icon="lock-closed-outline" />
          <PrimaryButton title="Request approval" icon="paper-plane-outline" loading={loading} disabled={!configured || !displayName || !username || !email || password.length < 10} onPress={() => void submit()} style={styles.submit} />
          <Text style={styles.finePrint}>Creating an account does not grant access to any conversation. An administrator must approve it first.</Text>
        </View>
      </View>
    </AppScreen>
  );
}

export function PendingApprovalScreen({ profile, onBack, onSignOut }: { profile: UserProfile | null; onBack: () => void; onSignOut?: () => void }) {
  return (
    <AppScreen style={styles.pendingScreen}>
      <View style={styles.pendingGlow}><Ionicons name="hourglass-outline" size={34} color={theme.colors.teal} /></View>
      <Text style={styles.eyebrow}>ACCESS REQUESTED</Text>
      <Text style={styles.pendingTitle}>You’re on the list.</Text>
      <Text style={styles.pendingText}>
        {profile?.displayName ? `Thanks, ${profile.displayName}. ` : ''}Your HUSTLER account is waiting for administrator approval. Private conversations remain unavailable until then.
      </Text>
      <View style={styles.pendingCard}>
        <View style={styles.pendingCheck}><Ionicons name="checkmark" size={16} color={theme.colors.backgroundDeep} /></View>
        <View style={{ flex: 1 }}><Text style={styles.pendingCardTitle}>Account created</Text><Text style={styles.pendingCardText}>Approval is controlled by the HUSTLER owner.</Text></View>
      </View>
      <PrimaryButton title="Return to calculator" icon="lock-closed-outline" variant="secondary" onPress={onBack} style={{ width: '100%', marginTop: 28 }} />
      {onSignOut ? <Pressable onPress={onSignOut} style={{ padding: 14 }}><Text style={styles.registerLink}>Sign out of this account</Text></Pressable> : null}
      <Text style={styles.footer}>HUSTLER · ACCESS BY APPROVAL</Text>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingHorizontal: 22 },
  content: { flex: 1, paddingBottom: 18 },
  brandBlock: { alignItems: 'center', marginTop: 24, marginBottom: 28 },
  card: { backgroundColor: theme.colors.surface, borderRadius: 26, borderWidth: 1, borderColor: theme.colors.border, padding: 20 },
  eyebrow: { color: theme.colors.teal, fontSize: 10, fontWeight: '900', letterSpacing: 1.7 },
  title: { color: theme.colors.text, fontSize: 27, fontWeight: '800', marginTop: 7 },
  subtitle: { color: theme.colors.textMuted, fontSize: 13, lineHeight: 19, marginTop: 5, marginBottom: 18 },
  submit: { marginTop: 7 },
  noteRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, marginTop: 18 },
  note: { flex: 1, color: theme.colors.textMuted, fontSize: 11, lineHeight: 16 },
  registerRow: { flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 20 },
  registerText: { color: theme.colors.textMuted, fontSize: 13 },
  registerLink: { color: theme.colors.teal, fontWeight: '800', fontSize: 13 },
  footer: { color: '#3F6663', textAlign: 'center', fontSize: 9, letterSpacing: 1.5, marginTop: 24 },
  backRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  backText: { color: theme.colors.textSecondary, fontSize: 13, fontWeight: '600' },
  finePrint: { color: theme.colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 13, textAlign: 'center' },
  pendingScreen: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 26 },
  pendingGlow: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0A3331', borderColor: '#1E5752', borderWidth: 1, marginBottom: 26 },
  pendingTitle: { color: theme.colors.text, fontSize: 30, fontWeight: '800', marginTop: 10, textAlign: 'center' },
  pendingText: { color: theme.colors.textSecondary, fontSize: 14, lineHeight: 22, textAlign: 'center', maxWidth: 350, marginTop: 12 },
  pendingCard: { width: '100%', flexDirection: 'row', alignItems: 'center', gap: 12, padding: 15, marginTop: 28, borderRadius: 18, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface },
  pendingCheck: { width: 28, height: 28, borderRadius: 14, backgroundColor: theme.colors.teal, alignItems: 'center', justifyContent: 'center' },
  pendingCardTitle: { color: theme.colors.text, fontSize: 13, fontWeight: '700' },
  pendingCardText: { color: theme.colors.textMuted, fontSize: 11, marginTop: 3 }
});

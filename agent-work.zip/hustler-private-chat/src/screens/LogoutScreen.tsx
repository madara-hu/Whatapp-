import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, PrimaryButton } from '@/components/Primitives';
import { theme } from '@/config/theme';

export function LogoutScreen({ onCancel, onConfirm, loading }: { onCancel: () => void; onConfirm: () => void; loading: boolean }) {
  return (
    <AppScreen style={styles.screen}>
      <View style={styles.icon}><Ionicons name="log-out-outline" size={32} color={theme.colors.warning} /></View>
      <Text style={styles.title}>Log out of HUSTLER?</Text>
      <Text style={styles.text}>Your account will be signed out on this device. Your approved conversations remain stored in Firebase and can be accessed again after signing in.</Text>
      <PrimaryButton title="Stay signed in" variant="secondary" onPress={onCancel} style={{ width: '100%', marginTop: 26 }} />
      <PrimaryButton title="Log out" icon="log-out-outline" variant="danger" loading={loading} onPress={onConfirm} style={{ width: '100%', marginTop: 10 }} />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { justifyContent: 'center', alignItems: 'center', paddingHorizontal: 30 },
  icon: { width: 76, height: 76, borderRadius: 38, backgroundColor: '#393019', borderWidth: 1, borderColor: '#66522B', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { color: theme.colors.text, fontSize: 25, fontWeight: '800', textAlign: 'center' },
  text: { color: theme.colors.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', marginTop: 12, maxWidth: 320 }
});

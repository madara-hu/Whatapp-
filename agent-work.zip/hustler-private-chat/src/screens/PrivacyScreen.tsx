import { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, PrimaryButton, ScreenHeader } from '@/components/Primitives';
import { theme } from '@/config/theme';

function PrivacyCard({ icon, title, text, tone = 'neutral' }: { icon: keyof typeof Ionicons.glyphMap; title: string; text: string; tone?: 'neutral' | 'warning' | 'good' }) {
  return (
    <View style={[styles.card, tone === 'warning' && styles.warningCard, tone === 'good' && styles.goodCard]}>
      <View style={[styles.iconWrap, tone === 'warning' && styles.warningIcon, tone === 'good' && styles.goodIcon]}><Ionicons name={icon} size={19} color={tone === 'warning' ? theme.colors.warning : tone === 'good' ? theme.colors.teal : theme.colors.textSecondary} /></View>
      <View style={{ flex: 1 }}><Text style={styles.cardTitle}>{title}</Text><Text style={styles.cardText}>{text}</Text></View>
    </View>
  );
}

export function PrivacyScreen({ onBack, onEnableNotifications, notificationsEnabled }: { onBack: () => void; onEnableNotifications: () => Promise<void>; notificationsEnabled: boolean | null }) {
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const enable = async () => {
    setBusy(true); setNotice('');
    try { await onEnableNotifications(); setNotice('Notification permission and device registration checked.'); }
    catch (error) { setNotice(error instanceof Error ? error.message : 'Could not register notifications.'); }
    finally { setBusy(false); }
  };

  return (
    <AppScreen style={styles.screen}>
      <ScreenHeader title="Privacy & security" onBack={onBack} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 22 }}>
        <View style={styles.intro}><View style={styles.shield}><Ionicons name="shield-checkmark-outline" size={27} color={theme.colors.teal} /></View><Text style={styles.introTitle}>Know the boundaries.</Text><Text style={styles.introText}>HUSTLER enforces account approval and participant-only Firebase access. This build does not yet provide end-to-end encrypted messaging.</Text></View>
        <PrivacyCard icon="lock-closed-outline" title="Transport & storage" text="Firebase uses TLS in transit and encrypts stored data at rest. Those protections are not end-to-end encryption; authorized Firebase project operators may be able to access message contents." tone="warning" />
        <PrivacyCard icon="chatbubble-ellipses-outline" title="Text and media messages" text="Messages are restricted by Firestore and Storage Rules to approved conversation members. Message content is not encrypted on the device before upload in this build." tone="warning" />
        <PrivacyCard icon="videocam-outline" title="Voice and video calls" text="Calls use WebRTC DTLS-SRTP between the two devices. A TURN server, when configured, relays encrypted packets without decoding them. Signaling is stored in Firestore under participant-only rules." tone="good" />
        <PrivacyCard icon="calculator-outline" title="Calculator gate" text="The calculator unlock is a convenience/obfuscation screen only. Its expression is included in the app build and can be extracted. It does not replace Android security or Firebase authentication." />
        <View style={styles.notificationCard}>
          <View style={{ flex: 1 }}><Text style={styles.cardTitle}>Push notifications</Text><Text style={styles.cardText}>{notificationsEnabled === true ? 'This device has an FCM token registered.' : notificationsEnabled === false ? 'Push notifications are not enabled for this device.' : 'Check permission and register this device with Firebase Cloud Messaging.'}</Text></View>
          <Ionicons name={notificationsEnabled ? 'notifications' : 'notifications-outline'} size={20} color={notificationsEnabled ? theme.colors.teal : theme.colors.textMuted} />
        </View>
        <PrimaryButton title="Enable notifications" icon="notifications-outline" loading={busy} onPress={() => void enable()} style={{ marginTop: 7 }} />
        {notice ? <Text style={styles.notice}>{notice}</Text> : null}
        <Text style={styles.footnote}>Do not use this build for sensitive conversations until a reviewed end-to-end encryption protocol and device/key verification are implemented and independently tested.</Text>
      </ScrollView>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 8 },
  intro: { alignItems: 'center', paddingHorizontal: 10, paddingTop: 6, paddingBottom: 20 },
  shield: { width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center', backgroundColor: '#103734', marginBottom: 13 },
  introTitle: { color: theme.colors.text, fontSize: 20, fontWeight: '800' },
  introText: { color: theme.colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: 'center', marginTop: 7 },
  card: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, padding: 14, marginBottom: 10, borderRadius: 18, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border },
  warningCard: { borderColor: '#6B5630', backgroundColor: '#2A261D' },
  goodCard: { borderColor: '#23564E', backgroundColor: '#0C2926' },
  iconWrap: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#173436' },
  warningIcon: { backgroundColor: '#4A3C22' },
  goodIcon: { backgroundColor: '#143C35' },
  cardTitle: { color: theme.colors.text, fontSize: 13, fontWeight: '800' },
  cardText: { color: theme.colors.textSecondary, fontSize: 11, lineHeight: 16, marginTop: 4 },
  notificationCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 15, marginBottom: 12, borderRadius: 18, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border },
  notice: { color: theme.colors.textMuted, fontSize: 11, textAlign: 'center', marginTop: 9 },
  footnote: { color: '#CBAA6C', fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: 18, paddingHorizontal: 8 }
});

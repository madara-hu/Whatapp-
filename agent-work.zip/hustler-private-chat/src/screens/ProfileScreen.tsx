import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, ErrorNotice, IconButton, PrimaryButton } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { BottomTabs } from '@/components/BottomTabs';
import { theme } from '@/config/theme';
import { setOwnPhotoPath, updateOwnProfile } from '@/services/authService';
import { uploadProfilePhoto } from '@/services/mediaService';
import type { MainTab, UserProfile } from '@/types/models';

// Keeping the editor fields local avoids persisting keystrokes as profile writes.
export function ProfileScreen({
  uid,
  email,
  profile,
  onTab,
  onPrivacy,
  onAdmin,
  onLogout
}: {
  uid: string;
  email: string;
  profile: UserProfile;
  onTab: (tab: MainTab) => void;
  onPrivacy: () => void;
  onAdmin: () => void;
  onLogout: () => void;
}) {
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [about, setAbout] = useState(profile.about);
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const saveProfile = async () => {
    setBusy(true); setError('');
    try {
      await updateOwnProfile(uid, { displayName, about });
      setEditing(false);
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not save profile.'); }
    finally { setBusy(false); }
  };

  const changePhoto = async () => {
    setError('');
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) throw new Error('Photo library permission was not granted.');
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 0.8 });
      if (result.canceled || !result.assets[0]) return;
      setBusy(true);
      const path = await uploadProfilePhoto(uid, result.assets[0].uri);
      await setOwnPhotoPath(uid, path);
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not update photo.'); }
    finally { setBusy(false); }
  };

  return (
    <AppScreen style={styles.screen}>
      <View style={styles.header}><Text style={styles.title}>Profile</Text><IconButton name="settings-outline" onPress={onPrivacy} color={theme.colors.textSecondary} /></View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <View style={styles.profileCard}>
          <Pressable onPress={() => void changePhoto()} style={styles.avatarButton}>
            <Avatar name={profile.displayName} photoPath={profile.photoPath} size={94} online={profile.presence === 'online'} />
            <View style={styles.editPhoto}><Ionicons name="camera-outline" size={14} color={theme.colors.backgroundDeep} /></View>
          </Pressable>
          <Text style={styles.name}>{profile.displayName || 'HUSTLER member'}</Text>
          <Text style={styles.username}>@{profile.username}</Text>
          <View style={styles.onlineRow}><View style={[styles.presenceDot, profile.presence !== 'online' && styles.offlineDot]} /><Text style={styles.onlineText}>{profile.presence === 'online' ? 'Online' : 'Offline'}</Text></View>
          <Text style={styles.about}>{profile.about || 'A quiet corner of the internet.'}</Text>
        </View>

        <ErrorNotice text={error} />
        <View style={styles.detailsCard}>
          <View style={styles.cardHeading}><Text style={styles.cardTitle}>Account details</Text><Pressable onPress={() => setEditing(value => !value)}><Text style={styles.editLabel}>{editing ? 'Cancel' : 'Edit'}</Text></Pressable></View>
          {editing ? (
            <>
              <Text style={styles.label}>Display name</Text>
              <View style={styles.editField}><Ionicons name="person-outline" size={17} color={theme.colors.textMuted} /><TextInputCompat value={displayName} onChangeText={setDisplayName} maxLength={48} /></View>
              <Text style={styles.label}>About</Text>
              <View style={[styles.editField, { minHeight: 70 }]}><Ionicons name="chatbox-ellipses-outline" size={17} color={theme.colors.textMuted} /><TextInputCompat value={about} onChangeText={setAbout} maxLength={140} multiline /></View>
              <PrimaryButton title="Save profile" loading={busy} onPress={() => void saveProfile()} style={{ marginTop: 7 }} />
            </>
          ) : (
            <>
              <DetailRow icon="at-outline" label="Username" value={`@${profile.username}`} />
              <DetailRow icon="mail-outline" label="Email" value={email || 'Not available'} />
              <DetailRow icon="shield-checkmark-outline" label="Account" value={profile.role === 'admin' ? 'Administrator' : 'Approved member'} />
            </>
          )}
        </View>

        <View style={styles.linksCard}>
          {profile.role === 'admin' ? <MenuRow icon="people-circle-outline" title="Account approvals" subtitle="Review pending access requests" onPress={onAdmin} /> : null}
          <MenuRow icon="lock-closed-outline" title="Privacy & security" subtitle="Understand what is and is not encrypted" onPress={onPrivacy} />
          <MenuRow icon="notifications-outline" title="Notifications" subtitle="Calls and new message alerts" onPress={onPrivacy} />
          <MenuRow icon="help-circle-outline" title="Help & support" subtitle="Setup, accounts, and known limitations" onPress={onPrivacy} />
        </View>
        <PrimaryButton title="Log out" icon="log-out-outline" variant="secondary" onPress={onLogout} style={styles.logout} />
      </ScrollView>
      <BottomTabs active="profile" onChange={onTab} />
    </AppScreen>
  );
}

function TextInputCompat(props: { value: string; onChangeText: (text: string) => void; maxLength: number; multiline?: boolean }) {
  return <TextInput {...props} placeholderTextColor={theme.colors.textMuted} style={styles.input} />;
}

function DetailRow({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  return <View style={styles.detailRow}><Ionicons name={icon} size={17} color={theme.colors.textMuted} /><Text style={styles.detailLabel}>{label}</Text><Text numberOfLines={1} style={styles.detailValue}>{value}</Text></View>;
}

function MenuRow({ icon, title, subtitle, onPress }: { icon: keyof typeof Ionicons.glyphMap; title: string; subtitle: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={styles.menuRow}><View style={styles.menuIcon}><Ionicons name={icon} size={18} color={theme.colors.teal} /></View><View style={{ flex: 1 }}><Text style={styles.menuTitle}>{title}</Text><Text style={styles.menuSub}>{subtitle}</Text></View><Ionicons name="chevron-forward" size={17} color={theme.colors.textMuted} /></Pressable>;
}

const styles = StyleSheet.create({
  screen: { paddingTop: 12, paddingBottom: 2 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  title: { color: theme.colors.text, fontSize: 27, fontWeight: '800' },
  scroll: { paddingBottom: 8 },
  profileCard: { alignItems: 'center', backgroundColor: theme.colors.surface, borderColor: theme.colors.border, borderWidth: 1, borderRadius: 23, padding: 21, marginBottom: 13 },
  avatarButton: { position: 'relative' },
  editPhoto: { position: 'absolute', right: 0, bottom: 1, width: 28, height: 28, borderRadius: 14, backgroundColor: theme.colors.teal, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: theme.colors.surface },
  name: { color: theme.colors.text, fontSize: 20, fontWeight: '800', marginTop: 12 },
  username: { color: theme.colors.textMuted, fontSize: 12, marginTop: 3 },
  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  presenceDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: theme.colors.teal },
  offlineDot: { backgroundColor: theme.colors.textMuted },
  onlineText: { color: theme.colors.textSecondary, fontSize: 11 },
  about: { color: theme.colors.textSecondary, fontSize: 12, textAlign: 'center', lineHeight: 18, marginTop: 11 },
  detailsCard: { backgroundColor: theme.colors.surface, borderColor: theme.colors.border, borderWidth: 1, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 8, marginBottom: 12 },
  cardHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 11 },
  cardTitle: { color: theme.colors.text, fontSize: 14, fontWeight: '800' },
  editLabel: { color: theme.colors.teal, fontSize: 12, fontWeight: '800' },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 42, borderTopColor: theme.colors.borderSoft, borderTopWidth: 1 },
  detailLabel: { color: theme.colors.textMuted, fontSize: 12, width: 68 },
  detailValue: { flex: 1, textAlign: 'right', color: theme.colors.textSecondary, fontSize: 12 },
  label: { color: theme.colors.textMuted, fontSize: 10, fontWeight: '800', textTransform: 'uppercase', marginTop: 9, marginBottom: 6 },
  editField: { minHeight: 45, borderRadius: 12, backgroundColor: '#061A1B', borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 11, paddingVertical: 7 },
  input: { flex: 1, color: theme.colors.text, fontSize: 13, padding: 2 },
  linksCard: { backgroundColor: theme.colors.surface, borderColor: theme.colors.border, borderWidth: 1, borderRadius: 20, paddingHorizontal: 13, marginBottom: 12 },
  menuRow: { minHeight: 65, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft, flexDirection: 'row', alignItems: 'center', gap: 11 },
  menuIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#113734', alignItems: 'center', justifyContent: 'center' },
  menuTitle: { color: theme.colors.text, fontSize: 12, fontWeight: '700' },
  menuSub: { color: theme.colors.textMuted, fontSize: 10, marginTop: 3 },
  logout: { marginVertical: 4 }
});

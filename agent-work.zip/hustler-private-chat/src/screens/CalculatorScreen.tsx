import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, BrandMark } from '@/components/Primitives';
import { theme } from '@/config/theme';
import { appConfig } from '@/config/appConfig';
import { calculateOrUnlock, evaluateExpression, formatCalculatorNumber } from '@/core/calculator';

const rows = [
  ['AC', '⌫', '(', '÷'],
  ['7', '8', '9', '×'],
  ['4', '5', '6', '−'],
  ['1', '2', '3', '+'],
  ['±', '0', '.', '=']
];

export function CalculatorScreen({ onUnlocked }: { onUnlocked: () => void }) {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  const press = (key: string) => {
    if (key === 'AC') {
      setExpression(''); setResult(''); setError(''); return;
    }
    if (key === '⌫') {
      setExpression(value => value.slice(0, -1)); setResult(''); setError(''); return;
    }
    if (key === '±') {
      try {
        const current = expression ? evaluateExpression(expression) : 0;
        setExpression(formatCalculatorNumber(-current));
        setResult(''); setError('');
      } catch {
        setExpression(value => value.startsWith('-') ? value.slice(1) : `-${value}`);
        setError('');
      }
      return;
    }
    if (key === '=') {
      // Check first: this exact interaction unlocks synchronously, without a wait.
      try {
        const outcome = calculateOrUnlock(expression, appConfig.unlockExpression);
        if (outcome.kind === 'unlock') {
          onUnlocked();
          return;
        }
        const formatted = formatCalculatorNumber(outcome.value);
        setResult(formatted);
        setExpression(formatted);
        setError('');
      } catch (caught) {
        setResult('');
        setError(caught instanceof Error ? caught.message : 'Invalid calculation.');
      }
      return;
    }
    setExpression(value => (value === 'Error' ? key : value + key));
    setResult('');
    setError('');
  };

  return (
    <AppScreen style={styles.container}>
      <View style={styles.topLine}>
        <View style={styles.brandMini}><BrandMark size={34} /><Text style={styles.brandName}>HUSTLER</Text></View>
        <View style={styles.privatePill}><View style={styles.liveDot} /><Text style={styles.privateText}>PRIVATE</Text></View>
      </View>

      <View style={styles.hero}>
        <View style={styles.lockHalo}><Ionicons name="lock-closed-outline" size={22} color={theme.colors.teal} /></View>
        <Text style={styles.heroTitle}>Your space, <Text style={styles.heroAccent}>your rules.</Text></Text>
        <Text style={styles.heroSub}>A little privacy goes a long way.</Text>
      </View>

      <View style={styles.displayCard}>
        <Text style={styles.displayHint}>CALCULATOR</Text>
        <Text numberOfLines={1} adjustsFontSizeToFit style={styles.expression}>{expression || '0'}</Text>
        <View style={styles.resultRow}>
          <Text numberOfLines={1} style={[styles.result, error ? styles.errorResult : null]}>{error || (result ? `= ${result}` : 'Enter your sequence')}</Text>
          <Ionicons name="lock-closed" size={15} color={theme.colors.tealDim} />
        </View>
      </View>

      <View style={styles.keypad}>
        {rows.map((row, rowIndex) => (
          <View style={styles.keyRow} key={`row-${rowIndex}`}>
            {row.map(key => {
              const operator = ['÷', '×', '−', '+'].includes(key);
              const equals = key === '=';
              const utility = key === 'AC' || key === '⌫' || key === '(' || key === '±';
              return (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={key === '=' ? 'Equals' : key === '⌫' ? 'Backspace' : key}
                  key={key}
                  onPress={() => press(key)}
                  style={({ pressed }) => [
                    styles.key,
                    operator && styles.operatorKey,
                    utility && styles.utilityKey,
                    equals && styles.equalsKey,
                    pressed && styles.keyPressed
                  ]}
                >
                  {key === '⌫'
                    ? <Ionicons name="backspace-outline" size={21} color={theme.colors.textSecondary} />
                    : <Text style={[styles.keyLabel, operator && styles.operatorLabel, equals && styles.equalsLabel, utility && styles.utilityLabel]}>{key}</Text>}
                </Pressable>
              );
            })}
          </View>
        ))}
      </View>
      <Text style={styles.footerNote}>PRIVATE MESSAGING · HUSTLER</Text>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: 22, paddingTop: 10, paddingBottom: 6 },
  topLine: { height: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brandMini: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandName: { color: theme.colors.text, fontSize: 15, fontWeight: '900', letterSpacing: 2.2 },
  privatePill: { flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: theme.colors.teal },
  privateText: { color: theme.colors.textSecondary, fontSize: 9, fontWeight: '800', letterSpacing: 1.3 },
  hero: { alignItems: 'center', justifyContent: 'center', paddingTop: 10, paddingBottom: 18 },
  lockHalo: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#0D3533', borderWidth: 1, borderColor: '#1A5952', alignItems: 'center', justifyContent: 'center', marginBottom: 11 },
  heroTitle: { color: theme.colors.text, fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  heroAccent: { color: theme.colors.teal },
  heroSub: { color: theme.colors.textMuted, marginTop: 5, fontSize: 12, letterSpacing: 0.2 },
  displayCard: { minHeight: 120, borderRadius: 22, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: '#061D1E', paddingHorizontal: 18, paddingVertical: 12, justifyContent: 'space-between', marginBottom: 12 },
  displayHint: { color: theme.colors.textMuted, fontSize: 9, fontWeight: '800', letterSpacing: 1.8 },
  expression: { color: theme.colors.text, fontSize: 37, fontWeight: '300', textAlign: 'right', letterSpacing: 1 },
  resultRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  result: { color: theme.colors.textMuted, fontSize: 11 },
  errorResult: { color: theme.colors.danger },
  keypad: { flex: 1, minHeight: 300, gap: 9 },
  keyRow: { flex: 1, flexDirection: 'row', gap: 9 },
  key: { flex: 1, minHeight: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 17, backgroundColor: '#10292B', borderWidth: 1, borderColor: '#163638' },
  keyPressed: { backgroundColor: '#1A3F40', transform: [{ scale: 0.97 }] },
  keyLabel: { color: theme.colors.text, fontSize: 21, fontWeight: '600' },
  operatorKey: { backgroundColor: '#153738', borderColor: '#25514F' },
  operatorLabel: { color: theme.colors.teal, fontSize: 22 },
  utilityKey: { backgroundColor: '#0A2425' },
  utilityLabel: { color: theme.colors.textSecondary, fontSize: 15, fontWeight: '700' },
  equalsKey: { backgroundColor: theme.colors.teal, borderColor: theme.colors.teal },
  equalsLabel: { color: theme.colors.backgroundDeep, fontSize: 24, fontWeight: '900' },
  footerNote: { color: '#4A706D', textAlign: 'center', fontSize: 9, letterSpacing: 1.7, paddingTop: 10 }
});

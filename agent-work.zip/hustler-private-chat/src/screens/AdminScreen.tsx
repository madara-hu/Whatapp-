import { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppScreen, ErrorNotice, IconButton, ScreenHeader } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { theme } from '@/config/theme';
import { adminSetAccountStatus, listPendingAccounts } from '@/services/authService';
import type { UserProfile } from '@/types/models';

export function AdminScreen({ onBack }: { onBack: () => void }) {
  const [pending, setPending] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyUid, setBusyUid] = useState<string | null>(null);
  const [error, setError] = useState('');
  const refresh = useCallback(async () => {
    setLoading(true); setError('');
    try { setPending(await listPendingAccounts()); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not load pending accounts.'); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  const approve = async (uid: string) => {
    setBusyUid(uid); setError('');
    try { await adminSetAccountStatus(uid, 'approved'); setPending(items => items.filter(item => item.uid !== uid)); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Approval failed.'); }
    finally { setBusyUid(null); }
  };

  return (
    <AppScreen style={styles.screen}>
      <ScreenHeader title="Account approvals" onBack={onBack} right={<IconButton name="refresh-outline" onPress={() => void refresh()} size={38} color={theme.colors.teal} />} />
      <View style={styles.intro}><View style={styles.shield}><Ionicons name="shield-checkmark-outline" size={24} color={theme.colors.teal} /></View><Text style={styles.introTitle}>Approve trusted accounts only</Text><Text style={styles.introText}>Approval is enforced again by Firestore and Storage Rules; this screen is not the security boundary.</Text></View>
      <ErrorNotice text={error} />
      {loading ? <View style={styles.center}><Text style={styles.muted}>Loading requests…</Text></View> : pending.length === 0 ? <View style={styles.center}><Text style={styles.emptyTitle}>No pending requests</Text><Text style={styles.muted}>New accounts remain isolated until approved.</Text></View> : (
        <FlatList data={pending} keyExtractor={item => item.uid} contentContainerStyle={{ paddingBottom: 15 }} renderItem={({ item }) => (
          <View style={styles.userRow}><Avatar name={item.displayName} photoPath={item.photoPath} size={49} /><View style={{ flex: 1 }}><Text style={styles.userName}>{item.displayName}</Text><Text style={styles.userSub}>@{item.username}</Text></View><Pressable onPress={() => void approve(item.uid)} disabled={busyUid !== null} style={({ pressed }) => [styles.approve, pressed && { opacity: 0.75 }]}><Ionicons name={busyUid === item.uid ? 'hourglass-outline' : 'checkmark'} size={17} color={theme.colors.backgroundDeep} /><Text style={styles.approveText}>{busyUid === item.uid ? 'Wait' : 'Approve'}</Text></Pressable></View>
        )} />
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingTop: 8 },
  intro: { alignItems: 'center', marginTop: 5, marginBottom: 20, paddingHorizontal: 20 },
  shield: { width: 55, height: 55, borderRadius: 18, backgroundColor: '#103734', alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  introTitle: { color: theme.colors.text, fontSize: 17, fontWeight: '800', textAlign: 'center' },
  introText: { color: theme.colors.textMuted, fontSize: 11, textAlign: 'center', lineHeight: 16, marginTop: 6 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  emptyTitle: { color: theme.colors.text, fontSize: 16, fontWeight: '800' },
  muted: { color: theme.colors.textMuted, fontSize: 12 },
  userRow: { minHeight: 76, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: theme.colors.borderSoft },
  userName: { color: theme.colors.text, fontSize: 14, fontWeight: '700' },
  userSub: { color: theme.colors.textMuted, fontSize: 11, marginTop: 3 },
  approve: { borderRadius: 13, backgroundColor: theme.colors.teal, paddingHorizontal: 11, paddingVertical: 9, flexDirection: 'row', alignItems: 'center', gap: 5 },
  approveText: { color: theme.colors.backgroundDeep, fontSize: 11, fontWeight: '800' }
});

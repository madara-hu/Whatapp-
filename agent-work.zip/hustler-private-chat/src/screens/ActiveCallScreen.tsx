import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { setAudioModeAsync } from 'expo-audio';
import { Ionicons } from '@expo/vector-icons';
import { RTCView } from 'react-native-webrtc';
import { AppScreen, IconButton } from '@/components/Primitives';
import { Avatar } from '@/components/Avatar';
import { theme } from '@/config/theme';
import type { CallController, CallSnapshot } from '@/services/callService';
import type { UserProfile } from '@/types/models';

function formatDuration(seconds: number): string {
  return `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
}

function callLabel(snapshot: CallSnapshot): string {
  if (snapshot.error) return 'Connection issue';
  if (snapshot.status === 'ringing') return 'Ringing…';
  if (snapshot.connectionState === 'connected' || snapshot.status === 'active') return 'Connected';
  if (snapshot.connectionState === 'disconnected') return 'Reconnecting…';
  if (snapshot.connectionState === 'failed') return 'Could not connect';
  return 'Connecting…';
}

export function ActiveCallScreen({ controller, person, onFinished }: { controller: CallController; person: UserProfile; onFinished: () => void }) {
  const [snapshot, setSnapshot] = useState(controller.snapshot);
  const [duration, setDuration] = useState(0);
  const [speaker, setSpeaker] = useState(true);
  const [ending, setEnding] = useState(false);

  useEffect(() => controller.subscribe(setSnapshot), [controller]);
  useEffect(() => {
    if (snapshot.connectionState !== 'connected' && snapshot.status !== 'active') return;
    const started = Date.now();
    const timer = setInterval(() => setDuration(value => value + 1), 1000);
    return () => { clearInterval(timer); void started; };
  }, [snapshot.connectionState, snapshot.status]);
  useEffect(() => {
    if (['ended', 'declined', 'missed', 'failed'].includes(snapshot.status)) {
      const timer = setTimeout(onFinished, 900);
      return () => clearTimeout(timer);
    }
  }, [snapshot.status, onFinished]);

  const toggleSpeaker = async () => {
    const next = !speaker;
    try { await setAudioModeAsync({ shouldRouteThroughEarpiece: !next, allowsRecording: true, playsInSilentMode: true }); setSpeaker(next); }
    catch { setSpeaker(next); }
  };
  const end = async () => {
    if (ending) return;
    setEnding(true);
    await controller.end('ended');
    onFinished();
  };

  return (
    <AppScreen style={styles.screen}>
      {controller.mediaType === 'video' ? (
        <View style={styles.videoStage}>
          {snapshot.remoteStream ? <RTCView streamURL={snapshot.remoteStream.toURL()} style={StyleSheet.absoluteFill} objectFit="cover" /> : <View style={styles.remotePlaceholder}><Avatar name={person.displayName} photoPath={person.photoPath} size={88} /><Text style={styles.connectText}>{callLabel(snapshot)}</Text></View>}
          <View style={styles.videoTop}><IconButton name="chevron-down" onPress={() => void end()} background="#0008" /><View style={styles.callBadge}><View style={styles.ringDot} /><Text style={styles.callBadgeText}>{formatDuration(duration)}</Text></View><View style={{ width: 40 }} /></View>
          {snapshot.localStream ? <RTCView streamURL={snapshot.localStream.toURL()} style={styles.localVideo} objectFit="cover" mirror /> : null}
          <View style={styles.videoBottom}><Text style={styles.videoName}>{person.displayName}</Text><Text style={styles.videoStatus}>{callLabel(snapshot)}</Text></View>
        </View>
      ) : (
        <View style={styles.voiceStage}>
          <View style={styles.voiceTop}><IconButton name="chevron-down" onPress={() => void end()} background="transparent" /><View style={styles.callBadge}><View style={styles.ringDot} /><Text style={styles.callBadgeText}>{formatDuration(duration)}</Text></View><View style={{ width: 40 }} /></View>
          <View style={styles.voiceCenter}><View style={styles.avatarHalo}><Avatar name={person.displayName} photoPath={person.photoPath} size={110} online /></View><Text style={styles.name}>{person.displayName}</Text><Text style={styles.status}>{callLabel(snapshot)}</Text>{snapshot.error ? <Text style={styles.errorText}>{snapshot.error}</Text> : null}</View>
        </View>
      )}

      <View style={styles.controls}>
        <Control label={snapshot.microphoneEnabled ? 'Mute' : 'Unmute'} icon={snapshot.microphoneEnabled ? 'mic' : 'mic-off'} active={!snapshot.microphoneEnabled} onPress={() => void controller.toggleMicrophone()} />
        <Control label={speaker ? 'Speaker' : 'Earpiece'} icon={speaker ? 'volume-high' : 'phone-portrait'} active={!speaker} onPress={() => void toggleSpeaker()} />
        {controller.mediaType === 'video' ? <Control label={snapshot.cameraEnabled ? 'Camera' : 'Camera off'} icon={snapshot.cameraEnabled ? 'videocam' : 'videocam-off'} active={!snapshot.cameraEnabled} onPress={() => void controller.toggleCamera()} /> : null}
        {controller.mediaType === 'video' ? <Control label="Flip" icon="camera-reverse" onPress={() => controller.switchCamera()} /> : null}
        <Pressable onPress={() => void end()} disabled={ending} style={({ pressed }) => [styles.endButton, pressed && { opacity: 0.8 }]}><Ionicons name="call" size={21} color="white" style={{ transform: [{ rotate: '135deg' }] }} /></Pressable>
      </View>
      {!snapshot.turnConfigured ? <Text style={styles.turnWarning}>STUN-only · some mobile networks require TURN</Text> : null}
      {snapshot.error && controller.mediaType === 'video' ? <Text style={styles.videoError}>{snapshot.error}</Text> : null}
    </AppScreen>
  );
}

function Control({ label, icon, active = false, onPress }: { label: string; icon: keyof typeof Ionicons.glyphMap; active?: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={styles.controlItem}><View style={[styles.control, active && styles.controlActive]}><Ionicons name={icon} size={20} color={active ? theme.colors.teal : theme.colors.text} /></View><Text style={styles.controlLabel}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  screen: { paddingHorizontal: 0, paddingTop: 0, paddingBottom: 15, backgroundColor: '#021112' },
  videoStage: { flex: 1, backgroundColor: '#031011', overflow: 'hidden' },
  remotePlaceholder: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center', gap: 14, backgroundColor: '#051B1C' },
  connectText: { color: theme.colors.textSecondary, fontSize: 12 },
  videoTop: { position: 'absolute', top: 8, left: 18, right: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  videoBottom: { position: 'absolute', bottom: 22, left: 22 },
  videoName: { color: 'white', fontSize: 20, fontWeight: '800', textShadowColor: '#000', textShadowRadius: 8 },
  videoStatus: { color: '#D8E5E2', fontSize: 12, marginTop: 4, textShadowColor: '#000', textShadowRadius: 8 },
  localVideo: { position: 'absolute', top: 72, right: 18, width: 104, height: 148, borderRadius: 17, overflow: 'hidden', borderWidth: 1, borderColor: '#B4FFF2' },
  voiceStage: { flex: 1, paddingHorizontal: 22 },
  voiceTop: { height: 60, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  callBadge: { flexDirection: 'row', gap: 7, alignItems: 'center', backgroundColor: '#0B2727', borderColor: theme.colors.border, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 100 },
  ringDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: theme.colors.teal },
  callBadgeText: { color: theme.colors.textSecondary, fontSize: 11, fontVariant: ['tabular-nums'] },
  voiceCenter: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingBottom: 42 },
  avatarHalo: { borderRadius: 80, padding: 8, backgroundColor: '#0C2B2C', borderWidth: 1, borderColor: theme.colors.border },
  name: { color: theme.colors.text, fontSize: 25, fontWeight: '800', marginTop: 19 },
  status: { color: theme.colors.textSecondary, fontSize: 13, marginTop: 9 },
  errorText: { color: theme.colors.danger, fontSize: 11, textAlign: 'center', marginTop: 8, maxWidth: 280 },
  controls: { minHeight: 108, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14, paddingHorizontal: 15 },
  controlItem: { alignItems: 'center', gap: 7 },
  control: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: '#143031' },
  controlActive: { backgroundColor: '#10413C' },
  controlLabel: { color: theme.colors.textSecondary, fontSize: 9 },
  endButton: { width: 58, height: 58, borderRadius: 29, backgroundColor: '#E04E4F', alignItems: 'center', justifyContent: 'center', marginLeft: 4 },
  turnWarning: { color: '#C5A76A', textAlign: 'center', fontSize: 9, marginBottom: 2 },
  videoError: { color: theme.colors.danger, textAlign: 'center', fontSize: 10, marginBottom: 6 }
});

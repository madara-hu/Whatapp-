import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  orderBy,
  where,
  writeBatch,
  type DocumentData
} from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import {
  MediaStream,
  RTCPeerConnection,
  RTCIceCandidate,
  RTCSessionDescription,
  mediaDevices,
  registerGlobals,
  type MediaStreamTrack
} from 'react-native-webrtc';
import { requireFirebase } from '@/config/firebase';
import { canTransitionCallStatus, isTerminalCallStatus, releaseCallResources } from '@/core/callLifecycle';
import type { CallDescription, CallDocument, CallMediaType, CallStatus } from '@/types/models';

registerGlobals();

interface RTCIceServer {
  urls: string | string[];
  username?: string;
  credential?: string;
}

interface RTCSessionDescriptionInit {
  type: 'offer' | 'answer';
  sdp: string;
}

const STUN_FALLBACK: RTCIceServer = { urls: 'stun:stun.l.google.com:19302' };

type CallRole = 'caller' | 'callee';
type PeerConnectionState = 'new' | 'connecting' | 'connected' | 'disconnected' | 'failed' | 'closed' | string;

export interface CallSnapshot {
  status: CallStatus;
  connectionState: PeerConnectionState;
  localStream: MediaStream;
  remoteStream: MediaStream | null;
  microphoneEnabled: boolean;
  cameraEnabled: boolean;
  turnConfigured: boolean;
  error: string | null;
}

type IceConfig = { servers: RTCIceServer[]; turnConfigured: boolean };

function callFromData(id: string, data: DocumentData): CallDocument {
  return {
    id,
    callerId: String(data.callerId ?? ''),
    calleeId: String(data.calleeId ?? ''),
    participantIds: Array.isArray(data.participantIds) ? data.participantIds as string[] : [],
    mediaType: data.mediaType === 'video' ? 'video' : 'audio',
    status: (data.status ?? 'ringing') as CallStatus,
    offer: data.offer && typeof data.offer.sdp === 'string' ? data.offer as CallDescription : null,
    answer: data.answer && typeof data.answer.sdp === 'string' ? data.answer as CallDescription : null,
    createdAt: data.createdAt ?? null,
    answeredAt: data.answeredAt ?? null,
    endedAt: data.endedAt ?? null,
    durationSeconds: typeof data.durationSeconds === 'number' ? data.durationSeconds : null
  };
}

async function resolveIceConfig(): Promise<IceConfig> {
  const { functions } = requireFirebase();
  try {
    const getTurnConfig = httpsCallable<void, { iceServers?: RTCIceServer[] }>(functions, 'getTurnConfig');
    const response = await getTurnConfig();
    const serverList = response.data.iceServers?.filter(server => server.urls) ?? [];
    const turnConfigured = serverList.some(server => {
      const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
      return urls.some(url => url.startsWith('turn:') || url.startsWith('turns:'));
    });
    return { servers: [STUN_FALLBACK, ...serverList], turnConfigured };
  } catch {
    // STUN helps on many networks but cannot relay media. Some mobile NATs need TURN.
    return { servers: [STUN_FALLBACK], turnConfigured: false };
  }
}

function localMediaConstraints(mediaType: CallMediaType) {
  return {
    audio: true,
    video: mediaType === 'video'
      ? { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } }
      : false
  };
}

async function removeCandidateDocuments(callId: string): Promise<void> {
  const { db } = requireFirebase();
  const callRef = doc(db, 'calls', callId);
  for (const side of ['callerCandidates', 'calleeCandidates']) {
    const candidates = await getDocs(collection(callRef, side));
    for (let start = 0; start < candidates.docs.length; start += 400) {
      const batch = writeBatch(db);
      candidates.docs.slice(start, start + 400).forEach(candidate => batch.delete(candidate.ref));
      await batch.commit();
    }
  }
}

export class CallController {
  private current: CallSnapshot;
  private listeners = new Set<(snapshot: CallSnapshot) => void>();
  private unsubscribers: Array<() => void> = [];
  private candidateQueue: RTCIceCandidate[] = [];
  private pendingLocalCandidates: Array<{ candidate: string; sdpMid?: string | null; sdpMLineIndex?: number | null }> = [];
  private localCandidateWriter: ((candidate: { candidate: string; sdpMid?: string | null; sdpMLineIndex?: number | null }) => void) | null = null;
  private disposed = false;
  private releasing = false;
  private activeStartedAt: number | null = null;

  constructor(
    readonly callId: string,
    readonly role: CallRole,
    readonly mediaType: CallMediaType,
    readonly peer: RTCPeerConnection,
    private readonly callRef: ReturnType<typeof doc>,
    localStream: MediaStream,
    turnConfigured: boolean,
    initialStatus: CallStatus
  ) {
    this.current = {
      status: initialStatus,
      connectionState: 'new',
      localStream,
      remoteStream: null,
      microphoneEnabled: true,
      cameraEnabled: mediaType === 'video',
      turnConfigured,
      error: null
    };

    this.peer.addEventListener('track', event => {
      const stream = event.streams?.[0];
      if (stream) this.patch({ remoteStream: stream });
      else {
        const fallback = this.current.remoteStream ?? new MediaStream();
        if (event.track) fallback.addTrack(event.track);
        this.patch({ remoteStream: fallback });
      }
    });

    this.peer.addEventListener('connectionstatechange', () => {
      const state = this.peer.connectionState;
      this.patch({ connectionState: state });
      if (state === 'connected') {
        if (this.activeStartedAt === null) this.activeStartedAt = Date.now();
        void this.updateStatus('active');
      } else if (state === 'failed' && !this.disposed) {
        this.patch({ error: 'Call connection failed. Check TURN setup and network access.' });
        void this.updateStatus('failed');
      }
    });
  }

  get snapshot(): CallSnapshot { return this.current; }

  subscribe(listener: (snapshot: CallSnapshot) => void): () => void {
    this.listeners.add(listener);
    listener(this.current);
    return () => this.listeners.delete(listener);
  }

  addUnsubscriber(unsubscribe: () => void): void {
    this.unsubscribers.push(unsubscribe);
  }

  patch(patch: Partial<CallSnapshot>): void {
    this.current = { ...this.current, ...patch };
    for (const listener of this.listeners) listener(this.current);
  }

  queueLocalCandidate(candidate: { candidate: string; sdpMid?: string | null; sdpMLineIndex?: number | null }): void {
    if (this.localCandidateWriter) this.localCandidateWriter(candidate);
    else this.pendingLocalCandidates.push(candidate);
  }

  setLocalCandidateWriter(writer: (candidate: { candidate: string; sdpMid?: string | null; sdpMLineIndex?: number | null }) => void): void {
    this.localCandidateWriter = writer;
    const queued = this.pendingLocalCandidates.splice(0);
    queued.forEach(candidate => writer(candidate));
  }

  queueCandidate(candidate: RTCIceCandidate): void {
    if (this.peer.remoteDescription) {
      void this.peer.addIceCandidate(candidate).catch(() => undefined);
    } else {
      this.candidateQueue.push(candidate);
    }
  }

  async flushCandidates(): Promise<void> {
    if (!this.peer.remoteDescription) return;
    const queue = this.candidateQueue.splice(0);
    for (const candidate of queue) {
      try { await this.peer.addIceCandidate(candidate); } catch { /* stale ICE is harmless after reconnect */ }
    }
  }

  async updateStatus(status: CallStatus): Promise<void> {
    if (this.disposed) return;
    try {
      const snapshot = await getDoc(this.callRef);
      if (!snapshot.exists()) return;
      const currentStatus = snapshot.data().status as CallStatus;
      if (currentStatus === status || !canTransitionCallStatus(currentStatus, status)) return;
      if (status === 'failed') {
        const durationSeconds = this.activeStartedAt ? Math.max(0, Math.floor((Date.now() - this.activeStartedAt) / 1000)) : 0;
        await updateDoc(this.callRef, {
          status,
          endedAt: serverTimestamp(),
          durationSeconds,
          updatedAt: serverTimestamp()
        });
      } else {
        await updateDoc(this.callRef, { status, updatedAt: serverTimestamp() });
      }
    } catch {
      this.patch({ error: 'Call signaling could not be updated. Check connectivity.' });
    }
  }

  setSignaledStatus(status: CallStatus): void {
    this.patch({ status });
    if (isTerminalCallStatus(status)) void this.releaseFromRemoteEnd(status);
  }

  async toggleMicrophone(): Promise<void> {
    const next = !this.current.microphoneEnabled;
    this.current.localStream.getAudioTracks().forEach(track => { track.enabled = next; });
    this.patch({ microphoneEnabled: next });
  }

  async toggleCamera(): Promise<void> {
    const next = !this.current.cameraEnabled;
    this.current.localStream.getVideoTracks().forEach(track => { track.enabled = next; });
    this.patch({ cameraEnabled: next });
  }

  switchCamera(): void {
    const track = this.current.localStream.getVideoTracks()[0] as (MediaStreamTrack & { _switchCamera?: () => void }) | undefined;
    track?._switchCamera?.();
  }

  async end(status: 'ended' | 'failed' = 'ended'): Promise<void> {
    if (this.disposed) return;
    try {
      const snapshot = await getDoc(this.callRef);
      if (snapshot.exists()) {
        const currentStatus = snapshot.data().status as CallStatus;
        if (!isTerminalCallStatus(currentStatus) && canTransitionCallStatus(currentStatus, status)) {
          const durationSeconds = this.activeStartedAt ? Math.max(0, Math.floor((Date.now() - this.activeStartedAt) / 1000)) : 0;
          await updateDoc(this.callRef, {
            status,
            endedAt: serverTimestamp(),
            durationSeconds,
            updatedAt: serverTimestamp()
          });
        }
      }
    } catch {
      this.patch({ error: 'Call ended locally, but the final status may not sync until reconnect.' });
    }
    this.patch({ status });
    await this.release();
  }

  private async releaseFromRemoteEnd(status: CallStatus): Promise<void> {
    if (this.releasing || this.disposed) return;
    this.patch({ status });
    await this.release();
  }

  private async release(): Promise<void> {
    if (this.releasing) return;
    this.releasing = true;
    this.disposed = true;
    await releaseCallResources({
      streams: [this.current.localStream, this.current.remoteStream],
      peer: this.peer,
      unsubscribers: this.unsubscribers,
      removeCandidates: () => removeCandidateDocuments(this.callId)
    });
    this.unsubscribers = [];
    this.patch({ connectionState: 'closed' });
  }
}

async function attachSignaling(controller: CallController, callRef: ReturnType<typeof doc>, role: CallRole): Promise<void> {
  const remoteCandidateCollection = role === 'caller' ? 'calleeCandidates' : 'callerCandidates';
  const remoteCandidates = query(collection(callRef, remoteCandidateCollection));
  const unsubscribeCandidates = onSnapshot(remoteCandidates, snapshot => {
    snapshot.docChanges().forEach(change => {
      if (change.type !== 'added') return;
      const data = change.doc.data();
      if (typeof data.candidate !== 'string') return;
      const candidate = new RTCIceCandidate({
        candidate: data.candidate,
        sdpMid: typeof data.sdpMid === 'string' ? data.sdpMid : null,
        sdpMLineIndex: typeof data.sdpMLineIndex === 'number' ? data.sdpMLineIndex : null
      });
      controller.queueCandidate(candidate);
    });
  }, () => controller.patch({ error: 'ICE signaling listener disconnected.' }));
  controller.addUnsubscriber(unsubscribeCandidates);

  const unsubscribeCall = onSnapshot(callRef, snapshot => {
    if (!snapshot.exists()) {
      controller.patch({ error: 'The call record is no longer available.' });
      return;
    }
    const data = snapshot.data();
    const status = data.status as CallStatus;
    controller.setSignaledStatus(status);
    const answer = data.answer as RTCSessionDescriptionInit | undefined;
    if (role === 'caller' && answer?.sdp) void setRemoteAnswerIfNeeded(controller, answer);
  }, () => controller.patch({ error: 'Call signaling listener disconnected.' }));
  controller.addUnsubscriber(unsubscribeCall);
}

const remoteDescriptions = new WeakSet<RTCPeerConnection>();
async function setRemoteAnswerIfNeeded(controller: CallController, answer: RTCSessionDescriptionInit): Promise<void> {
  const peer = controller.peer;
  if (remoteDescriptions.has(peer) || peer.remoteDescription) return;
  remoteDescriptions.add(peer);
  try {
    await peer.setRemoteDescription(new RTCSessionDescription(answer));
    await controller.flushCandidates();
  } catch {
    remoteDescriptions.delete(peer);
    controller.patch({ error: 'Could not apply the call answer.' });
  }
}

async function createPeer(callRef: ReturnType<typeof doc>, role: CallRole, mediaType: CallMediaType, ice: IceConfig): Promise<{
  peer: RTCPeerConnection;
  localStream: MediaStream;
  controller: CallController;
}> {
  const localStream = await mediaDevices.getUserMedia(localMediaConstraints(mediaType));
  const peer = new RTCPeerConnection({ iceServers: ice.servers, iceCandidatePoolSize: 4 });
  localStream.getTracks().forEach(track => peer.addTrack(track, localStream));
  const callId = callRef.id;
  const controller = new CallController(callId, role, mediaType, peer, callRef, localStream, ice.turnConfigured, role === 'caller' ? 'ringing' : 'connecting');
  peer.addEventListener('icecandidate', event => {
    if (event.candidate) {
      const data = event.candidate.toJSON();
      if (data.candidate) controller.queueLocalCandidate({
        candidate: data.candidate,
        sdpMid: data.sdpMid ?? null,
        sdpMLineIndex: data.sdpMLineIndex ?? null
      });
    }
  });
  return { peer, localStream, controller };
}

export async function startOutgoingCall(input: {
  callerId: string;
  calleeId: string;
  mediaType: CallMediaType;
}): Promise<CallController> {
  const { db } = requireFirebase();
  const ice = await resolveIceConfig();
  const callRef = doc(collection(db, 'calls'));
  const { peer, controller } = await createPeer(callRef, 'caller', input.mediaType, ice);
  try {
    const offer = await peer.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: input.mediaType === 'video' });
    await peer.setLocalDescription(offer);
    await setDoc(callRef, {
      callerId: input.callerId,
      calleeId: input.calleeId,
      participantIds: [input.callerId, input.calleeId].sort(),
      mediaType: input.mediaType,
      status: 'ringing',
      offer: { type: offer.type, sdp: offer.sdp ?? '' },
      answer: null,
      createdAt: serverTimestamp(),
      answeredAt: null,
      endedAt: null,
      durationSeconds: null,
      updatedAt: serverTimestamp()
    });
    controller.setLocalCandidateWriter(candidate => {
      void addDoc(collection(callRef, 'callerCandidates'), {
        candidate: candidate.candidate,
        sdpMid: candidate.sdpMid ?? null,
        sdpMLineIndex: candidate.sdpMLineIndex ?? null,
        createdAt: serverTimestamp()
      }).catch(() => controller.patch({ error: 'ICE candidate could not be sent.' }));
    });
    await attachSignaling(controller, callRef, 'caller');
    return controller;
  } catch (error) {
    await controller.end('failed');
    throw error;
  }
}

export async function acceptIncomingCall(input: {
  callId: string;
  currentUid: string;
}): Promise<CallController> {
  const { db } = requireFirebase();
  const callRef = doc(db, 'calls', input.callId);
  const snapshot = await getDoc(callRef);
  if (!snapshot.exists()) throw new Error('This call is no longer available.');
  const call = callFromData(snapshot.id, snapshot.data());
  if (call.calleeId !== input.currentUid || call.status !== 'ringing' || !call.offer?.sdp) {
    throw new Error('This call has already ended or is not for this account.');
  }
  const ice = await resolveIceConfig();
  const { peer, controller } = await createPeer(callRef, 'callee', call.mediaType, ice);
  try {
    await attachSignaling(controller, callRef, 'callee');
    await peer.setRemoteDescription(new RTCSessionDescription(call.offer));
    remoteDescriptions.add(peer);
    await controller.flushCandidates();
    const answer = await peer.createAnswer();
    await peer.setLocalDescription(answer);
    await updateDoc(callRef, {
      answer: { type: answer.type, sdp: answer.sdp ?? '' },
      status: 'connecting',
      answeredAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    controller.setLocalCandidateWriter(candidate => {
      void addDoc(collection(callRef, 'calleeCandidates'), {
        candidate: candidate.candidate,
        sdpMid: candidate.sdpMid ?? null,
        sdpMLineIndex: candidate.sdpMLineIndex ?? null,
        createdAt: serverTimestamp()
      }).catch(() => controller.patch({ error: 'ICE candidate could not be sent.' }));
    });
    return controller;
  } catch (error) {
    await controller.end('failed');
    throw error;
  }
}

export async function declineIncomingCall(callId: string): Promise<void> {
  const { db } = requireFirebase();
  const callRef = doc(db, 'calls', callId);
  await updateDoc(callRef, { status: 'declined', endedAt: serverTimestamp(), durationSeconds: 0, updatedAt: serverTimestamp() });
  await removeCandidateDocuments(callId).catch(() => undefined);
}

export async function cancelRingingCall(callId: string): Promise<void> {
  const { db } = requireFirebase();
  const callRef = doc(db, 'calls', callId);
  await updateDoc(callRef, { status: 'ended', endedAt: serverTimestamp(), durationSeconds: 0, updatedAt: serverTimestamp() });
  await removeCandidateDocuments(callId).catch(() => undefined);
}

export function subscribeIncomingCalls(uid: string, onData: (calls: CallDocument[]) => void, onError: (error: Error) => void): () => void {
  const { db } = requireFirebase();
  const incomingQuery = query(collection(db, 'calls'), where('calleeId', '==', uid), where('status', '==', 'ringing'));
  return onSnapshot(incomingQuery, snapshot => onData(snapshot.docs.map(item => callFromData(item.id, item.data()))), error => onError(error));
}

export function subscribeCallHistory(uid: string, onData: (calls: CallDocument[]) => void, onError: (error: Error) => void): () => void {
  const { db } = requireFirebase();
  const historyQuery = query(collection(db, 'calls'), where('participantIds', 'array-contains', uid), orderBy('createdAt', 'desc'));
  return onSnapshot(historyQuery, snapshot => onData(snapshot.docs.map(item => callFromData(item.id, item.data()))), error => onError(error));
}

export function subscribeCallRecord(callId: string, onData: (call: CallDocument | null) => void, onError: (error: Error) => void): () => void {
  const { db } = requireFirebase();
  return onSnapshot(doc(db, 'calls', callId), snapshot => onData(snapshot.exists() ? callFromData(snapshot.id, snapshot.data()) : null), error => onError(error));
}

export async function getCall(callId: string): Promise<CallDocument | null> {
  const { db } = requireFirebase();
  const snapshot = await getDoc(doc(db, 'calls', callId));
  return snapshot.exists() ? callFromData(snapshot.id, snapshot.data()) : null;
}

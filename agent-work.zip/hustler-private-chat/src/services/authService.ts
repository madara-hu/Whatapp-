import {
  createUserWithEmailAndPassword,
  deleteUser,
  signInWithEmailAndPassword,
  signOut,
  updateProfile as updateAuthProfile,
  type UserCredential
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
  type DocumentData
} from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { requireFirebase } from '@/config/firebase';
import type { AccountStatus, UserProfile } from '@/types/models';

export function normalizeUsername(username: string): string {
  const normalized = username.trim().toLowerCase();
  if (!/^[a-z0-9_]{3,20}$/.test(normalized)) {
    throw new Error('Username must be 3–20 characters using letters, numbers, or underscores.');
  }
  return normalized;
}

function profileFromData(uid: string, data: DocumentData): UserProfile {
  return {
    uid,
    username: String(data.username ?? ''),
    displayName: String(data.displayName ?? ''),
    about: String(data.about ?? ''),
    photoPath: typeof data.photoPath === 'string' ? data.photoPath : null,
    status: (data.status ?? 'pending') as AccountStatus,
    role: data.role === 'admin' ? 'admin' : 'member',
    accountDisabled: data.accountDisabled === true,
    presence: data.presence === 'online' ? 'online' : 'offline',
    lastSeenAt: data.lastSeenAt ?? null,
    createdAt: data.createdAt ?? null,
    updatedAt: data.updatedAt ?? null
  };
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const { db } = requireFirebase();
  const profileSnapshot = await getDoc(doc(db, 'users', uid));
  return profileSnapshot.exists() ? profileFromData(uid, profileSnapshot.data()) : null;
}

export async function signIn(email: string, password: string): Promise<UserCredential> {
  const { auth } = requireFirebase();
  return signInWithEmailAndPassword(auth, email.trim(), password);
}

export async function registerPendingAccount(input: {
  email: string;
  password: string;
  username: string;
  displayName: string;
}): Promise<UserCredential> {
  const { auth, db } = requireFirebase();
  const username = normalizeUsername(input.username);
  const displayName = input.displayName.trim();
  if (displayName.length < 2 || displayName.length > 48) throw new Error('Display name must be 2–48 characters.');
  if (input.password.length < 10) throw new Error('Use a password with at least 10 characters.');

  const credential = await createUserWithEmailAndPassword(auth, input.email.trim(), input.password);
  try {
    await updateAuthProfile(credential.user, { displayName });
    const userRef = doc(db, 'users', credential.user.uid);
    const usernameRef = doc(db, 'usernames', username);
    await runTransaction(db, async transaction => {
      const reservedUsername = await transaction.get(usernameRef);
      if (reservedUsername.exists()) throw new Error('That username is already taken.');
      transaction.set(usernameRef, {
        uid: credential.user.uid,
        username,
        createdAt: serverTimestamp()
      });
      transaction.set(userRef, {
        username,
        displayName,
        about: '',
        photoPath: null,
        status: 'pending',
        role: 'member',
        accountDisabled: false,
        presence: 'offline',
        lastSeenAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });
  } catch (error) {
    // Avoid leaving a newly created Auth identity stranded without its pending
    // Firestore profile if username reservation or the profile transaction fails.
    try {
      await deleteUser(credential.user);
    } catch {
      await signOut(auth).catch(() => undefined);
    }
    throw error;
  }
  return credential;
}

export async function logout(): Promise<void> {
  const { auth } = requireFirebase();
  await signOut(auth);
}

export async function updateOwnProfile(uid: string, input: { displayName: string; about: string }): Promise<void> {
  const { auth, db } = requireFirebase();
  const displayName = input.displayName.trim();
  const about = input.about.trim();
  if (auth.currentUser?.uid !== uid) throw new Error('You may only edit your own profile.');
  if (displayName.length < 2 || displayName.length > 48) throw new Error('Display name must be 2–48 characters.');
  if (about.length > 140) throw new Error('About text must be 140 characters or fewer.');
  await Promise.all([
    updateAuthProfile(auth.currentUser, { displayName }),
    updateDoc(doc(db, 'users', uid), { displayName, about, updatedAt: serverTimestamp() })
  ]);
}

export async function setOwnPhotoPath(uid: string, photoPath: string): Promise<void> {
  const { auth, db } = requireFirebase();
  if (auth.currentUser?.uid !== uid) throw new Error('You may only edit your own profile.');
  await updateDoc(doc(db, 'users', uid), { photoPath, updatedAt: serverTimestamp() });
}

export async function adminSetAccountStatus(uid: string, status: 'approved' | 'pending' | 'disabled'): Promise<void> {
  const { functions } = requireFirebase();
  const call = httpsCallable<{ uid: string; status: 'approved' | 'pending' | 'disabled' }, { ok: boolean }>(functions, 'adminSetAccountStatus');
  await call({ uid, status });
}

export async function listPendingAccounts(): Promise<UserProfile[]> {
  const { db } = requireFirebase();
  const pending = query(collection(db, 'users'), where('status', '==', 'pending'), orderBy('createdAt', 'desc'), limit(100));
  const snapshot = await getDocs(pending);
  return snapshot.docs.map(item => profileFromData(item.id, item.data()));
}

export async function requireAccountStatus(uid: string): Promise<AccountStatus | null> {
  const profile = await getUserProfile(uid);
  return profile?.status ?? null;
}

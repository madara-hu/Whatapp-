import { fromByteArray } from 'base64-js';
import { collection, doc } from 'firebase/firestore';
import { getBytes, ref, uploadBytes } from 'firebase/storage';
import { requireFirebase } from '@/config/firebase';

const MAX_IMAGE_BYTES = 6 * 1024 * 1024;
const MAX_AUDIO_BYTES = 8 * 1024 * 1024;
const loadedMedia = new Map<string, string>();

async function uriToBlob(uri: string): Promise<Blob> {
  const response = await fetch(uri);
  if (!response.ok) throw new Error('Could not read the selected media.');
  return response.blob();
}

export async function uploadChatMedia(input: {
  chatId: string;
  uid: string;
  uri: string;
  kind: 'image' | 'audio';
  mimeType: string;
}): Promise<{ storagePath: string; size: number }> {
  const { db, storage } = requireFirebase();
  const blob = await uriToBlob(input.uri);
  const maximum = input.kind === 'image' ? MAX_IMAGE_BYTES : MAX_AUDIO_BYTES;
  if (blob.size <= 0 || blob.size > maximum) {
    throw new Error(input.kind === 'image' ? 'Photos must be smaller than 6 MB.' : 'Voice messages must be smaller than 8 MB.');
  }
  if (input.kind === 'image' && !input.mimeType.startsWith('image/')) throw new Error('Choose an image file.');
  if (input.kind === 'audio' && !input.mimeType.startsWith('audio/')) throw new Error('The recording format is not supported.');
  const objectId = doc(collection(db, '_private-media-id-source')).id;
  const extension = input.kind === 'image' ? 'jpg' : 'm4a';
  const storagePath = `chats/${input.chatId}/${input.uid}/${objectId}.${extension}`;
  await uploadBytes(ref(storage, storagePath), blob, {
    contentType: input.mimeType,
    customMetadata: { chatId: input.chatId, ownerUid: input.uid, mediaKind: input.kind }
  });
  return { storagePath, size: blob.size };
}

export async function uploadProfilePhoto(uid: string, uri: string): Promise<string> {
  const { storage } = requireFirebase();
  const blob = await uriToBlob(uri);
  if (blob.size <= 0 || blob.size > MAX_IMAGE_BYTES) throw new Error('Profile photos must be smaller than 6 MB.');
  const storagePath = `users/${uid}/profile/avatar.jpg`;
  await uploadBytes(ref(storage, storagePath), blob, {
    contentType: blob.type || 'image/jpeg',
    customMetadata: { ownerUid: uid, mediaKind: 'profile-photo' }
  });
  loadedMedia.delete(storagePath);
  return storagePath;
}

export async function loadPrivateMediaDataUri(storagePath: string, mimeType = 'image/jpeg'): Promise<string> {
  const cached = loadedMedia.get(storagePath);
  if (cached) return cached;
  const { storage } = requireFirebase();
  const maximum = mimeType.startsWith('audio/') ? MAX_AUDIO_BYTES : MAX_IMAGE_BYTES;
  const bytes = await getBytes(ref(storage, storagePath), maximum);
  const dataUri = `data:${mimeType};base64,${fromByteArray(new Uint8Array(bytes))}`;
  // Bound the in-memory cache; plaintext media remains in process memory only.
  if (loadedMedia.size >= 12) loadedMedia.delete(loadedMedia.keys().next().value as string);
  loadedMedia.set(storagePath, dataUri);
  return dataUri;
}

export function clearPrivateMediaCache(): void {
  loadedMedia.clear();
}

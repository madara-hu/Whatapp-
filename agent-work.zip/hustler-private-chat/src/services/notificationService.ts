import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Application from 'expo-application';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { deleteDoc, doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { requireFirebase } from '@/config/firebase';

let handlerInstalled = false;

export function installNotificationPresentation(): void {
  if (handlerInstalled) return;
  handlerInstalled = true;
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: false
    })
  });
}

const INSTALL_ID_KEY = '@hustler/push-install-id';
let installIdPromise: Promise<string> | null = null;

function getInstallId(): Promise<string> {
  if (!installIdPromise) {
    installIdPromise = (async () => {
      const existing = await AsyncStorage.getItem(INSTALL_ID_KEY);
      if (existing) return existing;
      const random = `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 14)}`;
      const generated = `${Platform.OS}_${Application.applicationId ?? Device.osBuildId ?? 'device'}_${random}`
        .replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 100);
      await AsyncStorage.setItem(INSTALL_ID_KEY, generated);
      return generated;
    })().catch(error => {
      installIdPromise = null;
      throw error;
    });
  }
  return installIdPromise;
}

async function savePushToken(uid: string, token: string): Promise<void> {
  const { db } = requireFirebase();
  const installId = await getInstallId();
  await setDoc(doc(db, 'users', uid, 'devices', installId), {
    token,
    platform: Platform.OS,
    updatedAt: serverTimestamp()
  }, { merge: true });
}

export async function refreshPushTokenIfGranted(uid: string): Promise<void> {
  if (!Device.isDevice) return;
  const permission = await Notifications.getPermissionsAsync();
  const { db } = requireFirebase();
  const installId = await getInstallId();
  const registration = doc(db, 'users', uid, 'devices', installId);
  if (!permission.granted) {
    await deleteDoc(registration).catch(() => undefined);
    return;
  }
  const token = await Notifications.getDevicePushTokenAsync();
  await savePushToken(uid, String(token.data));
}

export function subscribePushTokenRefresh(uid: string): () => void {
  const subscription = Notifications.addPushTokenListener(event => {
    void savePushToken(uid, String(event.data)).catch(() => undefined);
  });
  return () => subscription.remove();
}

export async function unregisterPushNotifications(uid: string): Promise<void> {
  const { db } = requireFirebase();
  const installId = await getInstallId();
  await deleteDoc(doc(db, 'users', uid, 'devices', installId));
}

export async function registerPushNotifications(uid: string): Promise<{ enabled: boolean; message: string }> {
  if (!Device.isDevice) return { enabled: false, message: 'Push notifications require a physical device.' };
  installNotificationPresentation();
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('messages', {
      name: 'Messages',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 220, 120, 220],
      lightColor: '#20D7B5'
    });
    await Notifications.setNotificationChannelAsync('calls', {
      name: 'Calls',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 500, 250, 500],
      lightColor: '#20D7B5'
    });
  }
  const current = await Notifications.getPermissionsAsync();
  const permission = current.granted ? current : await Notifications.requestPermissionsAsync();
  if (!permission.granted) {
    const { db } = requireFirebase();
    const installId = await getInstallId().catch(() => null);
    if (installId) await deleteDoc(doc(db, 'users', uid, 'devices', installId)).catch(() => undefined);
    return { enabled: false, message: 'Notification permission is off.' };
  }

  try {
    const token = await Notifications.getDevicePushTokenAsync();
    await savePushToken(uid, String(token.data));
    return { enabled: true, message: 'Push notifications are ready.' };
  } catch {
    return { enabled: false, message: 'FCM is not configured in this build yet.' };
  }
}

export function addNotificationTapListener(listener: (data: Record<string, unknown>) => void): () => void {
  const subscription = Notifications.addNotificationResponseReceivedListener(response => {
    const raw = response.notification.request.content.data;
    listener(raw as Record<string, unknown>);
  });
  return () => subscription.remove();
}

export async function getInitialNotificationData(): Promise<Record<string, unknown> | null> {
  const response = await Notifications.getLastNotificationResponseAsync();
  if (!response) return null;
  return response.notification.request.content.data as Record<string, unknown>;
}

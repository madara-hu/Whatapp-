import {
  arrayUnion,
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  startAfter,
  updateDoc,
  where,
  type DocumentData,
  type QueryDocumentSnapshot
} from 'firebase/firestore';
import { requireFirebase } from '@/config/firebase';
import { directChatId, messagePreview } from '@/core/chatModel';
import type { ChatDocument, MessageDocument, MessageType, TypingState, UserProfile } from '@/types/models';

function chatFromData(id: string, data: DocumentData): ChatDocument {
  return {
    id,
    participantIds: Array.isArray(data.participantIds) ? data.participantIds as string[] : [],
    createdAt: data.createdAt ?? null,
    updatedAt: data.updatedAt ?? null,
    lastMessageAt: data.lastMessageAt ?? null,
    lastMessageId: typeof data.lastMessageId === 'string' ? data.lastMessageId : null,
    lastMessagePreview: typeof data.lastMessagePreview === 'string' ? data.lastMessagePreview : '',
    lastSenderId: typeof data.lastSenderId === 'string' ? data.lastSenderId : null,
    unreadCounts: data.unreadCounts && typeof data.unreadCounts === 'object' ? data.unreadCounts as Record<string, number> : {}
  };
}

function messageFromData(id: string, data: DocumentData): MessageDocument {
  return {
    id,
    senderId: String(data.senderId ?? ''),
    type: data.type === 'image' || data.type === 'audio' ? data.type : 'text',
    text: typeof data.text === 'string' ? data.text : null,
    storagePath: typeof data.storagePath === 'string' ? data.storagePath : null,
    mediaMimeType: typeof data.mediaMimeType === 'string' ? data.mediaMimeType : null,
    durationMs: typeof data.durationMs === 'number' ? data.durationMs : null,
    createdAt: data.createdAt ?? null,
    deliveredTo: Array.isArray(data.deliveredTo) ? data.deliveredTo as string[] : [],
    readBy: Array.isArray(data.readBy) ? data.readBy as string[] : []
  };
}

function userFromData(uid: string, data: DocumentData): UserProfile {
  return {
    uid,
    username: String(data.username ?? ''),
    displayName: String(data.displayName ?? ''),
    about: String(data.about ?? ''),
    photoPath: typeof data.photoPath === 'string' ? data.photoPath : null,
    status: data.status === 'approved' || data.status === 'disabled' ? data.status : 'pending',
    role: data.role === 'admin' ? 'admin' : 'member',
    accountDisabled: data.accountDisabled === true,
    presence: data.presence === 'online' ? 'online' : 'offline',
    lastSeenAt: data.lastSeenAt ?? null,
    createdAt: data.createdAt ?? null,
    updatedAt: data.updatedAt ?? null
  };
}

export function subscribeChats(
  uid: string,
  onData: (chats: ChatDocument[]) => void,
  onError: (error: Error) => void
): () => void {
  const { db } = requireFirebase();
  const chatsQuery = query(collection(db, 'chats'), where('participantIds', 'array-contains', uid), orderBy('updatedAt', 'desc'), limit(100));
  return onSnapshot(chatsQuery, snapshot => {
    onData(snapshot.docs.map(item => chatFromData(item.id, item.data())));
  }, error => onError(error));
}

export async function getApprovedUser(uid: string): Promise<UserProfile | null> {
  const { db } = requireFirebase();
  const snapshot = await getDoc(doc(db, 'users', uid));
  if (!snapshot.exists()) return null;
  return userFromData(uid, snapshot.data());
}

export async function getApprovedContacts(currentUid: string): Promise<UserProfile[]> {
  const { db } = requireFirebase();
  const contactsQuery = query(collection(db, 'users'), where('status', '==', 'approved'), orderBy('displayName', 'asc'), limit(200));
  const snapshot = await getDocs(contactsQuery);
  return snapshot.docs.map(item => userFromData(item.id, item.data())).filter(item => item.uid !== currentUid && !item.accountDisabled);
}

export async function getOrCreateDirectChat(currentUid: string, otherUid: string): Promise<string> {
  const { db } = requireFirebase();
  if (currentUid === otherUid) throw new Error('You cannot create a chat with yourself.');
  const chatId = directChatId(currentUid, otherUid);
  const chatRef = doc(db, 'chats', chatId);
  await runTransaction(db, async transaction => {
    const current = await transaction.get(chatRef);
    if (current.exists()) {
      const participants = current.data().participantIds;
      if (!Array.isArray(participants) || !participants.includes(currentUid) || !participants.includes(otherUid)) {
        throw new Error('This conversation does not match its participants.');
      }
      return;
    }
    const participantIds = [currentUid, otherUid].sort();
    transaction.set(chatRef, {
      participantIds,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastMessageAt: null,
      lastMessageId: null,
      lastMessagePreview: '',
      lastSenderId: null,
      unreadCounts: { [currentUid]: 0, [otherUid]: 0 }
    });
  });
  return chatId;
}

export interface MessagePage {
  messages: MessageDocument[];
  cursor: QueryDocumentSnapshot<DocumentData> | null;
  hasMore: boolean;
}

export function subscribeLatestMessages(
  chatId: string,
  onData: (page: MessagePage) => void,
  onError: (error: Error) => void
): () => void {
  const { db } = requireFirebase();
  const messagesQuery = query(collection(db, 'chats', chatId, 'messages'), orderBy('createdAt', 'desc'), limit(40));
  return onSnapshot(messagesQuery, snapshot => {
    const docs = snapshot.docs;
    onData({
      messages: docs.map(item => messageFromData(item.id, item.data())),
      cursor: docs.at(-1) ?? null,
      hasMore: docs.length === 40
    });
  }, error => onError(error));
}

export async function loadOlderMessages(chatId: string, cursor: QueryDocumentSnapshot<DocumentData>): Promise<MessagePage> {
  const { db } = requireFirebase();
  const olderQuery = query(collection(db, 'chats', chatId, 'messages'), orderBy('createdAt', 'desc'), startAfter(cursor), limit(40));
  const snapshot = await getDocs(olderQuery);
  const docs = snapshot.docs;
  return {
    messages: docs.map(item => messageFromData(item.id, item.data())),
    cursor: docs.at(-1) ?? null,
    hasMore: docs.length === 40
  };
}

export async function sendMessage(input: {
  chatId: string;
  senderId: string;
  recipientId: string;
  type: MessageType;
  text?: string;
  storagePath?: string;
  mediaMimeType?: string;
  durationMs?: number;
}): Promise<string> {
  const { db } = requireFirebase();
  const text = input.type === 'text' ? (input.text ?? '').trim() : '';
  if (input.type === 'text' && (!text || text.length > 4000)) throw new Error('Messages must contain 1–4,000 characters.');
  if (input.type !== 'text' && !input.storagePath) throw new Error('The media upload did not finish.');
  const chatRef = doc(db, 'chats', input.chatId);
  const messageRef = doc(collection(db, 'chats', input.chatId, 'messages'));
  await runTransaction(db, async transaction => {
    const chatSnapshot = await transaction.get(chatRef);
    if (!chatSnapshot.exists()) throw new Error('Conversation not found.');
    const participants = chatSnapshot.data().participantIds as string[] | undefined;
    if (!participants?.includes(input.senderId) || !participants.includes(input.recipientId)) throw new Error('You are not a participant in this conversation.');
    const currentCounts = (chatSnapshot.data().unreadCounts ?? {}) as Record<string, number>;
    const unreadCounts = { ...currentCounts, [input.recipientId]: Math.max(0, currentCounts[input.recipientId] ?? 0) + 1, [input.senderId]: 0 };
    transaction.set(messageRef, {
      senderId: input.senderId,
      type: input.type,
      text: input.type === 'text' ? text : null,
      storagePath: input.storagePath ?? null,
      mediaMimeType: input.mediaMimeType ?? null,
      durationMs: input.durationMs ?? null,
      createdAt: serverTimestamp(),
      deliveredTo: [input.senderId],
      readBy: [input.senderId]
    });
    transaction.update(chatRef, {
      lastMessageId: messageRef.id,
      lastMessagePreview: messagePreview({ type: input.type, text }),
      lastMessageAt: serverTimestamp(),
      lastSenderId: input.senderId,
      updatedAt: serverTimestamp(),
      unreadCounts
    });
  });
  return messageRef.id;
}

export async function markMessagesDelivered(chatId: string, uid: string, messages: MessageDocument[]): Promise<void> {
  const { db } = requireFirebase();
  const incoming = messages.filter(item => item.senderId !== uid && !item.deliveredTo.includes(uid));
  if (incoming.length === 0) return;
  const { writeBatch } = await import('firebase/firestore');
  const batch = writeBatch(db);
  for (const message of incoming.slice(0, 40)) {
    batch.update(doc(db, 'chats', chatId, 'messages', message.id), { deliveredTo: arrayUnion(uid) });
  }
  await batch.commit();
}

export async function markChatRead(chatId: string, uid: string, messages: MessageDocument[]): Promise<void> {
  const { db } = requireFirebase();
  const incoming = messages.filter(item => item.senderId !== uid && !item.readBy.includes(uid));
  const { writeBatch } = await import('firebase/firestore');
  const batch = writeBatch(db);
  for (const message of incoming.slice(0, 40)) {
    batch.update(doc(db, 'chats', chatId, 'messages', message.id), {
      deliveredTo: arrayUnion(uid),
      readBy: arrayUnion(uid)
    });
  }
  await batch.commit();
  await clearUnreadCount(chatId, uid);
}

export function subscribeTyping(chatId: string, currentUid: string, onData: (typing: TypingState[]) => void): () => void {
  const { db } = requireFirebase();
  const typingQuery = query(collection(db, 'chats', chatId, 'typing'), where('isTyping', '==', true));
  return onSnapshot(typingQuery, snapshot => {
    onData(snapshot.docs
      .filter(item => item.id !== currentUid)
      .map(item => ({ uid: item.id, isTyping: item.data().isTyping === true, updatedAt: item.data().updatedAt ?? null })));
  }, () => onData([]));
}

export async function setTyping(chatId: string, uid: string, isTyping: boolean): Promise<void> {
  const { db } = requireFirebase();
  const typingRef = doc(db, 'chats', chatId, 'typing', uid);
  if (isTyping) {
    await setDoc(typingRef, { isTyping: true, updatedAt: serverTimestamp() }, { merge: true });
  } else {
    await updateDoc(typingRef, { isTyping: false, updatedAt: serverTimestamp() }).catch(() => undefined);
  }
}

export async function clearUnreadCount(chatId: string, uid: string): Promise<void> {
  const { db } = requireFirebase();
  const chatRef = doc(db, 'chats', chatId);
  await runTransaction(db, async transaction => {
    const snapshot = await transaction.get(chatRef);
    if (!snapshot.exists()) return;
    const participants = snapshot.data().participantIds as string[] | undefined;
    if (!participants?.includes(uid)) throw new Error('Not a conversation participant.');
    const previousCounts = (snapshot.data().unreadCounts ?? {}) as Record<string, number>;
    if ((previousCounts[uid] ?? 0) === 0) return;
    const counts = { ...previousCounts, [uid]: 0 };
    transaction.update(chatRef, { unreadCounts: counts });
  });
}

export async function getChatById(chatId: string): Promise<ChatDocument | null> {
  const { db } = requireFirebase();
  const snapshot = await getDoc(doc(db, 'chats', chatId));
  return snapshot.exists() ? chatFromData(snapshot.id, snapshot.data()) : null;
}

export async function getChatParticipants(chatId: string): Promise<string[]> {
  const { db } = requireFirebase();
  const snapshot = await getDoc(doc(db, 'chats', chatId));
  return snapshot.exists() && Array.isArray(snapshot.data().participantIds) ? snapshot.data().participantIds as string[] : [];
}

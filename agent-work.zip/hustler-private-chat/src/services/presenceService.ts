import { AppState, type AppStateStatus } from 'react-native';
import { onDisconnect, onValue, ref, serverTimestamp, set, type DataSnapshot } from 'firebase/database';
import { requireRealtimeDatabase } from '@/config/firebase';

function writeStatus(uid: string, state: 'online' | 'offline') {
  const database = requireRealtimeDatabase();
  return set(ref(database, `status/${uid}`), {
    state,
    last_changed: serverTimestamp()
  });
}

export function connectPresence(uid: string): () => void {
  const database = requireRealtimeDatabase();
  const connectedRef = ref(database, '.info/connected');
  const userStatusRef = ref(database, `status/${uid}`);
  let disposed = false;
  let appState: AppStateStatus = AppState.currentState;
  const connectionListener = onValue(connectedRef, snapshot => {
    if (disposed || snapshot.val() !== true) return;
    void (async () => {
      try {
        await onDisconnect(userStatusRef).set({ state: 'offline', last_changed: serverTimestamp() });
        if (!disposed && appState === 'active') {
          await set(userStatusRef, { state: 'online', last_changed: serverTimestamp() });
        }
      } catch {
        // Firestore-backed approved membership remains the authorization boundary.
      }
    })();
  });
  const appStateListener = AppState.addEventListener('change', nextState => {
    appState = nextState;
    if (nextState === 'active') void writeStatus(uid, 'online').catch(() => undefined);
    else void writeStatus(uid, 'offline').catch(() => undefined);
  });
  void onDisconnect(userStatusRef).set({ state: 'offline', last_changed: serverTimestamp() }).catch(() => undefined);
  return () => {
    disposed = true;
    connectionListener();
    appStateListener.remove();
    void onDisconnect(userStatusRef).cancel().catch(() => undefined);
    void writeStatus(uid, 'offline').catch(() => undefined);
  };
}

export function subscribePresence(uid: string, onData: (snapshot: DataSnapshot) => void): () => void {
  const database = requireRealtimeDatabase();
  return onValue(ref(database, `status/${uid}`), onData, () => undefined);
}

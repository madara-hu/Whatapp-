import { Image, StyleSheet, Text, View } from 'react-native';
import { theme } from '@/config/theme';
import { usePrivateMedia } from '@/hooks/usePrivateMedia';

interface Props {
  name: string;
  photoPath?: string | null;
  size?: number;
  online?: boolean;
  muted?: boolean;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  return parts.slice(0, 2).map(part => part[0]?.toUpperCase() ?? '').join('') || 'H';
}

export function Avatar({ name, photoPath, size = 48, online = false, muted = false }: Props) {
  const uri = usePrivateMedia(photoPath);
  return (
    <View style={[styles.wrapper, { width: size, height: size, borderRadius: size / 2 }, muted && styles.muted]}>
      {uri ? <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} /> : (
        <View style={[styles.fallback, { width: size, height: size, borderRadius: size / 2 }]}>
          <Text style={[styles.initials, { fontSize: size * 0.32 }]}>{initials(name)}</Text>
        </View>
      )}
      {online && <View style={[styles.onlineDot, { width: size * 0.24, height: size * 0.24, borderRadius: size * 0.12 }]} />}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { position: 'relative', backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border },
  fallback: { alignItems: 'center', justifyContent: 'center', backgroundColor: '#123737' },
  initials: { color: theme.colors.teal, fontWeight: '800', letterSpacing: 0.4 },
  onlineDot: { position: 'absolute', right: -1, bottom: 0, backgroundColor: theme.colors.teal, borderWidth: 2, borderColor: theme.colors.background },
  muted: { opacity: 0.92 }
});

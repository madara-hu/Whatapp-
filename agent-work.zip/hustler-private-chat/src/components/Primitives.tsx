import type { ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type KeyboardTypeOptions,
  type StyleProp,
  type ViewStyle
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '@/config/theme';

export function AppScreen({ children, scroll = false, style }: { children: ReactNode; scroll?: boolean; style?: StyleProp<ViewStyle> }) {
  const content = <View style={[styles.screenContent, style]}>{children}</View>;
  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right', 'bottom']}>
      {scroll ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scrollContent}>{content}</ScrollView> : content}
    </SafeAreaView>
  );
}

export function BrandMark({ size = 46 }: { size?: number }) {
  return (
    <View style={[styles.brandMark, { width: size, height: size, borderRadius: size * 0.34 }]}>
      <Ionicons name="chatbubble-ellipses-outline" size={size * 0.55} color={theme.colors.teal} />
      <View style={[styles.brandLock, { width: size * 0.18, height: size * 0.17, bottom: size * 0.13 }]} />
    </View>
  );
}

export function BrandTitle({ subtitle }: { subtitle?: string }) {
  return (
    <View style={styles.brandTitleWrap}>
      <View style={styles.brandTitleRow}><BrandMark size={42} /><Text style={styles.brandTitle}>HUSTLER</Text></View>
      {subtitle ? <Text style={styles.brandSubtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export function PrimaryButton({
  title,
  onPress,
  icon,
  loading = false,
  disabled = false,
  variant = 'primary',
  style
}: {
  title: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [styles.button, styles[`button_${variant}`], pressed && styles.pressed, (disabled || loading) && styles.disabled, style]}
    >
      {loading ? <ActivityIndicator color={variant === 'primary' ? theme.colors.backgroundDeep : theme.colors.teal} /> : (
        <View style={styles.buttonInner}>
          {icon ? <Ionicons name={icon} size={18} color={variant === 'primary' ? theme.colors.backgroundDeep : theme.colors.text} /> : null}
          <Text style={[styles.buttonLabel, variant === 'primary' && styles.buttonLabelPrimary]}>{title}</Text>
        </View>
      )}
    </Pressable>
  );
}

export function IconButton({
  name,
  onPress,
  size = 42,
  iconSize = 20,
  color = theme.colors.text,
  background = theme.colors.surface,
  disabled = false
}: {
  name: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  size?: number;
  iconSize?: number;
  color?: string;
  background?: string;
  disabled?: boolean;
}) {
  return (
    <Pressable onPress={onPress} disabled={disabled} style={({ pressed }) => [styles.iconButton, { width: size, height: size, borderRadius: size / 2, backgroundColor: background }, pressed && styles.pressed, disabled && styles.disabled]}>
      <Ionicons name={name} size={iconSize} color={color} />
    </Pressable>
  );
}

export function FormField({
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry,
  keyboardType,
  autoCapitalize = 'none',
  multiline = false,
  maxLength,
  icon
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  secureTextEntry?: boolean;
  keyboardType?: KeyboardTypeOptions;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  multiline?: boolean;
  maxLength?: number;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={[styles.fieldShell, multiline && styles.fieldMultiline]}>
        {icon ? <Ionicons name={icon} size={18} color={theme.colors.textMuted} style={styles.fieldIcon} /> : null}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={theme.colors.textMuted}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          maxLength={maxLength}
          multiline={multiline}
          style={[styles.fieldInput, multiline && styles.fieldInputMultiline]}
          selectionColor={theme.colors.teal}
        />
      </View>
    </View>
  );
}

export function ScreenHeader({
  title,
  onBack,
  right
}: {
  title: string;
  onBack: () => void;
  right?: ReactNode;
}) {
  return (
    <View style={styles.header}>
      <IconButton name="chevron-back" onPress={onBack} size={40} background="transparent" />
      <Text style={styles.headerTitle}>{title}</Text>
      <View style={styles.headerRight}>{right}</View>
    </View>
  );
}

export function ErrorNotice({ text }: { text: string | null | undefined }) {
  if (!text) return null;
  return <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={18} color={theme.colors.danger} /><Text style={styles.errorText}>{text}</Text></View>;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <Text style={styles.sectionLabel}>{children}</Text>;
}

export function Divider() {
  return <View style={styles.divider} />;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.background },
  screenContent: { flex: 1, paddingHorizontal: 20, paddingTop: 10, paddingBottom: 8 },
  scrollContent: { flexGrow: 1 },
  brandTitleWrap: { alignItems: 'center', gap: 12 },
  brandTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandMark: { alignItems: 'center', justifyContent: 'center', backgroundColor: theme.colors.surfaceElevated, borderWidth: 1, borderColor: theme.colors.border, position: 'relative' },
  brandLock: { position: 'absolute', backgroundColor: theme.colors.surfaceElevated, borderRadius: 3, borderWidth: 1.6, borderColor: theme.colors.text, alignSelf: 'center' },
  brandTitle: { color: theme.colors.text, fontSize: 22, fontWeight: '900', letterSpacing: 2.5 },
  brandSubtitle: { color: theme.colors.textSecondary, fontSize: 13, letterSpacing: 0.5 },
  button: { height: 54, borderRadius: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
  button_primary: { backgroundColor: theme.colors.teal },
  button_secondary: { backgroundColor: theme.colors.surfaceElevated, borderColor: theme.colors.border, borderWidth: 1 },
  button_danger: { backgroundColor: theme.colors.dangerSoft, borderColor: '#703C3F', borderWidth: 1 },
  button_ghost: { backgroundColor: 'transparent' },
  buttonInner: { flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center' },
  buttonLabel: { fontSize: 15, fontWeight: '700', color: theme.colors.text, letterSpacing: 0.2 },
  buttonLabelPrimary: { color: theme.colors.backgroundDeep },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.5 },
  iconButton: { alignItems: 'center', justifyContent: 'center' },
  fieldWrap: { gap: 8, marginBottom: 14 },
  fieldLabel: { color: theme.colors.textSecondary, fontSize: 12, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
  fieldShell: { minHeight: 54, borderRadius: 16, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14 },
  fieldMultiline: { alignItems: 'flex-start', minHeight: 96 },
  fieldIcon: { marginRight: 10 },
  fieldInput: { flex: 1, color: theme.colors.text, fontSize: 15, paddingVertical: 13 },
  fieldInputMultiline: { minHeight: 76, textAlignVertical: 'top' },
  header: { minHeight: 52, flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  headerTitle: { flex: 1, color: theme.colors.text, fontSize: 18, fontWeight: '800', marginLeft: 4 },
  headerRight: { minWidth: 40, alignItems: 'flex-end' },
  errorBox: { borderRadius: 14, backgroundColor: '#361F24', padding: 12, flexDirection: 'row', alignItems: 'center', gap: 9, marginVertical: 8 },
  errorText: { flex: 1, color: '#FFC4C1', fontSize: 13, lineHeight: 18 },
  sectionLabel: { color: theme.colors.textMuted, fontSize: 11, fontWeight: '800', letterSpacing: 1.4, textTransform: 'uppercase', marginBottom: 10 },
  divider: { height: 1, backgroundColor: theme.colors.borderSoft }
});

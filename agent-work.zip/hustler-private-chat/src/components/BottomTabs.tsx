import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '@/config/theme';
import type { MainTab } from '@/types/models';

const items: Array<{ key: MainTab; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'chats', label: 'Chats', icon: 'chatbubble-ellipses-outline' },
  { key: 'calls', label: 'Calls', icon: 'call-outline' },
  { key: 'contacts', label: 'People', icon: 'people-outline' },
  { key: 'profile', label: 'Profile', icon: 'person-circle-outline' }
];

export function BottomTabs({ active, onChange }: { active: MainTab; onChange: (tab: MainTab) => void }) {
  return (
    <View style={styles.container}>
      {items.map(item => {
        const selected = item.key === active;
        return (
          <Pressable key={item.key} onPress={() => onChange(item.key)} style={styles.item}>
            <View style={[styles.iconWrap, selected && styles.activeWrap]}>
              <Ionicons name={item.icon} size={19} color={selected ? theme.colors.teal : theme.colors.textMuted} />
            </View>
            <Text style={[styles.label, selected && styles.activeLabel]}>{item.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { height: 74, backgroundColor: '#071E1F', borderRadius: 23, borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginTop: 12, marginBottom: 2, paddingHorizontal: 8 },
  item: { alignItems: 'center', justifyContent: 'center', gap: 3, flex: 1 },
  iconWrap: { minWidth: 52, height: 33, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  activeWrap: { backgroundColor: '#123E3B' },
  label: { color: theme.colors.textMuted, fontSize: 10, fontWeight: '600' },
  activeLabel: { color: theme.colors.teal, fontWeight: '800' }
});

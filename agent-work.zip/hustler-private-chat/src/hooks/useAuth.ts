import { useEffect, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db, firebaseReady } from '@/config/firebase';
import type { AccountStatus, UserProfile } from '@/types/models';

function readProfile(uid: string, data: Record<string, unknown>): UserProfile {
  return {
    uid,
    username: typeof data.username === 'string' ? data.username : '',
    displayName: typeof data.displayName === 'string' ? data.displayName : '',
    about: typeof data.about === 'string' ? data.about : '',
    photoPath: typeof data.photoPath === 'string' ? data.photoPath : null,
    status: (data.status ?? 'pending') as AccountStatus,
    role: data.role === 'admin' ? 'admin' : 'member',
    accountDisabled: data.accountDisabled === true,
    presence: data.presence === 'online' ? 'online' : 'offline',
    lastSeenAt: (data.lastSeenAt as UserProfile['lastSeenAt']) ?? null,
    createdAt: (data.createdAt as UserProfile['createdAt']) ?? null,
    updatedAt: (data.updatedAt as UserProfile['updatedAt']) ?? null
  };
}

export interface AuthState {
  user: User | null;
  profile: UserProfile | null;
  ready: boolean;
  error: string | null;
}

export function useAuthState(): AuthState {
  const [state, setState] = useState<AuthState>({ user: null, profile: null, ready: false, error: null });

  useEffect(() => {
    const activeAuth = auth;
    const activeDb = db;
    if (!firebaseReady || !activeAuth || !activeDb) {
      setState({ user: null, profile: null, ready: true, error: null });
      return;
    }
    let unsubscribeProfile: (() => void) | undefined;
    const unsubscribeAuth = onAuthStateChanged(activeAuth, nextUser => {
      unsubscribeProfile?.();
      unsubscribeProfile = undefined;
      setState({ user: nextUser, profile: null, ready: !nextUser, error: null });
      if (!nextUser) {
        setState({ user: null, profile: null, ready: true, error: null });
        return;
      }
      unsubscribeProfile = onSnapshot(doc(activeDb, 'users', nextUser.uid), snapshot => {
        if (snapshot.exists()) {
          setState({ user: nextUser, profile: readProfile(nextUser.uid, snapshot.data()), ready: true, error: null });
        } else {
          setState({ user: nextUser, profile: null, ready: true, error: null });
        }
      }, error => setState({ user: nextUser, profile: null, ready: true, error: error.message }));
    }, error => setState({ user: null, profile: null, ready: true, error: error.message }));

    return () => {
      unsubscribeProfile?.();
      unsubscribeAuth();
    };
  }, []);

  return state;
}

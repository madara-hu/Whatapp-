import { useEffect, useState } from 'react';
import * as Network from 'expo-network';

export function useNetworkStatus(): boolean | null {
  const [connected, setConnected] = useState<boolean | null>(null);
  useEffect(() => {
    let mounted = true;
    void Network.getNetworkStateAsync().then(state => {
      if (mounted) setConnected(Boolean(state.isConnected && state.isInternetReachable !== false));
    }).catch(() => { if (mounted) setConnected(null); });
    const subscription = Network.addNetworkStateListener(state => {
      setConnected(Boolean(state.isConnected && state.isInternetReachable !== false));
    });
    return () => {
      mounted = false;
      subscription.remove();
    };
  }, []);
  return connected;
}

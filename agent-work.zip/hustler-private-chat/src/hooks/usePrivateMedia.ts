import { useEffect, useState } from 'react';
import { loadPrivateMediaDataUri } from '@/services/mediaService';

export function usePrivateMedia(storagePath: string | null | undefined, mimeType = 'image/jpeg'): string | null {
  const [uri, setUri] = useState<string | null>(null);
  useEffect(() => {
    let mounted = true;
    setUri(null);
    if (storagePath) {
      void loadPrivateMediaDataUri(storagePath, mimeType).then(value => {
        if (mounted) setUri(value);
      }).catch(() => {
        if (mounted) setUri(null);
      });
    }
    return () => { mounted = false; };
  }, [storagePath, mimeType]);
  return uri;
}

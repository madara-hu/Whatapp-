import AsyncStorage from '@react-native-async-storage/async-storage';
import { initializeApp, getApps, type FirebaseApp, type FirebaseOptions } from 'firebase/app';
import { getAuth, initializeAuth, type Auth, type Persistence } from 'firebase/auth';
import * as FirebaseAuth from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';
import { getFunctions, type Functions } from 'firebase/functions';
import { getDatabase, type Database } from 'firebase/database';
import { appConfig } from './appConfig';

const firebaseConfig: FirebaseOptions = {
  ...(appConfig.firebase.apiKey ? { apiKey: appConfig.firebase.apiKey } : {}),
  ...(appConfig.firebase.authDomain ? { authDomain: appConfig.firebase.authDomain } : {}),
  ...(appConfig.firebase.projectId ? { projectId: appConfig.firebase.projectId } : {}),
  ...(appConfig.firebase.storageBucket ? { storageBucket: appConfig.firebase.storageBucket } : {}),
  ...(appConfig.firebase.messagingSenderId ? { messagingSenderId: appConfig.firebase.messagingSenderId } : {}),
  ...(appConfig.firebase.appId ? { appId: appConfig.firebase.appId } : {}),
  ...(appConfig.firebase.databaseURL ? { databaseURL: appConfig.firebase.databaseURL } : {})
};

export const firebaseReady = Boolean(
  firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId &&
  firebaseConfig.storageBucket && firebaseConfig.messagingSenderId && firebaseConfig.appId
);

let firebaseApp: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let firestoreInstance: Firestore | null = null;
let storageInstance: FirebaseStorage | null = null;
let functionsInstance: Functions | null = null;
let databaseInstance: Database | null = null;

if (firebaseReady) {
  firebaseApp = getApps().length > 0 ? getApps()[0] ?? initializeApp(firebaseConfig) : initializeApp(firebaseConfig);
  // Firebase exposes this helper through its React Native runtime entry. The
  // public web typings do not expose it in every TypeScript resolver condition.
  const getReactNativePersistence = (FirebaseAuth as unknown as {
    getReactNativePersistence?: (storage: {
      getItem(key: string): Promise<string | null>;
      setItem(key: string, value: string): Promise<void>;
      removeItem(key: string): Promise<void>;
    }) => Persistence;
  }).getReactNativePersistence;
  if (typeof getReactNativePersistence !== 'function') {
    throw new Error('Firebase React Native Auth persistence is unavailable in this native build.');
  }
  try {
    authInstance = initializeAuth(firebaseApp, {
      persistence: getReactNativePersistence(AsyncStorage)
    });
  } catch (error) {
    // Metro Fast Refresh may evaluate this module again after Auth was initialized.
    const code = typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code ?? '')
      : '';
    if (code !== 'auth/already-initialized') throw error;
    authInstance = getAuth(firebaseApp);
  }
  firestoreInstance = getFirestore(firebaseApp);
  storageInstance = getStorage(firebaseApp);
  functionsInstance = getFunctions(firebaseApp, 'asia-south1');
  if (firebaseConfig.databaseURL) databaseInstance = getDatabase(firebaseApp, firebaseConfig.databaseURL);
}

export const auth = authInstance;
export const db = firestoreInstance;
export const storage = storageInstance;
export const functions = functionsInstance;
export const realtimeDatabase = databaseInstance;

export function requireFirebase(): {
  app: FirebaseApp;
  auth: Auth;
  db: Firestore;
  storage: FirebaseStorage;
  functions: Functions;
} {
  if (!firebaseApp || !authInstance || !firestoreInstance || !storageInstance || !functionsInstance) {
    throw new Error('Firebase is not configured. Add the Firebase client settings from the project setup guide.');
  }
  return { app: firebaseApp, auth: authInstance, db: firestoreInstance, storage: storageInstance, functions: functionsInstance };
}

export function requireRealtimeDatabase(): Database {
  if (!databaseInstance) throw new Error('Realtime Database is not configured. Add the database URL and deploy database.rules.json.');
  return databaseInstance;
}

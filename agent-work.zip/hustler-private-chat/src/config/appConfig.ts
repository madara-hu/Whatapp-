import Constants from 'expo-constants';

const extra = (Constants.expoConfig?.extra ?? {}) as {
  unlockExpression?: string;
  firebase?: Record<string, string | undefined>;
};

/**
 * This local calculator gate is only an obfuscation screen. Any expression
 * included in a client build can be extracted; Firebase Auth and Firestore
 * Rules provide the actual account/data access control.
 */
export const appConfig = {
  brand: 'HUSTLER',
  unlockExpression: extra.unlockExpression?.trim() || '748+88',
  firebase: extra.firebase ?? {}
} as const;

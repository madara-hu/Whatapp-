export const theme = {
  colors: {
    background: '#041618',
    backgroundDeep: '#021112',
    surface: '#0A2223',
    surfaceElevated: '#102D2E',
    surfaceSoft: '#153638',
    border: '#214647',
    borderSoft: '#173638',
    teal: '#20D7B5',
    tealStrong: '#05B998',
    tealDim: '#0B7667',
    text: '#F4FAF8',
    textSecondary: '#A8C0BE',
    textMuted: '#71908D',
    danger: '#F16868',
    dangerSoft: '#4C252B',
    warning: '#E8B961',
    white: '#FFFFFF',
    transparent: 'transparent'
  },
  radius: {
    small: 12,
    medium: 18,
    large: 26,
    pill: 999
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 14,
    lg: 20,
    xl: 28,
    xxl: 38
  }
} as const;

export type Theme = typeof theme;

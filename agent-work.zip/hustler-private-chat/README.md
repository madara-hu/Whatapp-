# HUSTLER Private Chat

An original dark/teal Expo React Native application for approved one-to-one messaging and calls. The calculator gate is a convenience route into the app; it is **not** an authentication or device-security feature.

## Current implementation status

This is a configured project draft, not a released or deployed app.

Verified in this workspace:

- Root TypeScript check and the 8 core unit tests.
- 7 Firestore rules tests and 2 Storage rules tests against the Firebase emulators.
- Expo config resolution, Android prebuild, and Android JavaScript bundle export.
- Cloud Functions TypeScript compilation (the deployment runtime is Node 22).

Not verified or not available here:

- The user has an existing Firebase project, but this checkout is not linked to it: no local `.env` or Android `google-services.json` is present. The earlier Android export used blank placeholder Firebase settings; no live deployment was performed.
- No APK/AAB, EAS build, or Android device/simulator run has been produced.
- No end-to-end call, push delivery, TURN relay, background-call, or live Firebase test has been run.
- `expo-doctor` reports one metadata warning: `react-native-webrtc` is listed as untested on React Native's New Architecture. SDK 57 requires the New Architecture; the Android native project has not been compiled on a device/build server.
- Expo SDK 57 requires Node.js 22.13 or newer. The system Node is 20.20.2; a side-by-side Node 22 runtime can be used without replacing it or editing the project.
- At the last local configuration check, `.env`, `.env.local`, and `google-services.json` were absent, and `EAS_PROJECT_ID` was unset. The required client config names are listed below; no Firebase values or credentials are stored in this repository.

See [SECURITY.md](SECURITY.md) for the security model and limitations.

## Features in the source

- Safe calculator parser (no `eval`), operator precedence, decimals, clear/backspace, and same-interaction unlock when `748+88` is followed by `=`.
- Firebase email/password sign-in and pending-account registration with administrator approval.
- Firestore one-to-one chats, text messages, authenticated photo/voice media in Storage, typing state, unread counts, and delivery/read receipts.
- Realtime Database presence mirrored to Firestore by a Cloud Function.
- WebRTC audio/video call signaling, call history, FCM notification triggers, and an optional TURN credential callable.
- Least-privilege draft Firestore, Storage, and RTDB rules plus Firestore indexes and emulator tests.

This build does not provide reviewed end-to-end encryption. Message text, uploaded media, and call signaling are handled by Firebase services; see [SECURITY.md](SECURITY.md).

## Requirements

- Node.js **22.13+** and npm.
- Java **21+** to run the Firebase Emulator Suite with the current Firebase CLI.
- A Firebase project for live use: Authentication, Firestore, Storage, Realtime Database, FCM, and Cloud Functions.
- A custom Expo/EAS native build for WebRTC. Expo Go does not include `react-native-webrtc`.
- For local Android compilation: Android SDK/build tools and the JDK required by the selected Expo/Gradle build image. Alternatively, use EAS Build.

## Install and run checks

```bash
npm ci
npm run typecheck
npm test
npm run rules:test
```

`npm test` skips emulator-dependent suites when no emulator is running. `npm run rules:test` uses a demo-only project ID, starts Firestore and Storage emulators, and runs 9 rule tests; it does not require Firebase login or a live project. Java 21+ is required.

To install/build the Functions package:

```bash
cd functions
npm ci
npm run build
```

The Functions package targets Node 22. Expo development and production builds also need Node 22.13+.

## Firebase project setup

1. Use the existing Firebase project. Confirm it has an Android app with package name `app.hustler.privatechat`; add that Android app to the existing project only if it is missing. Do not create a second Firebase project unnecessarily.
2. Enable **Email/Password** under Authentication. Create Firestore, Firebase Storage, and Realtime Database instances. Use the exact RTDB URL shown in Firebase Console (it may be region-specific).
3. Copy `.env.example` to `.env` and fill in the client values from Firebase project settings:
   - `EXPO_PUBLIC_FIREBASE_API_KEY`
   - `EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN`
   - `EXPO_PUBLIC_FIREBASE_PROJECT_ID`
   - `EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET`
   - `EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
   - `EXPO_PUBLIC_FIREBASE_APP_ID`
   - `EXPO_PUBLIC_FIREBASE_DATABASE_URL`
4. Download the matching `google-services.json` for the Android app and place it at the project root. The file is git-ignored. Alternatively, configure it as an EAS **file** environment variable and point `GOOGLE_SERVICES_JSON` to that file path during the build.
5. Install/use the Firebase CLI, select the intended project, and deploy the rules and indexes:

   ```bash
   npx firebase-tools@15.34.1 login
   npx firebase-tools@15.34.1 use --add
   npx firebase-tools@15.34.1 deploy --only firestore,storage,database --project YOUR_PROJECT_ID
   ```

   Review the selected project before deploying. The rules intentionally deny access to accounts that are not approved.

6. Register the first administrator in the app so Firebase Authentication and the pending `users/{uid}` profile exist. Then use the secure local provisioning process below. Do not add a hardcoded admin password or grant admin status from client code.

### Provision the first administrator

The provisioning script uses Google Application Default Credentials (ADC), not a service-account JSON pasted into the app or chat.

```bash
cd functions
npm ci
# Authenticate locally with an account that has the required Firebase Auth,
# Firestore, and Realtime Database administration permissions.
gcloud auth application-default login
FIREBASE_DATABASE_URL="https://YOUR-EXACT-RTDB-URL" \
  npm run provision-admin -- admin@example.com YOUR_PROJECT_ID
```

The selected email must already be registered in the app and have a pending profile. After provisioning, sign out and back in so the Firebase ID token refreshes and includes the administrator custom claim. Keep ADC credentials on the trusted operator's machine; never commit them.

### Cloud Functions and TURN

Cloud Functions use the `asia-south1` region and Node.js 22. Functions include message/call push triggers, account-status administration, presence mirroring, missed-call cleanup, and the TURN configuration callable. Scheduled functions and deployment may require the Firebase/Google Cloud billing plan and enabled APIs.

For TURN, create a coturn-compatible shared-secret REST configuration. Put comma-separated TURN URLs in `functions/.env.YOUR_PROJECT_ID` (for example `TURN_URLS=turn:turn.example.net:3478?transport=udp,turns:turn.example.net:5349?transport=tcp`). Store the shared secret only in Secret Manager:

```bash
npx firebase-tools@15.34.1 functions:secrets:set TURN_SHARED_SECRET --project YOUR_PROJECT_ID
```

Then build and deploy:

```bash
cd functions && npm ci && npm run build
cd ..
npx firebase-tools@15.34.1 deploy --only functions --project YOUR_PROJECT_ID
```

Do not put `TURN_SHARED_SECRET` in source, `.env`, or an EAS client variable. If TURN URLs are not configured, calls receive STUN-only configuration; STUN alone cannot guarantee connectivity through mobile/carrier NATs.

## Android development build / APK

The native WebRTC module requires an Expo development/production build; it cannot run in Expo Go. The repository includes a `preview` EAS profile configured to produce an internal APK and a `production` profile configured for an Android App Bundle.

1. Configure the Firebase values and `google-services.json` for the EAS project. Set `EAS_PROJECT_ID` to the ID returned by `eas init` and configure the Firebase client values in the appropriate EAS environment. Configure `GOOGLE_SERVICES_JSON` as an EAS file variable if building remotely.
2. Authenticate through an official Expo flow:
   - With an interactive terminal/browser: `npx eas-cli@27.1.0 login`.
   - In a headless terminal: `npx eas-cli@27.1.0 login --device --non-interactive`. Complete the device/browser verification using the request ID and confirmation steps printed by EAS CLI; use only Expo's official site. The CLI help also documents `--resume <request-id> --match <number-from-browser>` for completing a device login.
   - For CI automation, Expo supports an `EXPO_TOKEN` environment variable; configure it only in a secret manager or protected environment, never in source or chat. See [Expo programmatic access](https://docs.expo.dev/accounts/programmatic-access/).

3. Link the EAS project and build the APK:

   ```bash
   npx eas-cli@27.1.0 init
   npx eas-cli@27.1.0 build --platform android --profile preview
   ```

4. Let EAS generate/manage Android signing credentials through its official prompts. Do not send signing credentials or private keys in chat.

## GitHub Codespaces continuation checklist — MANUAL ACTION REQUIRED

At handoff, this local checkout is on branch `master` and has **no GitHub remote**. The GitHub connector and GitHub CLI are unavailable in this environment, so nothing has been pushed. A verified `hustler-private-chat.bundle` is provided separately for transferring the committed project to Codespaces. Keep the destination repository **private**. Use an existing intended private repository if you have one; do not push this work to an unrelated repository.

### 1. Put the project in a private repository

- In GitHub, open the intended private repository. If you need to create one, create it as **Private**. If GitHub requires a commit before it will create a Codespace, initialize it with a short README on the default branch (usually `main`); the project will be pushed to `master` without overwriting that branch. Before pushing, inspect whether `master` already exists and whether it is the intended project history. Never force-push; if history conflicts, stop and inspect.
- Download the provided `hustler-private-chat.bundle`, open a Codespace for that private repository, then upload the bundle into the Codespaces workspace using its file explorer.
- From the Codespaces terminal at the directory containing the bundle, replace the URL placeholder with the exact HTTPS or SSH URL of your private repository, then run:

  ```bash
  REPO_URL='https://github.com/OWNER/PRIVATE_REPOSITORY.git'
  git clone "$PWD/hustler-private-chat.bundle" /workspaces/hustler-private-chat-import
  cd /workspaces/hustler-private-chat-import
  git remote set-url origin "$REPO_URL"
  git remote -v
  git ls-remote --heads origin master
  git push -u origin master
  ```

  Confirm the remote belongs to you before pushing. This creates/updates only the `master` branch; do not force-push. If `master` already exists and the push is rejected, stop and inspect the remote history. After verifying the project on GitHub, set `master` as the default branch if appropriate; do not delete other branches unless you intend to.

### 2. Open the right Codespace and select Node.js 22+

- Continue in `/workspaces/hustler-private-chat-import`, or open a fresh Codespace on the verified `master` branch.
- In the Codespaces terminal, verify Node is at least 22.13:

  ```bash
  node --version
  ```

  If the image has an older Node and `nvm` is available, use `nvm install 22 && nvm use 22`, then check `node --version` again. The project requires `>=22.13.0`.

### 3. Authenticate EAS without sharing credentials

- Interactive Codespaces terminal:

  ```bash
  npx eas-cli@27.1.0 login
  npx eas-cli@27.1.0 whoami
  ```

- If the terminal cannot open a browser, use EAS CLI's official device-code login and follow the URL/code and any resume/match instructions it prints:

  ```bash
  npx eas-cli@27.1.0 login --device --non-interactive
  ```

- For automated Codespaces/CI runs, configure `EXPO_TOKEN` as a **protected Codespaces secret** (GitHub Settings → Codespaces → Secrets) or other approved secret-manager environment. Do not put the token in source, `.env.example`, commit history, or chat. See [Expo's programmatic access guidance](https://docs.expo.dev/accounts/programmatic-access/).

### 4. Connect this app to the existing Firebase project

**MANUAL ACTION REQUIRED:** In Firebase Console, use the existing project and verify/create its Android app with package `app.hustler.privatechat`. From the existing project's app settings, fill these values in a local `.env` created from the example:

```bash
cp .env.example .env
```

Required client configuration names:

- `EXPO_PUBLIC_FIREBASE_API_KEY`
- `EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `EXPO_PUBLIC_FIREBASE_PROJECT_ID`
- `EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `EXPO_PUBLIC_FIREBASE_APP_ID`
- `EXPO_PUBLIC_FIREBASE_DATABASE_URL` (Realtime Database URL; required for the presence feature)

Use the values shown in Firebase Console; do not invent them. These are Firebase client settings, not service-account credentials. `.env` is git-ignored. For remote EAS builds, add the `EXPO_PUBLIC_FIREBASE_*` values to the appropriate protected EAS environment instead of committing them.

**MANUAL ACTION REQUIRED:** Download `google-services.json` for the Android app in that same Firebase project. Verify its `project_id` matches `EXPO_PUBLIC_FIREBASE_PROJECT_ID` and its Android package is `app.hustler.privatechat`. Place it at the project root in Codespaces (it is git-ignored), or configure it as an EAS **file** environment variable and set `GOOGLE_SERVICES_JSON` to its generated path. Do not use a service-account JSON in place of this Android client file.

### 5. Link the correct EAS project

**MANUAL ACTION REQUIRED:** After EAS login, run `npx eas-cli@27.1.0 init` and choose the intended EAS project. The dynamic Expo config reads `EAS_PROJECT_ID`; ensure it is set in the local ignored `.env` or EAS environment to the actual ID returned by EAS. Do not guess or invent the ID.

### 6. Run checks before asking for an APK build

```bash
npm ci --legacy-peer-deps
npm run check
npx expo install --check
npx expo-doctor
npm run rules:test
```

`npm run rules:test` requires Java 21+ and runs against local demo emulators. Expo Doctor currently reports the known metadata warning that `react-native-webrtc` is untested on the New Architecture; do not hide it. Confirm the remaining project/Firebase configuration is correct before asking to build. The preview APK command, when explicitly ready, is:

```bash
npx eas-cli@27.1.0 build --platform android --profile preview
```

No APK is included in this workspace. Do not build or deploy until the manual setup is complete and the owner explicitly resumes the build.
